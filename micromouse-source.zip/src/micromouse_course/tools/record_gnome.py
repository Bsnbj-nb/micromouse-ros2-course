"""Record the real GNOME desktop through its screencast service."""
import os, sys, time
import dbus
os.environ.setdefault('DBUS_SESSION_BUS_ADDRESS',f'unix:path=/run/user/{os.getuid()}/bus')
bus=dbus.SessionBus()
service=dbus.Interface(bus.get_object('org.gnome.Shell.Screencast','/org/gnome/Shell/Screencast'),'org.gnome.Shell.Screencast')
success,path=service.Screencast(sys.argv[1],dbus.Dictionary({'framerate':dbus.UInt32(12),'draw-cursor':dbus.Boolean(False)},signature='sv'))
print(bool(success),str(path),flush=True)
try:
 if len(sys.argv)>2:time.sleep(float(sys.argv[2]))
 else:sys.stdin.readline()
finally:
 print(service.StopScreencast(),flush=True)
 time.sleep(2)
