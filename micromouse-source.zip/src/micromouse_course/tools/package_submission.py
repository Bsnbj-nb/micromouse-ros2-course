#!/usr/bin/env python3
"""按任务书要求只打包工作空间 src，不包含构建目录和运行缓存。"""

import argparse
from pathlib import Path
import re
from zipfile import ZipFile, ZIP_DEFLATED


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--group", required=True, help="真实组号")
    parser.add_argument("--names", required=True, help="组员姓名，多人用下划线连接")
    parser.add_argument("--out", default="~/micromouse_submission")
    args = parser.parse_args()
    if any(not re.fullmatch(r"[\w\-]+", text) for text in (args.group, args.names)):
        parser.error("组号和姓名不能包含斜杠、空格或路径符号")
    package = Path(__file__).resolve().parents[1]
    src = package.parent
    if src.name != "src":
        parser.error("请从工作空间 src/micromouse_course/tools 运行此脚本")
    output_dir = Path(args.out).expanduser().resolve()
    if src == output_dir or src in output_dir.parents:
        parser.error("输出目录不能放在 src 内，以免把压缩包再次打包")
    output_dir.mkdir(parents=True, exist_ok=True)
    output = output_dir / f"{args.group}_{args.names}_代码包.zip"
    if output.exists():
        parser.error("输出已存在，请换输出目录或先自行备份旧文件")
    excluded = {"__pycache__", ".git", ".pytest_cache", ".venv", "build", "install", "log"}
    count = 0
    with ZipFile(output, "x", ZIP_DEFLATED) as archive:
        for file in sorted(package.rglob("*")):
            if (not file.is_file() or file.is_symlink()
                    or any(part in excluded for part in file.parts)
                    or file.suffix in (".pyc", ".pyo")):
                continue
            archive.write(file, Path("src") / file.relative_to(src))
            count += 1
    print(f"已打包 {count} 个源码与资源文件：{output}")
    print("综合设计报告与不超过3分钟的真实演示视频另按同一组号和姓名命名。")


if __name__ == "__main__":
    main()
