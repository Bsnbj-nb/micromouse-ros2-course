#!/usr/bin/env python3
"""从通路拓扑生成墙体世界，并检查入口到出口的连通性。"""

from collections import deque
import json
from pathlib import Path
import xml.etree.ElementTree as ET


CELL_SIZE = 1.0
WALL_THICKNESS = 0.08
WALL_HEIGHT = 0.50
COLS = 4
ROWS = 4
START = (0, 0)
GOAL = (3, 3)
# 每一对格子表示一条双向通路。未列出的相邻格子之间保留墙体。
PASSAGES = (
    ((0, 0), (1, 0)),
    ((1, 0), (1, 1)),
    ((1, 1), (0, 1)),
    ((0, 1), (0, 2)),
    ((0, 2), (0, 3)),
    ((1, 1), (2, 1)),
    ((2, 1), (2, 0)),
    ((2, 0), (3, 0)),
    ((2, 1), (3, 1)),
    ((2, 1), (2, 2)),
    ((2, 2), (1, 2)),
    ((1, 2), (1, 3)),
    ((1, 3), (2, 3)),
    ((2, 3), (3, 3)),
    ((3, 3), (3, 2)),
)
# 朝向按逆时针递增：东、北、西、南。
DIRECTIONS = ((1, 0), (0, 1), (-1, 0), (0, -1))


def graph():
    neighbors = {(x, y): set() for x in range(COLS) for y in range(ROWS)}
    for a, b in PASSAGES:
        if a not in neighbors or b not in neighbors:
            raise ValueError("通路端点超出迷宫范围")
        if abs(a[0] - b[0]) + abs(a[1] - b[1]) != 1:
            raise ValueError("通路必须连接两个相邻格子")
        if b in neighbors[a]:
            raise ValueError("存在重复通路")
        neighbors[a].add(b)
        neighbors[b].add(a)
    return neighbors


def shortest_cell_path():
    neighbors = graph()
    queue = deque([START])
    parent = {START: None}
    while queue:
        cell = queue.popleft()
        if cell == GOAL:
            path = []
            while cell is not None:
                path.append(cell)
                cell = parent[cell]
            return list(reversed(path))
        for other in sorted(neighbors[cell]):
            if other not in parent:
                parent[other] = cell
                queue.append(other)
    raise ValueError("入口与出口不连通")


def left_hand_cell_walk(max_steps=256):
    """验证离散迷宫的左手规则；此检查不代替连续运动仿真。"""
    neighbors = graph()
    cell, heading = START, 0
    walk = [cell]
    visited_states = set()
    for _ in range(max_steps):
        state = (cell, heading)
        if state in visited_states:
            raise ValueError("左手规则在离散拓扑中进入环路")
        visited_states.add(state)
        for candidate in ((heading + 1) % 4, heading, (heading - 1) % 4, (heading + 2) % 4):
            dx, dy = DIRECTIONS[candidate]
            other = (cell[0] + dx, cell[1] + dy)
            if cell == GOAL and other == (COLS, ROWS - 1):
                walk.append(other)
                return walk
            if other in neighbors[cell]:
                cell, heading = other, candidate
                walk.append(cell)
                break
        else:
            raise ValueError("存在没有通路的格子")
    raise ValueError("左手规则超出步数上限")


def add_text(parent, tag, value):
    item = ET.SubElement(parent, tag)
    item.text = str(value)
    return item


def add_box(world, name, x, y, z, sx, sy, sz, color):
    model = ET.SubElement(world, "model", {"name": name})
    add_text(model, "static", "true")
    add_text(model, "pose", f"{x:.5f} {y:.5f} {z:.5f} 0 0 0")
    link = ET.SubElement(model, "link", {"name": "body"})
    for kind in ("collision", "visual"):
        item = ET.SubElement(link, kind, {"name": name + "_" + kind})
        box = ET.SubElement(ET.SubElement(item, "geometry"), "box")
        add_text(box, "size", f"{sx:.5f} {sy:.5f} {sz:.5f}")
        if kind == "collision":
            ode = ET.SubElement(ET.SubElement(ET.SubElement(item, "surface"), "friction"), "ode")
            add_text(ode, "mu", 0.8)
            add_text(ode, "mu2", 0.8)
        else:
            material = ET.SubElement(item, "material")
            add_text(material, "ambient", color)
            add_text(material, "diffuse", color)
    return model


def create_world(name, camera_center=(2.0, 2.0)):
    sdf = ET.Element("sdf", {"version": "1.6"})
    world = ET.SubElement(sdf, "world", {"name": name})
    add_text(world, "gravity", "0 0 -9.81")
    plugin = ET.SubElement(world, "plugin", {"name": "ground_truth_state", "filename": "libgazebo_ros_state.so"})
    add_text(ET.SubElement(plugin, "ros"), "namespace", "/gazebo")
    add_text(plugin, "update_rate", 20)
    physics = ET.SubElement(world, "physics", {"name": "default_physics", "type": "ode"})
    add_text(physics, "max_step_size", 0.001)
    add_text(physics, "real_time_update_rate", 1000)
    add_text(physics, "real_time_factor", 1.0)
    scene = ET.SubElement(world, "scene")
    add_text(scene, "ambient", "0.65 0.65 0.65 1")
    add_text(scene, "background", "0.92 0.92 0.92 1")
    add_text(scene, "shadows", "false")
    light = ET.SubElement(world, "light", {"name": "sun", "type": "directional"})
    add_text(light, "cast_shadows", "false")
    add_text(light, "pose", "0 0 10 0 0 0")
    add_text(light, "diffuse", "0.8 0.8 0.8 1")
    add_text(light, "specular", "0.1 0.1 0.1 1")
    add_text(light, "direction", "-0.5 0.2 -0.9")
    attenuation = ET.SubElement(light, "attenuation")
    add_text(attenuation, "range", 1000)
    add_text(attenuation, "constant", 0.9)
    add_text(attenuation, "linear", 0.01)
    add_text(attenuation, "quadratic", 0.001)
    add_box(world, "ground", 2.5, 2.5, -0.05, 20, 20, 0.1, "0.85 0.85 0.85 1")
    gui = ET.SubElement(world, "gui", {"fullscreen": "0"})
    camera = ET.SubElement(gui, "camera", {"name": "user_camera"})
    cx, cy = camera_center
    add_text(camera, "pose", f"{cx} {cy - 5.5} 7 0 0.90 1.570796")
    add_text(camera, "view_controller", "orbit")
    add_text(camera, "projection_type", "perspective")
    return sdf, world


def maze_wall_segments():
    """返回墙体中心和长宽，交点处稍微搭接以避免接缝漏碰撞。"""
    neighbors = graph()
    result = []
    for x in range(COLS + 1):
        for y in range(ROWS):
            if (x == 0 and y == 0) or (x == COLS and y == ROWS - 1):
                continue
            if 0 < x < COLS and (x, y) in neighbors[(x - 1, y)]:
                continue
            result.append((f"wall_v_{x}_{y}", x * CELL_SIZE, (y + 0.5) * CELL_SIZE,
                           WALL_THICKNESS, CELL_SIZE + WALL_THICKNESS))
    for y in range(ROWS + 1):
        for x in range(COLS):
            if 0 < y < ROWS and (x, y) in neighbors[(x, y - 1)]:
                continue
            result.append((f"wall_h_{x}_{y}", (x + 0.5) * CELL_SIZE, y * CELL_SIZE,
                           CELL_SIZE + WALL_THICKNESS, WALL_THICKNESS))
    return result


def course_maze():
    sdf, world = create_world("course_maze")
    for name, x, y, sx, sy in maze_wall_segments():
        add_box(world, name, x, y, WALL_HEIGHT / 2, sx, sy, WALL_HEIGHT, "0.32 0.38 0.44 1")
    return sdf


def control_arena():
    sdf, world = create_world("control_arena")
    # 无内部障碍，便于先验证控制算法。前方避障可用东侧边界墙验收。
    for name, x, y, sx, sy in (
        ("wall_south", 2, -1, 6.08, 0.08),
        ("wall_north", 2, 5, 6.08, 0.08),
        ("wall_west", -1, 2, 0.08, 6.08),
        ("wall_east", 5, 2, 0.08, 6.08),
    ):
        add_box(world, name, x, y, WALL_HEIGHT / 2, sx, sy, WALL_HEIGHT, "0.35 0.35 0.35 1")
    return sdf


def failure_loop():
    sdf, world = create_world("failure_loop", (3.0, 3.0))
    # 东墙中央保留一米出口。中央孤岛与外墙不相连。
    for name, x, y, sx, sy in (
        ("wall_south", 3, 0, 6.08, 0.08),
        ("wall_north", 3, 6, 6.08, 0.08),
        ("wall_west", 0, 3, 0.08, 6.08),
        ("wall_east_low", 6, 1.25, 0.08, 2.50),
        ("wall_east_high", 6, 4.75, 0.08, 2.50),
        ("island", 3, 3, 2.0, 2.0),
    ):
        add_box(world, name, x, y, WALL_HEIGHT / 2, sx, sy, WALL_HEIGHT, "0.35 0.35 0.35 1")
    return sdf


def metadata():
    return {
        "purpose": "世界构造参数与离散拓扑检查，不是雷达建图结果或实测轨迹",
        "frame": "gazebo_world",
        "cell_size_m": CELL_SIZE,
        "wall_thickness_m": WALL_THICKNESS,
        "wall_height_m": WALL_HEIGHT,
        "cols": COLS,
        "rows": ROWS,
        "spawn": {"x": 0.5, "y": 0.5, "yaw": 0.0},
        "entrance": {"side": "west", "cell": list(START)},
        "exit": {"side": "east", "cell": list(GOAL), "region": [4.15, 5.0, 3.10, 3.90]},
        "passages": PASSAGES,
        "shortest_cell_path": shortest_cell_path(),
        "left_hand_cell_walk": left_hand_cell_walk(),
        "failure_loop_spawn": {"x": 1.55, "y": 2.5, "yaw": -1.5707963267948966},
        "failure_loop_exit_region": [6.15, 7.0, 2.60, 3.40],
    }


def main():
    output = Path(__file__).resolve().parents[1] / "worlds"
    output.mkdir(parents=True, exist_ok=True)
    graph_data = graph()
    seen, queue = {START}, deque([START])
    while queue:
        for other in graph_data[queue.popleft()]:
            if other not in seen:
                seen.add(other)
                queue.append(other)
    if len(seen) != COLS * ROWS or len(PASSAGES) != COLS * ROWS - 1:
        raise ValueError("课程迷宫必须为覆盖所有格子的树形通路")
    for name, builder in (("course_maze", course_maze), ("control_arena", control_arena),
                          ("failure_loop", failure_loop)):
        root = builder()
        ET.indent(root, space="  ")
        ET.ElementTree(root).write(output / f"{name}.world", encoding="utf-8", xml_declaration=True)
    (output / "maze_layout.json").write_text(json.dumps(metadata(), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("已生成三个世界；课程迷宫连通性及离散左手规则检查通过。")


if __name__ == "__main__":
    main()
