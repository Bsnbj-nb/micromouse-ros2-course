#!/usr/bin/env python3
"""从运行记录生成汇总表；没有实测记录时不生成示例数据。"""

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import sys


SOURCE_FILES = ("trajectory.csv", "summary.json", "run_config.json")
FIELDS = [
    "run_directory", "mode", "scene", "task_completed", "goal_reached",
    "completion_time_sim_s", "startup_wait_sim_s", "path_length_odom_m",
    "minimum_valid_scan_range_m", "angular_command_total_variation",
    "samples", "stop_samples", "front_blocked_samples",
    "path_cross_track_rmse_m", "reference_path_points", "reference_path_source",
    "reference_path_hash", "parameters_hash", "comparison_group_key",
    "pp_waypoints_pair_available", "comparison_note", "clean_shutdown",
    "last_state", "last_fault", "analysis_notes",
]
TRAJECTORY_COLUMNS = {
    "sim_time", "mode", "state", "x", "y", "v_cmd", "w_cmd",
    "task_completed", "goal_reached",
}


def finite_number(value, field, optional=False, nonnegative=False):
    if value is None or value == "":
        if optional:
            return None
        raise ValueError(f"missing numeric field: {field}")
    if isinstance(value, bool):
        raise ValueError(f"boolean used as number: {field}")
    result = float(value)
    if not math.isfinite(result) or (nonnegative and result < 0):
        raise ValueError(f"invalid number in {field}")
    return result


def boolean(value, field):
    if isinstance(value, bool):
        return value
    if value in ("True", "true"):
        return True
    if value in ("False", "false"):
        return False
    raise ValueError(f"missing or invalid boolean: {field}")


def canonical_hash(value):
    encoded = json.dumps(value, sort_keys=True, ensure_ascii=False,
                         separators=(",", ":"), allow_nan=False).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def reference_path(config, mode):
    points = config.get("reference_points_task")
    source = "recorded_reference_points_task"
    if not points and mode in ("waypoints", "pure_pursuit"):
        flat = config.get("waypoints_xy", [])
        if len(flat) % 2:
            raise ValueError("waypoints_xy does not contain complete coordinate pairs")
        points = list(zip(flat[::2], flat[1::2]))
        source = "configured_waypoints_xy"
    if not points:
        return [], ""
    validated = []
    for point in points:
        if not isinstance(point, (tuple, list)) or len(point) != 2:
            raise ValueError("reference path contains a malformed point")
        validated.append([finite_number(point[0], "reference_x"),
                          finite_number(point[1], "reference_y")])
    return validated, source


def point_to_segment_distance(point, first, second):
    dx, dy = second[0] - first[0], second[1] - first[1]
    length_squared = dx * dx + dy * dy
    if length_squared <= 1e-20:
        return math.hypot(point[0] - first[0], point[1] - first[1])
    fraction = ((point[0] - first[0]) * dx + (point[1] - first[1]) * dy) / length_squared
    fraction = min(1.0, max(0.0, fraction))
    return math.hypot(point[0] - first[0] - fraction * dx,
                      point[1] - first[1] - fraction * dy)


def tracking_rows(rows):
    """剔除运行前的等待，保留运动中的停车、等待和首次完成行。"""
    active, selected = False, []
    for row in rows:
        moving = abs(row["v_cmd"]) > 1e-6 or abs(row["w_cmd"]) > 1e-6
        preparation = row["state"].startswith("WAIT_") or row["state"] == "IDLE"
        if not active and (moving or row["task_completed"] or not preparation):
            active = True
        if active:
            selected.append(row)
        if row["task_completed"]:
            break
    return selected


def cross_track_rmse(rows, points):
    if len(points) < 2 or not rows:
        return None
    # 没有发出运动命令且未完成的准备记录不能充当跟踪实验。
    if not any(abs(r["v_cmd"]) > 1e-6 or abs(r["w_cmd"]) > 1e-6
               or r["task_completed"] for r in rows):
        return None
    squared = []
    for row in rows:
        point = (row["x"], row["y"])
        error = min(point_to_segment_distance(point, a, b)
                    for a, b in zip(points[:-1], points[1:]))
        squared.append(error * error)
    return math.sqrt(sum(squared) / len(squared))


def read_run(directory):
    directory = Path(directory)
    config = json.loads((directory / "run_config.json").read_text(encoding="utf-8"))
    summary = json.loads((directory / "summary.json").read_text(encoding="utf-8"))
    if not isinstance(config, dict) or not isinstance(summary, dict):
        raise ValueError("config and summary must be JSON objects")
    mode = str(summary.get("mode", ""))
    if not mode or str(config.get("mode", mode)) != mode:
        raise ValueError("mode mismatch between config and summary")
    rows = []
    with (directory / "trajectory.csv").open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream)
        if not TRAJECTORY_COLUMNS.issubset(reader.fieldnames or []):
            raise ValueError("trajectory is missing required columns")
        for number, raw in enumerate(reader, start=2):
            if raw.get("mode") != mode:
                raise ValueError(f"trajectory row {number} has a different mode")
            parsed = dict(raw)
            for field in ("sim_time", "x", "y", "v_cmd", "w_cmd"):
                parsed[field] = finite_number(raw.get(field), field)
            for field in ("task_completed", "goal_reached"):
                parsed[field] = boolean(raw.get(field), field)
            if rows and parsed["sim_time"] < rows[-1]["sim_time"]:
                raise ValueError("trajectory simulation time moved backwards")
            rows.append(parsed)
    if not rows:
        raise ValueError("trajectory contains no samples")
    reported_samples = summary.get("samples")
    if not isinstance(reported_samples, int) or reported_samples != len(rows):
        raise ValueError("summary sample count does not match CSV; stop the run and retry")
    completed = boolean(summary.get("task_completed"), "task_completed")
    reached = boolean(summary.get("goal_reached"), "goal_reached")
    if completed != any(row["task_completed"] for row in rows):
        raise ValueError("completion status differs between summary and CSV")
    if reached != any(row["goal_reached"] for row in rows):
        raise ValueError("goal status differs between summary and CSV")
    if reached and (not completed or mode == "open_loop"):
        raise ValueError("invalid goal_reached flag for this run")
    completion = finite_number(summary.get("completion_time_sim_s"),
                               "completion_time_sim_s", optional=not completed,
                               nonnegative=True)
    notes = []
    if not completed:
        if completion is not None:
            notes.append("unfinished run: completion time was ignored")
        completion = None
    clean = boolean(summary.get("clean_shutdown"), "clean_shutdown")
    if not clean:
        notes.append("run is not marked as cleanly closed")
    points, source = reference_path(config, mode)
    path_hash = canonical_hash(points) if points else ""
    # mode 是比较对象；输出目录和坐标对齐观测不是算法参数。
    parameters = {key: value for key, value in config.items()
                  if key not in {"mode", "record", "log_directory", "alignment",
                                 "reference_points_task", "data_origin", "test_fixture"}}
    parameters_hash = canonical_hash(parameters)
    scene = str(config.get("scene", ""))
    missing_setup = [name for name in ("scene", "spawn_x", "spawn_y", "spawn_yaw",
                                      "linear_speed", "angular_speed", "position_tolerance")
                     if name not in config]
    group = ""
    if len(points) >= 2 and not missing_setup:
        group = canonical_hash({"scene": scene, "path": path_hash,
                                "parameters": parameters_hash})
    active_rows = tracking_rows(rows)
    stop_count = sum(abs(row["v_cmd"]) <= 1e-6 and abs(row["w_cmd"]) <= 1e-6
                     for row in active_rows)
    blocked_count = sum(row["state"] == "FRONT_BLOCKED" for row in active_rows)
    if missing_setup:
        notes.append("comparison metadata missing: " + ",".join(missing_setup))
    notes.append("stop counts exclude startup WAIT/IDLE; sample counts are not durations")
    return {
        "run_directory": str(directory.resolve()), "mode": mode, "scene": scene,
        "task_completed": completed, "goal_reached": reached,
        "completion_time_sim_s": completion,
        "startup_wait_sim_s": finite_number(summary.get("startup_wait_sim_s"),
                                             "startup_wait_sim_s", True, True),
        "path_length_odom_m": finite_number(summary.get("path_length_odom_m"),
                                            "path_length_odom_m", nonnegative=True),
        "minimum_valid_scan_range_m": finite_number(summary.get("minimum_valid_scan_range_m"),
                                                     "minimum_valid_scan_range_m", True, True),
        "angular_command_total_variation": finite_number(
            summary.get("angular_command_total_variation"),
            "angular_command_total_variation", nonnegative=True),
        "samples": len(rows), "stop_samples": stop_count,
        "front_blocked_samples": blocked_count,
        "path_cross_track_rmse_m": cross_track_rmse(active_rows, points),
        "reference_path_points": len(points), "reference_path_source": source,
        "reference_path_hash": path_hash, "parameters_hash": parameters_hash,
        "comparison_group_key": group, "pp_waypoints_pair_available": False,
        "comparison_note": "not paired", "clean_shutdown": clean,
        "last_state": str(summary.get("last_state", "")),
        "last_fault": str(summary.get("last_fault", "")),
        "analysis_notes": "; ".join(notes),
    }


def mark_comparison_groups(records):
    groups = {}
    for record in records:
        key = record["comparison_group_key"]
        if key and record["mode"] in ("waypoints", "pure_pursuit"):
            groups.setdefault(key, set()).add(record["mode"])
    for record in records:
        key = record["comparison_group_key"]
        if (record["mode"] in ("waypoints", "pure_pursuit") and key
                and groups.get(key) == {"waypoints", "pure_pursuit"}):
            record["pp_waypoints_pair_available"] = True
            record["comparison_note"] = (
                "same recorded scene/spawn/reference/parameters; verify world file and software versions")
        elif record["mode"] in ("waypoints", "pure_pursuit"):
            record["comparison_note"] = "no counterpart with the same recorded setup and ordered reference path"
        else:
            record["comparison_note"] = "PP/waypoints pairing does not apply to this mode"


def collect_runs(root):
    root = Path(root).expanduser()
    if not root.is_dir():
        raise ValueError(f"run root does not exist: {root}")
    records, warnings = [], []
    for directory in sorted(root.iterdir()):
        if not directory.is_dir():
            continue
        existing = [name for name in SOURCE_FILES if (directory / name).is_file()]
        if not existing:
            continue
        if len(existing) != len(SOURCE_FILES):
            warnings.append(f"{directory.name}: incomplete run files; skipped")
            continue
        try:
            records.append(read_run(directory))
        except (OSError, ValueError, TypeError, KeyError, csv.Error) as exc:
            warnings.append(f"{directory.name}: {exc}; skipped")
    if not records:
        detail = "\n".join(warnings)
        raise ValueError("No usable run records found. Run the ROS experiment first."
                         + ("\n" + detail if detail else ""))
    mark_comparison_groups(records)
    return records, warnings


def write_csv(records, destination):
    destination = Path(destination).expanduser()
    if destination.suffix.lower() != ".csv":
        raise ValueError("--out must have a .csv suffix")
    protected = {(Path(record["run_directory"]) / name).resolve()
                 for record in records for name in SOURCE_FILES}
    if destination.resolve() in protected:
        raise ValueError("refusing to overwrite a source run file")
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(destination.name + ".tmp")
    with temporary.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(records)
    temporary.replace(destination)
    return destination


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default="~/micromouse_runs", help="parent of the recorded run folders")
    parser.add_argument("--out", required=True, help="output summary CSV path")
    args = parser.parse_args(argv)
    try:
        records, warnings = collect_runs(args.root)
        destination = write_csv(records, args.out)
    except (OSError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2
    for warning in warnings:
        print(f"Warning: {warning}", file=sys.stderr)
    print(f"Saved {len(records)} recorded runs to {destination}")
    print("Unfinished runs have no completion time. Minimum scan range is not body clearance or collision count.")
    print("Cross-track RMSE is sample-based distance to the reference polyline; it does not verify waypoint order.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
