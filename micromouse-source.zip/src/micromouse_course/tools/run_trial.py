"""Run one live Gazebo experiment and retain all original evidence files."""
import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import time
import fcntl

p=argparse.ArgumentParser()
p.add_argument('name');p.add_argument('world');p.add_argument('mode')
p.add_argument('--gui',action='store_true');p.add_argument('--mapping',action='store_true')
p.add_argument('--loop',action='store_true');p.add_argument('--record',action='store_true')
p.add_argument('--map-file',default='');p.add_argument('--goal',nargs=2,type=float)
p.add_argument('--seconds',type=float,default=600.);p.add_argument('--stop-after',type=float,default=0.)
p.add_argument('--params-file',default='')
p.add_argument('--video',action='store_true')
p.add_argument('--view',choices=['Gazebo','RViz'],default='Gazebo')
p.add_argument('--model-view',action='store_true')
p.add_argument('--output-root',default=str(Path.home()/'course_results'))
a=p.parse_args()
simulation_lock=open('/tmp/micromouse_course_sim.lock','w')
fcntl.flock(simulation_lock,fcntl.LOCK_EX)
out=Path(a.output_root).expanduser()/a.name
from ament_index_python.packages import get_package_share_directory
share=Path(get_package_share_directory('micromouse_course'))
out.mkdir(parents=True,exist_ok=False)
args=['ros2','launch','micromouse_course','course.launch.py',f'world:={a.world}',f'mode:={a.mode}',
 f'gui:={str(a.gui).lower()}',f'rviz:={str(a.gui).lower()}',f'mapping:={str(a.mapping).lower()}',
 f'loop_detection:={str(a.loop).lower()}',f'log_directory:={out}',f'map_save_path:={out}/map']
if a.video:args.append('paused:=true')
if a.model_view:args.append('rviz_config:='+str(share/'rviz/model.rviz'))
if a.map_file:args.append('map_file:='+a.map_file)
config=out/'trial_params.yaml'
extra=Path(a.params_file).read_text() if a.params_file else ''
if extra:
 import yaml
 cfg=yaml.safe_load(extra)
else:cfg={}
cfg.setdefault('course_controller',{}).setdefault('ros__parameters',{})['max_run_seconds']=a.seconds
import yaml
config.write_text(yaml.safe_dump(cfg))
args.append('params_file:='+str(config))
(out/'launch_command.json').write_text(json.dumps(args,indent=2))
log=(out/'launch.log').open('w')
launch=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(out/'launch.pid').write_text(str(launch.pid))
bag=None;video=None
inhibitor=None
if a.video:
 inhibitor=subprocess.Popen(['gnome-session-inhibit','--inhibit','idle','--reason','Course experiment recording','--inhibit-only'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
if a.record:
 baglog=(out/'bag.log').open('w')
 qos=str(share/'config/bag_qos.yaml')
 bag=subprocess.Popen(['ros2','bag','record','-o',str(out/'bag'),'--qos-profile-overrides-path',qos,
  '/clock','/scan','/odom','/tf','/tf_static','/cmd_vel','/controller_state','/scan_sectors',
  '/planned_path','/planner_status','/task_alignment','/map','/gazebo/model_states'],stdout=baglog,stderr=subprocess.STDOUT,start_new_session=True)
start=time.monotonic(); sent=False; unpaused=False; reason='wall_clock_timeout'; latest={}
try:
 while time.monotonic()-start<max(180.,a.seconds*3+90):
  if launch.poll() is not None:reason='launch_exited';break
  if a.video and video is None and time.monotonic()-start>5:
   vl=(out/'video_capture.log').open('w')
   video=subprocess.Popen(['/usr/bin/python3',str(Path(__file__).with_name('record_gnome.py')),str(out/'screen.webm')],
      stdin=subprocess.PIPE,stdout=vl,stderr=subprocess.STDOUT,start_new_session=True)
  if a.video and not unpaused and time.monotonic()-start>15:
   if video is None or video.poll() is not None:
    raise RuntimeError('GNOME recording failed before motion; inspect video_capture.log')
   if not (out/'screen.webm').exists():
    if time.monotonic()-start>30:raise RuntimeError('GNOME recording did not create a video file')
    time.sleep(.2)
    continue
   subprocess.run(['wmctrl','-r',a.view,'-b','add,maximized_vert,maximized_horz'],check=False)
   subprocess.run(['wmctrl','-a',a.view],check=False)
   with (out/'unpause.log').open('w') as ul:
    subprocess.run(['ros2','service','call','/unpause_physics','std_srvs/srv/Empty','{}'],stdout=ul,stderr=subprocess.STDOUT,timeout=30)
   unpaused=True
  summaries=sorted(out.glob('*/summary.json'))
  if summaries:
   try:latest=json.loads(summaries[-1].read_text())
   except (OSError,json.JSONDecodeError):latest={}
   if latest.get('task_completed'):reason='task_completed';break
   if latest.get('last_state') in ['FAULT','ERROR','TIMEOUT','LOOP_DETECTED']:
    reason=latest['last_state'];break
   if a.stop_after:
    csvpath=summaries[-1].with_name('trajectory.csv')
    import csv
    with csvpath.open() as f: rows=list(csv.DictReader(f))
    if rows and float(rows[-1]['elapsed_sim'])>=a.stop_after:reason='requested_observation_duration';break
  if a.goal and not sent and time.monotonic()-start>12 and (not a.video or unpaused):
   with (out/'goal_sender.log').open('w') as gl:
    sender=subprocess.run(['ros2','run','micromouse_course','send_goal','--ros-args','-p',f'x:={a.goal[0]}','-p',f'y:={a.goal[1]}','-p','use_sim_time:=true'],stdout=gl,stderr=subprocess.STDOUT,timeout=30)
   sent=sender.returncode==0
  time.sleep(1)
 if a.mapping:
  with (out/'save_map.log').open('w') as sl:
   try:subprocess.run(['ros2','service','call','/save_map','std_srvs/srv/Trigger','{}'],stdout=sl,stderr=subprocess.STDOUT,timeout=15)
   except subprocess.TimeoutExpired:sl.write('save_map timeout\n')
 time.sleep(1)
except Exception as error:
 reason='runner_error: '+str(error)
 raise
finally:
 if video is not None and video.poll() is None:
  video.communicate(input=b'\n',timeout=10)
 if inhibitor is not None:
  inhibitor.terminate()
  inhibitor.wait(timeout=5)
 for process in [bag,launch]:
  if process is None:continue
  if process.poll() is None:
   # ROS launch relays SIGINT to its own children; signalling the group here
   # would deliver a second interrupt during node cleanup.
   process.send_signal(signal.SIGINT)
   try:process.wait(timeout=12)
   except subprocess.TimeoutExpired:
    os.killpg(process.pid,signal.SIGTERM)
    try:process.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL)
 log.close()
 summaries=sorted(out.glob('*/summary.json'))
 if summaries:
  try:latest=json.loads(summaries[-1].read_text())
  except (OSError,json.JSONDecodeError):pass
 (out/'runner.json').write_text(json.dumps({'reason':reason,'wall_seconds':time.monotonic()-start,'last_summary':latest},indent=2))
