#!/usr/bin/env python3
"""用二维射线和运动学检查控制器与墙体几何，不代替 Gazebo 实验。

模型没有轮胎打滑、惯性、碰撞求解、传感器噪声及 ROS 消息延迟。
该输出只用于代码回归，不能作为报告中的本人仿真实测数据。
"""

import argparse
import json
import math
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

import numpy as np

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE_ROOT))

from micromouse_course.core import Pose2D, WallConfig, WallFollower, extract_sectors, wrap_angle


def load_wall_boxes(world_file):
    """读取 world 中的轴对齐墙体碰撞盒，不读取 visual 代替 collision。"""
    root = ET.parse(world_file).getroot()
    result = []
    for model in root.findall("./world/model"):
        if not model.get("name", "").startswith("wall_"):
            continue
        pose = [float(value) for value in model.findtext("pose").split()]
        if any(abs(value) > 1e-9 for value in pose[3:]):
            raise ValueError("geometry check only supports axis-aligned walls")
        for collision in model.findall("./link/collision"):
            size = collision.findtext("./geometry/box/size")
            if size is None:
                raise ValueError("a wall collision is not a box")
            sx, sy, _ = [float(value) for value in size.split()]
            result.append((pose[0] - sx / 2, pose[0] + sx / 2,
                           pose[1] - sy / 2, pose[1] + sy / 2))
    if not result:
        raise ValueError("the world contains no wall collision boxes")
    return np.asarray(result, dtype=float)


def raycast_sectors(pose, boxes, laser_x=-0.032):
    angles = np.arange(360, dtype=float) * math.pi / 180.0
    origin = np.array([pose.x + laser_x * math.cos(pose.yaw),
                       pose.y + laser_x * math.sin(pose.yaw)])
    direction = np.stack([np.cos(angles + pose.yaw), np.sin(angles + pose.yaw)], axis=1)
    direction[np.abs(direction) < 1e-12] = 1e-12
    ta = (boxes[None, :, [0, 2]] - origin) / direction[:, None, :]
    tb = (boxes[None, :, [1, 3]] - origin) / direction[:, None, :]
    near = np.minimum(ta, tb).max(axis=2)
    far = np.maximum(ta, tb).min(axis=2)
    hits = np.where((near <= far) & (far > 0), np.maximum(near, 0), np.inf).min(axis=1)
    hits[hits > 3.5] = np.inf
    hits[hits < 0.12] = np.nan
    return extract_sectors(hits.tolist(), 0.0, math.pi / 180.0, 0.12, 3.5)


def center_wall_distance(pose, boxes):
    dx = np.maximum(np.maximum(boxes[:, 0] - pose.x, 0), pose.x - boxes[:, 1])
    dy = np.maximum(np.maximum(boxes[:, 2] - pose.y, 0), pose.y - boxes[:, 3])
    return float(np.sqrt(dx * dx + dy * dy).min())


def integrate(pose, command, dt):
    velocity, angular = command.linear, command.angular
    new_yaw = pose.yaw + angular * dt
    if abs(angular) < 1e-10:
        x = pose.x + velocity * math.cos(pose.yaw) * dt
        y = pose.y + velocity * math.sin(pose.yaw) * dt
    else:
        x = pose.x + velocity / angular * (math.sin(new_yaw) - math.sin(pose.yaw))
        y = pose.y - velocity / angular * (math.cos(new_yaw) - math.cos(pose.yaw))
    return Pose2D(x, y, wrap_angle(new_yaw))


def run_case(adaptive=False, max_seconds=300.0, dt=0.05, scan_period=0.2):
    boxes = load_wall_boxes(PACKAGE_ROOT / "worlds" / "course_maze.world")
    metadata = json.loads((PACKAGE_ROOT / "worlds" / "maze_layout.json").read_text(encoding="utf-8"))
    spawn = metadata["spawn"]
    exit_region = metadata["exit"]["region"]
    pose = Pose2D(spawn["x"], spawn["y"], spawn["yaw"])
    controller = WallFollower(WallConfig(adaptive=adaptive))
    transitions = []
    previous_state = None
    robot_radius = 0.14
    minimum_distance = math.inf
    outcome = "TIME_LIMIT"
    now = 0.0
    scan_stamp = -math.inf
    reading = None
    for index in range(int(max_seconds / dt) + 1):
        now = index * dt
        if now - scan_stamp >= scan_period - 1e-9:
            reading = raycast_sectors(pose, boxes)
            scan_stamp = now
        result = controller.update(pose, reading, now, scan_stamp=scan_stamp)
        nearest = center_wall_distance(pose, boxes)
        minimum_distance = min(minimum_distance, nearest)
        if result.state != previous_state:
            transitions.append({"time": round(now, 3), "state": result.state,
                                "x": round(pose.x, 4), "y": round(pose.y, 4)})
            previous_state = result.state
        if result.fault:
            outcome = "CONTROLLER_FAULT: " + result.fault
            break
        if nearest < robot_radius:
            outcome = "DISC_COLLISION"
            break
        if (exit_region[0] <= pose.x <= exit_region[1]
                and exit_region[2] <= pose.y <= exit_region[3]):
            outcome = "REACHED_EXIT"
            break
        pose = integrate(pose, result.command, dt)
    return {
        "model": "ideal_2d_geometry_not_gazebo",
        "strategy": "adaptive" if adaptive else "baseline",
        "outcome": outcome,
        "integration_step_s": dt,
        "scan_period_s": scan_period,
        "model_time_s": round(now, 3),
        "robot_disc_radius_m": robot_radius,
        "minimum_center_to_wall_m": round(minimum_distance, 6),
        "minimum_disc_clearance_m": round(minimum_distance - robot_radius, 6),
        "final_pose": vars(pose),
        "state_transitions": transitions,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--strategy", choices=("baseline", "adaptive", "both"), default="both")
    parser.add_argument("--scan-period", type=float, default=0.2)
    args = parser.parse_args()
    flags = (False, True) if args.strategy == "both" else (args.strategy == "adaptive",)
    if not math.isfinite(args.scan_period) or args.scan_period <= 0:
        parser.error("scan-period must be finite and positive")
    results = [run_case(adaptive=flag, scan_period=args.scan_period) for flag in flags]
    print(json.dumps(results, ensure_ascii=False, indent=2))
    return 0 if all(result["outcome"] == "REACHED_EXIT" for result in results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
