from glob import glob
from setuptools import find_packages, setup

package_name = "micromouse_course"

data_files = [
    ("share/ament_index/resource_index/packages", ["resource/" + package_name]),
    ("share/" + package_name, ["package.xml", "readme.md", "NOTICE.md", "LICENSE"]),
]
for directory in ("launch", "config", "worlds", "rviz", "scripts", "tools", "docs", "urdf"):
    files = [path for path in glob(directory + "/*") if not path.endswith("__pycache__")]
    if files:
        data_files.append(("share/" + package_name + "/" + directory, files))

setup(
    name=package_name, version="0.1.0",
    packages=find_packages(exclude=["test"]), data_files=data_files,
    install_requires=["setuptools"], zip_safe=True,
    maintainer="Xiang Haoxuan and Yang Sheng", maintainer_email="Bsnbj-nb@users.noreply.github.com",
    description="ROS2 Humble 地老鼠走迷宫课程开发工程",
    license="MIT", tests_require=["pytest"],
    entry_points={"console_scripts": [
        "course_controller = micromouse_course.controller_node:main",
        "mapping_node = micromouse_course.mapping_node:main",
        "planner_node = micromouse_course.planner_node:main",
        "send_goal = micromouse_course.send_goal:main",
        "course_keyboard = micromouse_course.teleop_node:main",
        "truth_recorder = micromouse_course.truth_recorder:main",
    ]},
)
