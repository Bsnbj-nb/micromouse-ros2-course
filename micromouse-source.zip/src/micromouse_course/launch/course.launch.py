"""一次启动仿真、官方 Burger 模型、显示和课程节点。"""

import json
import os
from pathlib import Path
import xml.etree.ElementTree as ET
import xacro

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (DeclareLaunchArgument, IncludeLaunchDescription,
                            OpaqueFunction, SetEnvironmentVariable)
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def as_bool(text):
    if text.lower() not in ("true", "false"):
        raise ValueError("boolean launch argument must be true or false")
    return text.lower() == "true"


def setup(context):
    share = Path(get_package_share_directory("micromouse_course"))
    gazebo = Path(get_package_share_directory("gazebo_ros"))
    tb3 = Path(get_package_share_directory("turtlebot3_gazebo"))
    description = Path(get_package_share_directory("turtlebot3_description"))
    value = lambda name: LaunchConfiguration(name).perform(context)
    world_name, mode = value("world"), value("mode")
    if world_name not in ("course_maze", "control_arena", "failure_loop"):
        raise ValueError("world must be course_maze, control_arena or failure_loop")
    if mode not in ("idle", "manual", "open_loop", "point", "waypoints", "avoid",
                    "wall_basic", "wall_adaptive", "pure_pursuit", "global"):
        raise ValueError("unsupported mode")
    map_file = os.path.expanduser(value("map_file"))
    mapping = as_bool(value("mapping"))
    planning = mode == "global" or as_bool(value("planning"))
    if map_file and not planning:
        raise ValueError("map_file requires planning:=true or mode:=global")
    if map_file and mapping:
        raise ValueError("saved map and live mapper cannot both publish /map; set mapping:=false")
    if planning and not map_file and not mapping:
        raise ValueError("planning needs map_file:=... or mapping:=true")
    if map_file and not Path(map_file).is_file():
        raise FileNotFoundError("map_file does not exist: " + map_file)
    layout = json.loads((share / "worlds/maze_layout.json").read_text(encoding="utf-8"))
    spawn = layout["failure_loop_spawn"] if world_name == "failure_loop" else layout["spawn"]
    region = layout["failure_loop_exit_region"] if world_name == "failure_loop" else layout["exit"]["region"]
    candidates = [tb3 / "urdf/turtlebot3_burger.urdf", description / "urdf/turtlebot3_burger.urdf"]
    urdf = next((p for p in candidates if p.is_file()), None)
    if urdf is None:
        raise FileNotFoundError("Humble Burger URDF missing; run scripts/preflight.sh")
    # Humble package 2.3.6 retains ${namespace} in its .urdf file.
    # Expand the installed official model before publishing frame names.
    robot_xml = xacro.process_file(str(share / "urdf/burger.urdf.xacro"), mappings={"namespace": ""}).toxml()
    if ET.fromstring(robot_xml).tag != "robot":
        raise ValueError("robot_description must contain a URDF robot")
    sdf_file = tb3 / "models/turtlebot3_burger/model.sdf"
    sdf = ET.parse(sdf_file)
    plugins = [p.get("filename", "") for p in sdf.findall(".//plugin")]
    if not any("gazebo_ros_diff_drive" in p for p in plugins):
        raise ValueError("Burger SDF is not Gazebo Classic; install the Humble version")
    existing = os.environ.get("GAZEBO_MODEL_PATH", "")
    model_path = str(tb3 / "models") + (os.pathsep + existing if existing else "")
    common = {"use_sim_time": True}
    config = str(share / "config/course.yaml")
    controller_params = dict(common, mode=mode, scene=world_name,
                             spawn_x=float(spawn["x"]), spawn_y=float(spawn["y"]),
                             spawn_yaw=float(spawn["yaw"]), exit_region=[float(v) for v in region],
                             exit_enabled=world_name != "control_arena",
                             loop_detection=as_bool(value("loop_detection")),
                             log_directory=os.path.expanduser(value("log_directory")))
    optional = value("params_file")
    files = [config] + ([os.path.expanduser(optional)] if optional else [])
    actions = [
        SetEnvironmentVariable("TURTLEBOT3_MODEL", "burger"),
        SetEnvironmentVariable("GAZEBO_MODEL_PATH", model_path),
        # 所有场景均为本地几何，禁止 Gazebo 启动时等待模型数据库。
        SetEnvironmentVariable("GAZEBO_MODEL_DATABASE_URI", ""),
        IncludeLaunchDescription(PythonLaunchDescriptionSource(str(gazebo / "launch/gzserver.launch.py")),
                                 launch_arguments={"world": str(share / "worlds" / (world_name + ".world")),
                                                   "verbose": "false", "pause": value("paused")}.items()),
        IncludeLaunchDescription(PythonLaunchDescriptionSource(str(gazebo / "launch/gzclient.launch.py")),
                                 condition=IfCondition(LaunchConfiguration("gui"))),
        Node(package="robot_state_publisher", executable="robot_state_publisher", output="screen",
             parameters=[dict(common, robot_description=robot_xml)]),
        Node(package="gazebo_ros", executable="spawn_entity.py", output="screen",
             arguments=["-entity", "burger", "-file", str(sdf_file), "-x", str(spawn["x"]),
                        "-y", str(spawn["y"]), "-z", "0.01", "-Y", str(spawn["yaw"]),
                        "-timeout", "90.0"]),
        Node(package="micromouse_course", executable="course_controller", name="course_controller",
             output="screen", parameters=files + [controller_params],
             condition=IfCondition(LaunchConfiguration("controller"))),
        Node(package="micromouse_course", executable="truth_recorder", name="truth_recorder", output="screen",
             parameters=[dict(common, output_directory=os.path.expanduser(value("log_directory")))]),
        Node(package="rviz2", executable="rviz2", output="screen",
             arguments=["-d", os.path.expanduser(value("rviz_config")) or str(share / "rviz/course.rviz")], parameters=[common],
             condition=IfCondition(LaunchConfiguration("rviz"))),
    ]
    if mapping:
        actions.append(Node(package="micromouse_course", executable="mapping_node", name="grid_mapper",
                            output="screen", parameters=files + [dict(common,
                                save_path=os.path.expanduser(value("map_save_path")))]))
    if planning:
        actions.append(Node(package="micromouse_course", executable="planner_node", name="grid_planner",
                            output="screen", parameters=files + [dict(common, map_file=map_file,
                                                                        use_live_map=not bool(map_file))]))
    return actions


def generate_launch_description():
    defaults = {
        "world": ("course_maze", "course_maze | control_arena | failure_loop"),
        "mode": ("idle", "idle | manual | open_loop | point | waypoints | avoid | wall_basic | wall_adaptive | pure_pursuit | global"),
        "gui": ("true", "Start the Gazebo window"), "rviz": ("true", "Start RViz2"),
        "paused": ("false", "Start physics paused for a complete recorded demonstration"),
        "rviz_config": ("", "Optional RViz configuration; empty selects the course view"),
        "controller": ("true", "Enable the only motion controller; false is for isolated collision verification"),
        "mapping": ("false", "Build an odometry-based occupancy grid from scan"),
        "planning": ("false", "Start A* planner; global mode enables it automatically"),
        "map_file": ("", "Saved occupancy JSON; requires mapping:=false"),
        "map_save_path": ("~/micromouse_runs/map", "Map output base path"),
        "params_file": ("", "Optional YAML parameter overrides"),
        "log_directory": ("~/micromouse_runs", "Directory for per-run records"),
        "loop_detection": ("false", "Stop after repeated position and heading visits"),
    }
    return LaunchDescription([DeclareLaunchArgument(name, default_value=value, description=description)
                              for name, (value, description) in defaults.items()] + [OpaqueFunction(function=setup)])
