#!/usr/bin/env bash
set -eo pipefail
python3 - <<'PY'
from datetime import datetime, timezone
import platform
print('记录时间 UTC:', datetime.now(timezone.utc).isoformat())
print('系统:', platform.platform())
print('Python:', platform.python_version())
PY
if command -v lsb_release >/dev/null 2>&1; then lsb_release -ds; fi
if command -v gazebo >/dev/null 2>&1; then gazebo --version; fi
if command -v ros2 >/dev/null 2>&1; then
  for package in gazebo_ros turtlebot3_gazebo turtlebot3_description micromouse_course; do
    printf '\n%s\n' "$package"
    ros2 pkg prefix "$package" || true
  done
fi
if command -v dpkg-query >/dev/null 2>&1; then
  dpkg-query -W -f='${Package}\t${Version}\n' \
    ros-humble-rclpy ros-humble-gazebo-ros-pkgs ros-humble-turtlebot3-gazebo \
    ros-humble-turtlebot3-description python3-numpy 2>/dev/null || true
fi
