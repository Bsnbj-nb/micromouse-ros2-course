#!/usr/bin/env bash
set -euo pipefail
label="${1:-run}"
if [[ ! "$label" =~ ^[A-Za-z0-9_-]+$ ]]; then
  echo '实验标识仅使用英文字母、数字、下划线、短横线。' >&2
  exit 1
fi
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
package_dir="$(cd -- "$script_dir/.." && pwd)"
record_dir="$HOME/micromouse_runs/evidence/$(date +%Y%m%d_%H%M%S)_${label}"
mkdir -p "$record_dir"
printf '录制目录：%s\n按 Ctrl+C 完成录制；rosbag 不是演示视频。\n' "$record_dir"
ros2 bag record --qos-profile-overrides-path "$package_dir/config/bag_qos.yaml" \
  -o "$record_dir/bag" /clock /odom /scan /tf /tf_static /cmd_vel \
  /controller_state /scan_sectors /planned_path /map /task_alignment
