#!/usr/bin/env bash
set -eo pipefail
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
package_dir="$(cd -- "$script_dir/.." && pwd)"
workspace_dir="$(cd -- "$package_dir/../.." && pwd)"
if [[ ! -f /opt/ros/humble/setup.bash ]]; then
  echo '未找到 /opt/ros/humble/setup.bash，请先完成 Humble 环境安装。' >&2
  exit 1
fi
source /opt/ros/humble/setup.bash
cd "$workspace_dir"
colcon build --symlink-install --packages-select micromouse_course
printf '\n编译结束。本终端还需执行：\nsource "%s/install/setup.bash"\n' "$workspace_dir"
