#!/usr/bin/env bash
set -euo pipefail
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
package_dir="$(cd -- "$script_dir/.." && pwd)"
export PYTHONPATH="$package_dir${PYTHONPATH:+:$PYTHONPATH}"
python3 - "$package_dir" <<'PY'
import ast
from pathlib import Path
import sys
root = Path(sys.argv[1])
paths = sorted(root.rglob('*.py'))
for path in paths:
    if '__pycache__' not in path.parts:
        ast.parse(path.read_text(encoding='utf-8'), filename=str(path), feature_version=(3, 10))
print('Python 3.10 语法检查通过，文件数：', len(paths))
PY
for script in "$script_dir"/*.sh; do
  bash -n "$script"
done
python3 -m unittest discover -s "$package_dir/test" -p 'test_*.py' -v
printf '\n以上为源代码与算法检查，ROS2/Gazebo 实测按执行手册完成。\n'
