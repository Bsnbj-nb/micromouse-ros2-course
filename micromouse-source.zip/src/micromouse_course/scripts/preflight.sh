#!/usr/bin/env bash
# 只检查依赖和模型文件，不安装软件，不修改环境配置。
set -u

if ! command -v python3 >/dev/null 2>&1; then
    printf '[FAIL] 没有找到 python3。请先检查 Ubuntu 和 ROS2 安装。\n'
    exit 1
fi

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
python3 - "$script_dir/.." <<'PY'
import importlib
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET


errors = []
warnings = []
package_dir = Path(sys.argv[1]).resolve()


def report(level, message):
    print(f'[{level}] {message}')
    if level == 'FAIL':
        errors.append(message)
    elif level == 'WARN':
        warnings.append(message)


def checked_xml(path, label):
    if not path.is_file():
        report('FAIL', f'{label} 不存在：{path}')
        return None
    try:
        return ET.parse(path).getroot()
    except (ET.ParseError, OSError) as exc:
        report('FAIL', f'{label} 不能解析：{exc}')
        return None


print('机器人感知与控制综合实践 环境检查')
print(f'当前 Python：{sys.executable}')
release = {}
release_path = Path('/etc/os-release')
if release_path.is_file():
    for line in release_path.read_text(encoding='utf-8').splitlines():
        if '=' in line and not line.startswith('#'):
            key, value = line.split('=', 1)
            release[key] = value.strip('"')
if release.get('ID') == 'ubuntu' and release.get('VERSION_ID') == '22.04':
    report('PASS', 'Ubuntu 22.04')
else:
    report('FAIL', f'本项目固定 Ubuntu 22.04；当前为 {release.get("PRETTY_NAME", "未知系统")}')

if os.environ.get('ROS_DISTRO') == 'humble':
    report('PASS', 'ROS_DISTRO=humble')
else:
    report('FAIL', '当前未加载 ROS2 Humble；先执行 source /opt/ros/humble/setup.bash')
for command in ('ros2', 'colcon', 'gazebo', 'gzserver'):
    location = shutil.which(command)
    report('PASS' if location else 'FAIL', f'{command}：{location or "未找到"}')

if shutil.which('gazebo'):
    try:
        result = subprocess.run(['gazebo', '--version'], text=True, capture_output=True, timeout=10)
        text = (result.stdout + result.stderr).strip()
        # Gazebo Classic's version-only path can return nonzero even when it
        # prints a valid version; inspect the version banner, not that status.
        if re.search(r'^Gazebo multi-robot simulator, version\s+11(?:\.|\s|$)', text, re.I | re.M):
            report('PASS', text.splitlines()[0])
            report('INFO', f'gazebo --version exit status: {result.returncode}')
        else:
            report('FAIL', f'需要 Gazebo Classic 11；检测输出：{text[:300]}')
    except (OSError, subprocess.TimeoutExpired) as exc:
        report('FAIL', f'读取 Gazebo 版本失败：{exc}')

for module in ('rclpy', 'yaml', 'numpy', 'ament_index_python', 'xacro'):
    try:
        importlib.import_module(module)
    except (ImportError, OSError, RuntimeError) as exc:
        report('FAIL', f'Python 模块 {module} 无法导入：{exc}')
    else:
        report('PASS', f'Python 模块 {module} 可导入')

share_dirs = {}
try:
    from ament_index_python.packages import PackageNotFoundError, get_package_share_directory
except ImportError:
    report('FAIL', '无法读取 ROS2 包索引；检查是否误用 Conda Python，或是否遗漏 source 命令')
else:
    names = ('gazebo_ros', 'gazebo_plugins', 'gazebo_msgs', 'xacro', 'turtlebot3_gazebo', 'turtlebot3_description',
             'turtlebot3_msgs', 'robot_state_publisher', 'rviz2', 'tf2_ros', 'nav_msgs',
             'sensor_msgs', 'geometry_msgs', 'std_msgs', 'std_srvs')
    for name in names:
        try:
            share_dirs[name] = Path(get_package_share_directory(name))
            report('PASS', f'ROS2 包 {name}')
        except PackageNotFoundError:
            report('FAIL', f'缺少 ROS2 包 {name}')

if 'turtlebot3_gazebo' in share_dirs:
    tb3_share = share_dirs['turtlebot3_gazebo']
    sdf_path = tb3_share / 'models/turtlebot3_burger/model.sdf'
    sdf = checked_xml(sdf_path, 'Burger SDF')
    if sdf is not None:
        print(f'官方物理模型：{sdf_path}')
        plugins = {p.attrib.get('filename', ''): p for p in sdf.findall('.//plugin')}
        expected_plugins = ('libgazebo_ros_diff_drive.so', 'libgazebo_ros_ray_sensor.so',
                            'libgazebo_ros_joint_state_publisher.so')
        for name in expected_plugins:
            report('PASS' if name in plugins else 'FAIL', f'SDF 插件 {name}')
        if any('gz-sim-' in name for name in plugins):
            report('FAIL', '当前 SDF 使用 Gazebo Sim 插件；请使用 turtlebot3_simulations 的 humble 分支')
        diff = plugins.get('libgazebo_ros_diff_drive.so')
        if diff is not None:
            for tag, expected in (('odometry_frame', 'odom'), ('robot_base_frame', 'base_footprint')):
                value = (diff.findtext(tag) or '').strip()
                report('PASS' if value == expected else 'FAIL', f'{tag}={value or "未显式设置"}，要求 {expected}')
            source = diff.findtext('odometry_source')
            report('INFO', f'SDF odometry_source={source.strip() if source else "未显式设置"}')
            report('INFO', '世界坐标与 odom 的关系以 launch 所用模型和首次里程计读数为准。')
            for tag in ('publish_odom', 'publish_odom_tf'):
                value = (diff.findtext(tag) or '').strip().lower()
                report('PASS' if value in ('true', '1') else 'FAIL', f'{tag}={value or "未显式设置"}')
        ray = plugins.get('libgazebo_ros_ray_sensor.so')
        if ray is not None:
            frame = (ray.findtext('frame_name') or '').strip()
            report('PASS' if frame == 'base_scan' else 'FAIL', f'激光坐标系={frame or "未显式设置"}，要求 base_scan')
        for sensor in sdf.findall('.//sensor'):
            if sensor.attrib.get('type') in ('ray', 'gpu_ray'):
                rate = sensor.findtext('update_rate') or '未显式设置'
                lower = sensor.findtext('ray/range/min') or '未显式设置'
                upper = sensor.findtext('ray/range/max') or '未显式设置'
                report('INFO', f'激光传感器 {sensor.attrib.get("name", "")}：{rate} Hz，量程 {lower} 至 {upper} m')
                report('INFO', '控制定时器频率不等于扫描频率；新扫描到达前，控制器会持有上一帧数据。')
        missing_meshes = []
        for uri in sdf.findall('.//mesh/uri'):
            address = (uri.text or '').strip()
            if address.startswith('model://'):
                resolved = tb3_share / 'models' / address[len('model://'):]
                if not resolved.is_file():
                    missing_meshes.append(str(resolved))
        if missing_meshes:
            for name in sorted(set(missing_meshes)):
                report('FAIL', f'SDF 网格文件缺失：{name}')
        else:
            report('PASS', 'Burger SDF 引用的本地 model:// 网格文件齐全')

    # Match launch: the installed Humble model contains Xacro expressions.
    # Checking its raw XML names would falsely report missing links.
    urdf_path = package_dir / 'urdf/burger.urdf.xacro'
    urdf = None
    try:
        import xacro
        urdf = ET.fromstring(xacro.process_file(str(urdf_path), mappings={'namespace': ''}).toxml())
    except Exception as exc:
        report('FAIL', f'Burger Xacro 展开失败：{exc}')
    if urdf is not None:
        print(f'官方运动学模型：{urdf_path}')
        report('PASS' if urdf.tag == 'robot' else 'FAIL', f'URDF 根标签为 {urdf.tag}')
        links = {link.attrib.get('name', '') for link in urdf.findall('link')}
        for name in ('base_footprint', 'base_link', 'base_scan', 'wheel_left_link', 'wheel_right_link'):
            report('PASS' if name in links else 'FAIL', f'URDF link {name}')
        for tag in ('joint', 'link/visual', 'link/collision', 'link/inertial'):
            count = len(urdf.findall(tag))
            report('PASS' if count else 'FAIL', f'URDF {tag} 数量：{count}')
        for joint in urdf.findall('joint'):
            parent = joint.find('parent')
            child = joint.find('child')
            if (parent is None or child is None or parent.attrib.get('link') not in links
                    or child.attrib.get('link') not in links):
                report('FAIL', f'URDF joint {joint.attrib.get("name", "")} 的父子 link 不完整')
        missing_meshes = []
        for mesh in urdf.findall('.//mesh'):
            address = mesh.attrib.get('filename', '')
            if address.startswith('package://'):
                relative = address[len('package://'):]
                owner, separator, tail = relative.partition('/')
                try:
                    resolved = Path(get_package_share_directory(owner)) / tail
                except PackageNotFoundError:
                    missing_meshes.append(address)
                    continue
                if not separator or not resolved.is_file():
                    missing_meshes.append(address)
        if missing_meshes:
            for address in sorted(set(missing_meshes)):
                report('FAIL', f'URDF 网格资源缺失：{address}')
        else:
            report('PASS', 'Burger URDF 引用的 package:// 网格文件齐全')

for name in ('course_maze', 'control_arena', 'failure_loop'):
    root = checked_xml(package_dir / 'worlds' / f'{name}.world', f'{name} 世界')
    if root is not None:
        report('PASS' if root.tag == 'sdf' else 'FAIL', f'{name}.world 可解析')

print(f'检查结束：{len(errors)} 项失败，{len(warnings)} 项提醒。')
if errors:
    print('按失败条目修复环境，再重新运行本脚本；本脚本没有安装或修改任何软件。')
else:
    print('静态环境检查通过；仍需启动仿真并实测 /clock、/odom、/scan、TF 和碰撞行为。')
sys.exit(1 if errors else 0)
PY
