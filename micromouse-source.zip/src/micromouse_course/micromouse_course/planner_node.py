"""在实测占据栅格上规划，发布路径，不直接控制机器人速度。"""

import json
import math

import rclpy
from rclpy.node import Node
from rclpy.executors import ExternalShutdownException
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy, qos_profile_sensor_data
from geometry_msgs.msg import PoseStamped
from nav_msgs.msg import OccupancyGrid, Odometry, Path
from std_msgs.msg import String
from std_srvs.srv import Trigger

from micromouse_course.grid import GridSpec, astar_plan, load_grid


class PlannerNode(Node):
    def __init__(self):
        super().__init__("planner_node")
        self.declare_parameter("map_file", "")
        self.map_file = str(self.get_parameter("map_file").value)
        defaults = {
            "frame_id": "odom", "use_live_map": not bool(self.map_file),
            "goal_x": 0.0, "goal_y": 0.0, "auto_goal": False,
            "inflation_radius": 0.22, "allow_unknown": False,
            "occupied_threshold": 65, "free_threshold": 35, "odom_max_age": 1.0,
        }
        for name, value in defaults.items():
            self.declare_parameter(name, value)
        get = lambda name: self.get_parameter(name).value
        self.frame_id = str(get("frame_id"))
        self.use_live_map = bool(get("use_live_map"))
        if self.map_file and self.use_live_map:
            raise ValueError("map_file requires use_live_map:=false to prevent map replacement")
        self.inflation = float(get("inflation_radius"))
        self.allow_unknown = bool(get("allow_unknown"))
        self.occupied_threshold = int(get("occupied_threshold"))
        self.free_threshold = int(get("free_threshold"))
        self.odom_max_age = float(get("odom_max_age"))
        if (not math.isfinite(self.inflation) or self.inflation < 0
                or not math.isfinite(self.odom_max_age) or self.odom_max_age <= 0
                or not 0 <= self.free_threshold < self.occupied_threshold <= 100):
            raise ValueError("invalid planning thresholds or odom_max_age")
        self.spec, self.data, self.robot_xy = None, None, None
        self.odom_stamp_ns = None
        self.goal_xy = None
        self.pending = False
        self.last_status = None
        self.map_load_stamp = None
        self.saved_map_publisher = None
        self.saved_map_timer = None
        latched = QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL,
                             reliability=ReliabilityPolicy.RELIABLE)
        self.path_publisher = self.create_publisher(Path, "/planned_path", latched)
        self.status_publisher = self.create_publisher(String, "/planner_status", latched)
        self.odom_subscription = self.create_subscription(
            Odometry, "/odom", self._on_odom, qos_profile_sensor_data)
        self.goal_subscription = self.create_subscription(
            PoseStamped, "/goal_pose", self._on_goal, 10)
        self.replan_service = self.create_service(Trigger, "/replan", self._replan)
        self.map_subscription = None
        if self.use_live_map:
            self.map_subscription = self.create_subscription(
                OccupancyGrid, "/map", self._on_map, latched)
        elif self.map_file:
            self.spec, self.data, _ = load_grid(self.map_file)
            if self.spec.frame_id != self.frame_id:
                raise ValueError("saved map frame does not match frame_id")
            self.saved_map_publisher = self.create_publisher(OccupancyGrid, "/map", latched)
            self.saved_map_timer = self.create_timer(1.0, self._publish_saved_map)
            self.get_logger().warning(
                "Loaded an odom map: restart with the same world, robot spawn pose, and odom origin.")
        else:
            raise ValueError("enable use_live_map or provide map_file")
        if bool(get("auto_goal")):
            self.goal_xy = (float(get("goal_x")), float(get("goal_y")))
            if not all(math.isfinite(v) for v in self.goal_xy):
                raise ValueError("goal coordinates must be finite")
            self.pending = True
        self._clear_path()
        self._status("WAITING", "Waiting for a goal, map, and odometry.")
        self.timer = self.create_timer(0.5, self._try_plan)

    def _status(self, state, message, **extra):
        payload = {"state": state, "message": message, "frame_id": self.frame_id,
                   "goal": self.goal_xy, **extra}
        text = json.dumps(payload, ensure_ascii=False)
        if text != self.last_status:
            self.status_publisher.publish(String(data=text))
            self.get_logger().info(f"{state}: {message}")
            self.last_status = text

    def _clear_path(self):
        message = Path()
        message.header.frame_id = self.frame_id
        message.header.stamp = self.get_clock().now().to_msg()
        self.path_publisher.publish(message)

    def _on_map(self, message):
        try:
            if message.header.frame_id != self.frame_id:
                raise ValueError(f"map frame must be {self.frame_id}")
            q = message.info.origin.orientation
            norm = math.sqrt(q.x * q.x + q.y * q.y + q.z * q.z + q.w * q.w)
            if (not math.isfinite(norm) or abs(norm - 1.0) > 1e-5
                    or abs(q.x) + abs(q.y) + abs(q.z) > 1e-6):
                raise ValueError("rotated grid origins are not supported")
            spec = GridSpec(message.info.resolution, message.info.width,
                            message.info.height, message.info.origin.position.x,
                            message.info.origin.position.y, message.header.frame_id)
            data = list(message.data)
            if len(data) != spec.width * spec.height or any(v < -1 or v > 100 for v in data):
                raise ValueError("invalid map occupancy array")
        except ValueError as exc:
            self.spec, self.data = None, None
            self._clear_path()
            self.pending = self.goal_xy is not None
            self._status("INVALID_MAP", str(exc))
            return
        stamp = (message.info.map_load_time.sec, message.info.map_load_time.nanosec)
        changed = ((self.spec is not None and self.spec != spec)
                   or (self.map_load_stamp is not None and stamp != self.map_load_stamp))
        self.spec, self.data, self.map_load_stamp = spec, data, stamp
        if changed:
            self._clear_path()
            self.pending = self.goal_xy is not None
            self._status("WAITING", "Map origin or load time changed; old path cancelled.")

    def _on_odom(self, message):
        if message.header.frame_id != self.frame_id:
            self.robot_xy = None
            self._clear_path()
            self._status("INVALID_ODOM", f"Odometry frame must be {self.frame_id}.")
            return
        xy = (message.pose.pose.position.x, message.pose.pose.position.y)
        if not all(math.isfinite(v) for v in xy):
            self.robot_xy = None
            self._clear_path()
            self._status("INVALID_ODOM", "Odometry position is not finite.")
            return
        stamp = message.header.stamp.sec * 1_000_000_000 + message.header.stamp.nanosec
        if self.odom_stamp_ns is not None and stamp < self.odom_stamp_ns:
            self._clear_path()
            self.pending = self.goal_xy is not None
            self._status("WAITING", "Odometry time moved backwards; old path cancelled.")
        self.robot_xy, self.odom_stamp_ns = xy, stamp

    def _on_goal(self, message):
        self._clear_path()
        self.pending = False
        self.goal_xy = None
        if message.header.frame_id != self.frame_id:
            self._status("INVALID_GOAL", f"Set the RViz Fixed Frame to {self.frame_id}.")
            return
        xy = (message.pose.position.x, message.pose.position.y)
        if not all(math.isfinite(v) for v in xy):
            self._status("INVALID_GOAL", "Goal coordinates are not finite.")
            return
        self.goal_xy, self.pending = xy, True
        self._status("WAITING", "New goal accepted; waiting for valid inputs.")

    def _replan(self, request, response):
        del request
        self._clear_path()
        if self.goal_xy is None:
            response.success = False
            response.message = "No goal. Use RViz 2D Goal Pose or set auto_goal."
        else:
            self.pending = True
            self._status("WAITING", "Replan requested; old path cancelled.")
            response.success = True
            response.message = "Planning request queued; inspect /planner_status for its result."
        return response

    def _try_plan(self):
        if not self.pending:
            return
        if self.spec is None or self.data is None:
            self._status("WAITING", "Waiting for a valid occupancy grid.")
            return
        if self.robot_xy is None or self.odom_stamp_ns is None:
            self._status("WAITING", "Waiting for odometry.")
            return
        age = (self.get_clock().now().nanoseconds - self.odom_stamp_ns) * 1e-9
        if age < -self.odom_max_age or age > self.odom_max_age:
            self._status("WAITING", "Odometry is stale; check simulation time.")
            return
        if not any(0 <= value <= self.free_threshold for value in self.data):
            self._status("WAITING", "Map has no sufficiently observed free cells yet.")
            return
        self._status("PLANNING", "Running A* on the inflated occupancy grid.")
        points = astar_plan(self.spec, self.data, self.robot_xy, self.goal_xy,
                            self.inflation, self.allow_unknown,
                            self.occupied_threshold, self.free_threshold)
        self.pending = False
        if not points:
            self._clear_path()
            self._status("NO_PATH", "Start/goal blocked, outside map, or disconnected. "
                         "Inspect the map, then send a new goal or call /replan.")
            return
        path = Path()
        path.header.frame_id = self.frame_id
        path.header.stamp = self.get_clock().now().to_msg()
        for i, (x, y) in enumerate(points):
            pose = PoseStamped()
            pose.header.frame_id = self.frame_id
            pose.header.stamp = path.header.stamp
            pose.pose.position.x, pose.pose.position.y = x, y
            before = points[max(0, i - 1)]
            after = points[min(len(points) - 1, i + 1)]
            yaw = math.atan2(after[1] - before[1], after[0] - before[0])
            pose.pose.orientation.z = math.sin(yaw / 2.0)
            pose.pose.orientation.w = math.cos(yaw / 2.0)
            path.poses.append(pose)
        self.path_publisher.publish(path)
        length = sum(math.hypot(b[0] - a[0], b[1] - a[1])
                     for a, b in zip(points[:-1], points[1:]))
        self._status("READY", "Path published; this planner does not avoid moving obstacles.",
                     points=len(points), path_length_m=round(length, 3))

    def _publish_saved_map(self):
        message = OccupancyGrid()
        message.header.stamp = self.get_clock().now().to_msg()
        message.header.frame_id = self.spec.frame_id
        message.info.resolution = self.spec.resolution
        message.info.width, message.info.height = self.spec.width, self.spec.height
        message.info.origin.position.x = self.spec.origin_x
        message.info.origin.position.y = self.spec.origin_y
        message.info.origin.orientation.w = 1.0
        message.data = self.data
        self.saved_map_publisher.publish(message)


def main(args=None):
    rclpy.init(args=args)
    node = None
    try:
        node = PlannerNode()
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        if node is not None:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
