"""二维位置、角度和四元数的基础计算。"""

import math


def clamp(value, lower, upper):
    return max(lower, min(value, upper))


def wrap_angle(angle):
    """把角度归一化到 [-pi, pi)，避免跨越 ±pi 时反向长转。"""
    if not math.isfinite(angle):
        raise ValueError("angle must be finite")
    return (angle + math.pi) % (2.0 * math.pi) - math.pi


def yaw_from_quaternion(x, y, z, w):
    values = (x, y, z, w)
    if not all(math.isfinite(v) for v in values):
        raise ValueError("quaternion contains non-finite values")
    norm = math.sqrt(sum(v * v for v in values))
    if norm < 1.0e-12:
        raise ValueError("zero quaternion")
    x, y, z, w = (v / norm for v in values)
    return math.atan2(2.0 * (w * z + x * y),
                      1.0 - 2.0 * (y * y + z * z))


def distance(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])
