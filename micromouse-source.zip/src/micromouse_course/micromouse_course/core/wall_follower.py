"""左手规则状态机，转弯角度由里程计闭环控制。"""

from dataclasses import dataclass
import math

from .geometry import clamp, wrap_angle
from .types import ControlResult, Velocity


@dataclass(frozen=True)
class WallConfig:
    adaptive: bool = False
    desired_distance: float = 0.32
    front_stop: float = 0.40
    opening_distance: float = 0.70
    advance_distance: float = 0.22
    linear_speed: float = 0.14
    angular_speed: float = 0.80
    distance_gain: float = 1.6
    heading_gain: float = 1.4
    turn_gain: float = 2.0
    turn_tolerance: float = 0.04
    opening_debounce: float = 0.15
    rearm_distance: float = 0.25
    turn_timeout: float = 10.0
    advance_timeout: float = 5.0


class WallFollower:
    """左岔口优先，其次直行，再右转，死胡同时右转 180 度。

    左开口出现后先直行一小段，使车身越过内角再转弯。每次左转后
    必须重新观察到左墙并走过最短距离，才允许触发下一次左转。
    该算法不负责判定出口，也不能保证解决含孤立墙岛的任意迷宫。
    """

    def __init__(self, config=None):
        self.config = config or WallConfig()
        values = [value for key, value in vars(self.config).items() if key != "adaptive"]
        if not all(math.isfinite(value) and value > 0 for value in values):
            raise ValueError("wall-following parameters must be finite and positive")
        if self.config.opening_distance <= self.config.desired_distance:
            raise ValueError("opening distance must exceed desired wall distance")
        self.reset()

    def reset(self):
        self.state = "FOLLOW_WALL"
        self.fault = ""
        self.last_time = None
        self.last_pose = None
        self.travel_since_turn = 0.0
        self.left_ready = True
        self.open_since = None
        self.closed_since = None
        self.hold_yaw = None
        self.state_started = 0.0
        self.turn_requested = 0.0
        self.turn_accumulated = 0.0
        self.turn_last_yaw = 0.0
        self.turn_goal_yaw = 0.0
        self.turn_settle_since = None
        self.advance_origin = None

    def _stop(self, fault):
        self.fault = fault
        self.state = "ERROR"
        return ControlResult(Velocity(), self.state, fault=fault)

    def _start_turn(self, angle, pose, now, state):
        self.state = state
        self.state_started = now
        self.turn_goal_yaw = wrap_angle(self.hold_yaw + angle)
        self.turn_requested = wrap_angle(self.turn_goal_yaw - pose.yaw)
        # 掉头固定向右，累计转角允许略超过 pi 以消除入弯前的航向偏差。
        if angle <= -math.pi + 1e-6 and self.turn_requested > 0:
            self.turn_requested -= 2.0 * math.pi
        self.turn_accumulated = 0.0
        self.turn_last_yaw = pose.yaw
        self.turn_settle_since = None
        self.open_since = None
        self.closed_since = None
        self.left_ready = False
        return self._turn(pose, now, now)

    def _turn(self, pose, now, scan_stamp):
        if now - self.state_started > self.config.turn_timeout:
            return self._stop("turn timeout: inspect odometry, wheel contact and thresholds")
        delta = wrap_angle(pose.yaw - self.turn_last_yaw)
        self.turn_accumulated += delta
        self.turn_last_yaw = pose.yaw
        remaining = self.turn_requested - self.turn_accumulated
        if abs(remaining) <= self.config.turn_tolerance:
            if self.turn_settle_since is None:
                self.turn_settle_since = now
            # 激光一般低于控制频率。必须用停转后的新扫描，不能拿
            # 转弯前缓存的“左侧”距离去判断新走廊中的左侧开口。
            if (now - self.turn_settle_since >= 0.10
                    and scan_stamp >= self.turn_settle_since + 0.05):
                self.state = "FOLLOW_WALL"
                self.hold_yaw = self.turn_goal_yaw
                self.travel_since_turn = 0.0
            return ControlResult(Velocity(), self.state)
        self.turn_settle_since = None
        angular = clamp(self.config.turn_gain * remaining,
                        -self.config.angular_speed, self.config.angular_speed)
        return ControlResult(Velocity(0.0, angular), self.state)

    def update(self, pose, sectors, now, scan_stamp=None):
        """scan_stamp 为该帧激光的仿真时间；省略时视为同步观测。"""
        if scan_stamp is None:
            scan_stamp = now
        if self.fault:
            return ControlResult(Velocity(), "ERROR", fault=self.fault)
        if not pose.finite() or not math.isfinite(now) or not math.isfinite(scan_stamp):
            return self._stop("invalid pose or simulation time")
        if self.last_time is not None and now < self.last_time - 1e-6:
            return self._stop("simulation clock moved backwards; reset the controller")
        self.last_time = now
        if not sectors.valid:
            return ControlResult(Velocity(), "WAIT_SCAN", fault=sectors.reason)
        distances = (sectors.front, sectors.left, sectors.right,
                     sectors.front_left, sectors.front_right)
        if not all(math.isfinite(value) and value > 0.0 for value in distances):
            return ControlResult(Velocity(), "WAIT_SCAN", fault="invalid sector distance")
        if self.last_pose is not None:
            self.travel_since_turn += math.hypot(pose.x - self.last_pose.x,
                                               pose.y - self.last_pose.y)
        self.last_pose = pose
        if self.hold_yaw is None:
            self.hold_yaw = pose.yaw

        if self.state.startswith("TURN_"):
            return self._turn(pose, now, scan_stamp)
        if self.state == "ADVANCE_LEFT":
            if now - self.state_started > self.config.advance_timeout:
                return self._stop("corner advance timeout: inspect collision and odometry")
            if (sectors.left < self.config.opening_distance
                    and sectors.front > self.config.front_stop):
                # 航向修正可能使某一帧短暂出现假开口。前移期间重新
                # 看到左墙时撤销转弯，不执行已经过时的岔口决定。
                self.state = "FOLLOW_WALL"
                self.left_ready = True
                self.open_since = None
                self.closed_since = scan_stamp
                return ControlResult(Velocity(), self.state)
            origin = self.advance_origin
            travelled = ((pose.x - origin.x) * math.cos(self.hold_yaw)
                         + (pose.y - origin.y) * math.sin(self.hold_yaw))
            if travelled >= self.config.advance_distance or sectors.front <= self.config.front_stop:
                return self._start_turn(math.pi / 2.0, pose, now, "TURN_LEFT")
            angular = clamp(1.8 * wrap_angle(self.hold_yaw - pose.yaw), -0.45, 0.45)
            return ControlResult(Velocity(min(0.10, self.config.linear_speed), angular), self.state)

        left_open = sectors.left >= self.config.opening_distance
        if left_open:
            self.closed_since = None
            if self.open_since is None:
                self.open_since = scan_stamp
        else:
            self.open_since = None
            if self.closed_since is None:
                self.closed_since = scan_stamp
            if (scan_stamp - self.closed_since >= self.config.opening_debounce
                    and self.travel_since_turn >= self.config.rearm_distance):
                self.left_ready = True

        # 前方已接近墙时不再做岔口前移；直接原地转向。
        if sectors.front <= self.config.front_stop:
            if left_open and self.left_ready:
                return self._start_turn(math.pi / 2.0, pose, now, "TURN_LEFT")
            if sectors.right >= self.config.opening_distance:
                return self._start_turn(-math.pi / 2.0, pose, now, "TURN_RIGHT")
            return self._start_turn(-math.pi, pose, now, "TURN_AROUND")

        opening_confirmed = (left_open and self.open_since is not None
                             and scan_stamp - self.open_since >= self.config.opening_debounce)
        if self.left_ready and opening_confirmed:
            self.state = "ADVANCE_LEFT"
            self.state_started = now
            self.advance_origin = pose
            self.left_ready = False
            return ControlResult(Velocity(min(0.10, self.config.linear_speed), 0.0), self.state)

        if left_open:
            # 左墙暂时消失时保持航向，不能把大距离误差变成连续左旋。
            angular = 1.8 * wrap_angle(self.hold_yaw - pose.yaw)
        else:
            error = clamp(sectors.left - self.config.desired_distance, -0.25, 0.25)
            angular = self.config.distance_gain * error
            # 当前走廊方向在上一次直角转弯后固定，防止侧距修正逐步
            # 累成一次未经状态机确认的斜向拐弯。只在两个方向估计
            # 一致时融合左墙方向，岔口回波不用于重置走廊朝向。
            heading_error = wrap_angle(self.hold_yaw - pose.yaw)
            if (sectors.wall_heading is not None and math.isfinite(sectors.wall_heading)
                    and abs(wrap_angle(sectors.wall_heading - heading_error)) < 0.25):
                heading_error = 0.5 * (heading_error + sectors.wall_heading)
            angular += self.config.heading_gain * heading_error
        angular = clamp(angular, -self.config.angular_speed, self.config.angular_speed)
        linear = self.config.linear_speed
        if self.config.adaptive:
            clearance_factor = clamp((sectors.front - self.config.front_stop) / 0.60, 0.30, 1.0)
            linear *= clearance_factor / (1.0 + 1.6 * abs(angular))
        if left_open:
            linear = min(linear, 0.09)
        return ControlResult(Velocity(linear, angular), self.state)
