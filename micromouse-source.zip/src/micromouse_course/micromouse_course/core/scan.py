"""根据扫描角度提取扇区距离，不能把数组下标当成角度。"""

import math
from .geometry import wrap_angle
from .types import LaserSectors


SECTORS = (
    ("front", -15.0, 15.0),
    # 侧向使用窄扇区，避免接近正前墙时将其斜射回波当成侧墙。
    ("left", 85.0, 95.0),
    ("right", -95.0, -85.0),
    ("front_left", 20.0, 70.0),
    ("front_right", -70.0, -20.0),
)


def extract_sectors(ranges, angle_min, angle_increment, range_min, range_max):
    """返回各扇区最小有效距离，缺少任一必需扇区时 valid=False。

    正无穷表示量程内没有回波，按 range_max 处理；NaN、负无穷、
    零值以及超出有效量程的有限数不用于决策。没有回波与没有数据
    是不同的情况，后者不能作为通道畅通的依据。
    """
    meta = (angle_min, angle_increment, range_min, range_max)
    if (not all(math.isfinite(v) for v in meta)
            or angle_increment == 0.0 or range_min < 0.0
            or range_max <= range_min or len(ranges) == 0):
        return LaserSectors.invalid("invalid scan metadata")
    buckets = [[] for _ in SECTORS]
    # 左前、左后各取一个窄角束，辅助估计左墙方向。
    beams = ([], [])
    for index, value in enumerate(ranges):
        angle = wrap_angle(angle_min + index * angle_increment)
        degrees = math.degrees(angle)
        if value == math.inf:
            valid_range = range_max
        elif math.isfinite(value) and range_min <= value <= range_max and value > 0:
            valid_range = value
        else:
            continue
        for bucket, (_, lower, upper) in zip(buckets, SECTORS):
            if lower - 1e-7 <= degrees <= upper + 1e-7:
                bucket.append(valid_range)
        if 57.0 <= degrees <= 63.0 and math.isfinite(value):
            beams[0].append((valid_range, angle))
        if 117.0 <= degrees <= 123.0 and math.isfinite(value):
            beams[1].append((valid_range, angle))

    counts = tuple(len(bucket) for bucket in buckets)
    distances = [min(bucket) if bucket else 0.0 for bucket in buckets]
    valid = all(count > 0 for count in counts)
    heading = None
    if beams[0] and beams[1]:
        front = sorted(beams[0])[len(beams[0]) // 2]
        rear = sorted(beams[1])[len(beams[1]) // 2]
        # 过远回波通常来自岔口对面的墙，不作为当前左墙方向。
        if max(front[0], rear[0]) < 0.9:
            dx = front[0] * math.cos(front[1]) - rear[0] * math.cos(rear[1])
            dy = front[0] * math.sin(front[1]) - rear[0] * math.sin(rear[1])
            if dx > 0.05:
                estimate = math.atan2(dy, dx)
                if abs(estimate) <= 0.65:
                    heading = estimate
    reason = "" if valid else "one or more required sectors have no valid samples"
    return LaserSectors(*distances, valid, heading, counts, reason)
