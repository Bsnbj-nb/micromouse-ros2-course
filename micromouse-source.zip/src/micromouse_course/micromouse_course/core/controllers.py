"""点到点 P 控制、顺序航点和基于折线路径的纯追踪。"""

import math

from .geometry import clamp, distance, wrap_angle
from .types import ControlResult, Velocity


def _points(points):
    result = []
    for point in points:
        if len(point) != 2 or not all(math.isfinite(v) for v in point):
            raise ValueError("each point must contain two finite coordinates")
        result.append((float(point[0]), float(point[1])))
    if not result:
        raise ValueError("the point list cannot be empty")
    return result


class WaypointController:
    """仅到达当前航点的容差圆后才切换，不按最近点跳过中间航点。"""

    def __init__(self, waypoints, linear_speed=0.16, angular_speed=0.85,
                 position_tolerance=0.08, k_distance=0.8, k_heading=1.8):
        self.waypoints = _points(waypoints)
        parameters = (linear_speed, angular_speed, position_tolerance, k_distance, k_heading)
        if not all(math.isfinite(value) and value > 0 for value in parameters):
            raise ValueError("controller gains and limits must be finite and positive")
        self.linear_speed = linear_speed
        self.angular_speed = angular_speed
        self.position_tolerance = position_tolerance
        self.k_distance = k_distance
        self.k_heading = k_heading
        self.index = 0
        self.done = False

    def update(self, pose):
        if not pose.finite():
            return ControlResult(Velocity(), "ERROR", fault="invalid odometry")
        if self.done:
            return ControlResult(Velocity(), "DONE", done=True)
        while self.index < len(self.waypoints):
            goal = self.waypoints[self.index]
            rho = math.hypot(goal[0] - pose.x, goal[1] - pose.y)
            if rho > self.position_tolerance:
                break
            self.index += 1
        if self.index == len(self.waypoints):
            self.done = True
            return ControlResult(Velocity(), "DONE", done=True)
        alpha = wrap_angle(math.atan2(goal[1] - pose.y, goal[0] - pose.x) - pose.yaw)
        angular = clamp(self.k_heading * alpha, -self.angular_speed, self.angular_speed)
        # 大朝向误差时先转向，否则会向侧面的目标划出大弧线。
        linear = 0.0
        if abs(alpha) < 0.45:
            linear = min(self.linear_speed, self.k_distance * rho) * math.cos(alpha)
        return ControlResult(Velocity(linear, angular), "WAYPOINT_%d" % self.index)


class PointController(WaypointController):
    def __init__(self, goal, **kwargs):
        super().__init__([goal], **kwargs)


class PurePursuitController:
    """在线段上投影，再沿路径弧长寻找前视点。

    投影只允许在当前进度附近向前移动，防止自交路径直接跳到远处
    的线段。纯追踪会平滑折线拐角，精确逐点经过使用 WaypointController。
    """

    def __init__(self, path, lookahead=0.28, linear_speed=0.16,
                 angular_speed=0.85, position_tolerance=0.08,
                 projection_window=0.6):
        raw = _points(path)
        self.path = [raw[0]]
        for point in raw[1:]:
            if distance(point, self.path[-1]) > 1e-8:
                self.path.append(point)
        parameters = (lookahead, linear_speed, angular_speed, position_tolerance, projection_window)
        if not all(math.isfinite(value) and value > 0 for value in parameters):
            raise ValueError("pursuit parameters must be finite and positive")
        self.lookahead = lookahead
        self.linear_speed = linear_speed
        self.angular_speed = angular_speed
        self.position_tolerance = position_tolerance
        self.projection_window = projection_window
        self.arc = [0.0]
        for first, second in zip(self.path, self.path[1:]):
            self.arc.append(self.arc[-1] + distance(first, second))
        self.progress = 0.0
        self.done = False
        self.started = False
        self.start_controller = PointController(
            self.path[0], linear_speed=linear_speed, angular_speed=angular_speed,
            position_tolerance=position_tolerance)

    @property
    def total_length(self):
        return self.arc[-1]

    def point_at(self, arc_length):
        if len(self.path) == 1:
            return self.path[0]
        s = clamp(arc_length, 0.0, self.total_length)
        for index in range(len(self.path) - 1):
            if s <= self.arc[index + 1]:
                fraction = (s - self.arc[index]) / (self.arc[index + 1] - self.arc[index])
                first, second = self.path[index], self.path[index + 1]
                return (first[0] + fraction * (second[0] - first[0]),
                        first[1] + fraction * (second[1] - first[1]))
        return self.path[-1]

    def _project(self, pose):
        low = max(0.0, self.progress - 0.05)
        high = min(self.total_length, self.progress + self.projection_window)
        best_distance, best_s = math.inf, self.progress
        for index, (first, second) in enumerate(zip(self.path, self.path[1:])):
            begin, end = self.arc[index], self.arc[index + 1]
            if begin > high or end < low:
                continue
            dx, dy = second[0] - first[0], second[1] - first[1]
            length = end - begin
            fraction = ((pose.x - first[0]) * dx + (pose.y - first[1]) * dy) / (length * length)
            fraction = clamp(fraction, max(0.0, (low - begin) / length),
                             min(1.0, (high - begin) / length))
            projected = (first[0] + fraction * dx, first[1] + fraction * dy)
            error = distance((pose.x, pose.y), projected)
            s = begin + fraction * length
            if error < best_distance - 1e-9 or (abs(error - best_distance) <= 1e-9 and s < best_s):
                best_distance, best_s = error, s
        self.progress = max(self.progress, best_s)

    def update(self, pose):
        if not pose.finite():
            return ControlResult(Velocity(), "ERROR", fault="invalid odometry")
        if self.done:
            return ControlResult(Velocity(), "DONE", done=True)
        if not self.started:
            result = self.start_controller.update(pose)
            if not result.done:
                return ControlResult(result.command, "APPROACH_PATH_START", fault=result.fault)
            self.started = True
        if len(self.path) == 1:
            self.done = True
            return ControlResult(Velocity(), "DONE", done=True)
        self._project(pose)
        end_distance = distance((pose.x, pose.y), self.path[-1])
        remaining_arc = self.total_length - self.progress
        on_final_segment = self.progress >= self.arc[-2]
        near_final_segment = on_final_segment and remaining_arc <= self.lookahead
        # 闭合路径的起终点可能重合，仅比较终点距离会在起点误报完成。
        if (on_final_segment and remaining_arc <= self.position_tolerance
                and end_distance <= self.position_tolerance):
            self.done = True
            return ControlResult(Velocity(), "DONE", done=True)
        target_arc = min(self.total_length, self.progress + self.lookahead)
        target = self.point_at(target_arc)
        dx, dy = target[0] - pose.x, target[1] - pose.y
        # 前视跨过一个短闭环时，目标恰好重合；缩短弧长以保留前进方向。
        for _ in range(12):
            if dx * dx + dy * dy >= 1e-10:
                break
            target_arc = (self.progress + target_arc) / 2.0
            target = self.point_at(target_arc)
            dx, dy = target[0] - pose.x, target[1] - pose.y
        heading_error = wrap_angle(math.atan2(dy, dx) - pose.yaw)
        if abs(heading_error) > 0.85:
            return ControlResult(Velocity(0.0, clamp(1.8 * heading_error,
                                                    -self.angular_speed, self.angular_speed)),
                                 "ALIGN_PATH")
        squared_distance = dx * dx + dy * dy
        if squared_distance < 1e-10:
            return ControlResult(Velocity(), "PATH_TARGET_COINCIDENT")
        lateral = -math.sin(pose.yaw) * dx + math.cos(pose.yaw) * dy
        curvature = 2.0 * lateral / squared_distance
        linear = self.linear_speed / (1.0 + 0.5 * abs(curvature))
        if near_final_segment:
            linear = min(linear, 0.8 * end_distance)
        if abs(curvature) > 1e-9:
            linear = min(linear, self.angular_speed / abs(curvature))
        angular = clamp(linear * curvature, -self.angular_speed, self.angular_speed)
        return ControlResult(Velocity(linear, angular), "PURE_PURSUIT")
