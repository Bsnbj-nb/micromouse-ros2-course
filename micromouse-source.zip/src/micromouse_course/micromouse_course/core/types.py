"""不依赖 ROS 的运动状态和控制输出。"""

from dataclasses import dataclass
import math


@dataclass(frozen=True)
class Pose2D:
    x: float
    y: float
    yaw: float

    def finite(self):
        return all(math.isfinite(v) for v in (self.x, self.y, self.yaw))


@dataclass(frozen=True)
class Velocity:
    linear: float = 0.0
    angular: float = 0.0


@dataclass(frozen=True)
class ControlResult:
    command: Velocity
    state: str
    done: bool = False
    fault: str = ""


@dataclass(frozen=True)
class LaserSectors:
    front: float
    left: float
    right: float
    front_left: float
    front_right: float
    valid: bool = True
    wall_heading: float = None
    counts: tuple = ()
    reason: str = ""

    @classmethod
    def invalid(cls, reason):
        return cls(0.0, 0.0, 0.0, 0.0, 0.0, False, reason=reason)
