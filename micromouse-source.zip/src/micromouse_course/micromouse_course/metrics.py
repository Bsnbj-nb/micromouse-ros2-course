"""仅记录运行时实际接收的位姿与控制输出，不预填实验结论。"""

import csv
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import time


class RunRecorder:
    FIELDS = ["sim_time", "elapsed_sim", "elapsed_wall", "mode", "state",
              "x", "y", "yaw", "odom_x", "odom_y", "v_cmd", "w_cmd",
              "front_m", "left_m", "right_m", "nearest_scan_m", "scan_valid",
              "task_completed", "goal_reached", "fault"]

    def __init__(self, directory, mode, metadata):
        root = Path(directory).expanduser()
        root.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
        self.directory = root / (stamp + "_" + mode)
        self.directory.mkdir()
        self.file = (self.directory / "trajectory.csv").open("w", newline="", encoding="utf-8")
        self.writer = csv.DictWriter(self.file, fieldnames=self.FIELDS)
        self.writer.writeheader()
        self.wall_start = time.monotonic()
        self.sim_start = None
        self.last_pose = None
        self.last_command = None
        self.last_state = None
        self.path_length = 0.0
        self.angular_total_variation = 0.0
        self.min_scan = math.inf
        self.samples = 0
        self.last_flush = self.wall_start
        self.first_success_time = None
        self.motion_start = None
        self.last_row = None
        self.closed = False
        self.mode = mode
        self.metadata = metadata
        self._write_json("run_config.json", metadata)

    def _write_json(self, name, value):
        target = self.directory / name
        temp = target.with_suffix(target.suffix + ".tmp")
        temp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
                        encoding="utf-8")
        temp.replace(target)

    def record(self, now, pose, odom, result, sectors, nearest):
        if self.closed or pose is None:
            return
        if self.sim_start is None:
            self.sim_start = now
        wall = time.monotonic()
        if self.last_pose is not None:
            self.path_length += math.hypot(pose.x - self.last_pose.x, pose.y - self.last_pose.y)
        if self.last_command is not None:
            self.angular_total_variation += abs(result.command.angular - self.last_command.angular)
        self.last_pose, self.last_command = pose, result.command
        if self.motion_start is None and (abs(result.command.linear) > 1e-6 or abs(result.command.angular) > 1e-6):
            self.motion_start = now
        if sectors is not None and sectors.valid and math.isfinite(nearest):
            self.min_scan = min(self.min_scan, nearest)
        if result.done and self.first_success_time is None:
            self.first_success_time = now - (self.motion_start if self.motion_start is not None else now)
        row = dict(sim_time=now, elapsed_sim=now - self.sim_start,
                   elapsed_wall=wall - self.wall_start, mode=self.mode, state=result.state,
                   x=pose.x, y=pose.y, yaw=pose.yaw, odom_x=odom.x, odom_y=odom.y,
                   v_cmd=result.command.linear, w_cmd=result.command.angular,
                   front_m=sectors.front if sectors else "", left_m=sectors.left if sectors else "",
                   right_m=sectors.right if sectors else "", nearest_scan_m=nearest,
                   scan_valid=bool(sectors and sectors.valid), task_completed=result.done,
                   goal_reached=result.done and self.mode != "open_loop",
                   fault=result.fault)
        self.writer.writerow(row)
        self.last_row = row
        self.samples += 1
        if wall - self.last_flush >= 1.0 or result.state != self.last_state:
            self.file.flush()
            self._write_json("summary.json", self.summary())
            self.last_flush = wall
        self.last_state = result.state

    def summary(self):
        return {
            "mode": self.mode, "samples": self.samples,
            "task_completed": self.first_success_time is not None,
            "goal_reached": self.first_success_time is not None and self.mode != "open_loop",
            "completion_time_sim_s": self.first_success_time,
            "startup_wait_sim_s": self.motion_start - self.sim_start if self.motion_start is not None else None,
            "path_length_odom_m": self.path_length,
            "minimum_valid_scan_range_m": self.min_scan if math.isfinite(self.min_scan) else None,
            "angular_command_total_variation": self.angular_total_variation,
            "last_state": self.last_row["state"] if self.last_row else "NO_DATA",
            "last_fault": self.last_row["fault"] if self.last_row else "",
            "evidence": "ROS topic samples from this run; scan range is not body clearance or collision count",
            "clean_shutdown": self.closed,
        }

    def close(self):
        if not self.closed:
            self.closed = True
            self.file.flush()
            self.file.close()
            self._write_json("summary.json", self.summary())
