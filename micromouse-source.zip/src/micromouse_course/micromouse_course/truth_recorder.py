"""Independent Gazebo ground truth evidence; never publishes motion commands.

Added during target-machine integration. The navigation algorithm cannot read
these samples: they are saved solely to audit trajectories and wall penetration.
"""
import csv
import json
import math
import signal
from pathlib import Path
import rclpy
from rclpy.node import Node
from rclpy.executors import ExternalShutdownException, SingleThreadedExecutor
from rclpy.signals import SignalHandlerOptions
from rclpy.qos import qos_profile_sensor_data
from gazebo_msgs.msg import ModelStates
from sensor_msgs.msg import LaserScan


class TruthRecorder(Node):
    def __init__(self):
        super().__init__('truth_recorder')
        root=Path(self.declare_parameter('output_directory','/tmp/course_evidence').value)
        root.mkdir(parents=True,exist_ok=True)
        self.root=root; self.count=0; self.scan_count=0
        self.file=(root/'ground_truth.csv').open('w',newline='')
        self.writer=csv.writer(self.file)
        self.writer.writerow(['sim_time','x','y','z','yaw','vx','vy','wz'])
        self.create_subscription(ModelStates,'/gazebo/model_states',self.record,10)
        self.create_subscription(LaserScan,'/scan',self.scan,qos_profile_sensor_data)

    def scan(self,msg):
        if self.scan_count==0:
            data={name:getattr(msg,name) for name in ['angle_min','angle_max','angle_increment','scan_time','time_increment','range_min','range_max']}
            data.update(count=len(msg.ranges),frame_id=msg.header.frame_id,source='live /scan')
            (self.root/'scan_metadata.json').write_text(json.dumps(data,indent=2))
        self.scan_count+=1

    def record(self,msg):
        if 'burger' not in msg.name:return
        i=msg.name.index('burger'); p=msg.pose[i]; v=msg.twist[i]; q=p.orientation
        a=math.atan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z))
        self.writer.writerow([self.get_clock().now().nanoseconds*1e-9,p.position.x,p.position.y,p.position.z,a,v.linear.x,v.linear.y,v.angular.z])
        self.count+=1
        if self.count%20==0:self.file.flush()


def main(args=None):
    """Stop taking messages before destroying their ROS context.

    AI-assisted fix, 2026-11-02: Humble's default signal handler can shut
    down the context while the executor is taking a ModelStates message.
    A Python signal handler only requests exit; the current callback may
    finish, then the single-threaded executor is stopped before cleanup.
    Unexpected callback exceptions remain visible and produce failure.
    """
    stopping = False

    def request_stop(signum, frame):
        nonlocal stopping
        stopping = True

    previous_handlers = {}
    node = None
    executor = None
    initialized = False
    try:
        for signum in (signal.SIGINT, signal.SIGTERM):
            previous_handlers[signum] = signal.signal(signum, request_stop)
        rclpy.init(args=args, signal_handler_options=SignalHandlerOptions.NO)
        initialized = True
        node = TruthRecorder()
        executor = SingleThreadedExecutor()
        executor.add_node(node)
        while not stopping and rclpy.ok():
            executor.spin_once(timeout_sec=0.1)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        try:
            try:
                if executor is not None:
                    executor.shutdown()
            finally:
                try:
                    if node is not None:
                        node.destroy_node()
                finally:
                    try:
                        if node is not None:
                            node.file.close()
                    finally:
                        if initialized and rclpy.ok():
                            rclpy.shutdown()
        finally:
            for signum, handler in previous_handlers.items():
                signal.signal(signum, handler)
