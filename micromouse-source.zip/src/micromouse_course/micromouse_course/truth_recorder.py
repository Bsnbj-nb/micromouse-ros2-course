"""Independent Gazebo ground truth evidence; never publishes motion commands.

Added during target-machine integration. The navigation algorithm cannot read
these samples: they are saved solely to audit trajectories and wall penetration.
"""
import csv
import json
import math
from pathlib import Path
import rclpy
from rclpy.node import Node
from rclpy.executors import ExternalShutdownException
from rclpy.qos import qos_profile_sensor_data
from gazebo_msgs.msg import ModelStates
from sensor_msgs.msg import LaserScan


class TruthRecorder(Node):
    def __init__(self):
        super().__init__('truth_recorder')
        root=Path(self.declare_parameter('output_directory','/tmp/course_evidence').value)
        root.mkdir(parents=True,exist_ok=True)
        self.root=root; self.count=0; self.scan_count=0
        self.file=(root/'ground_truth.csv').open('w',newline='')
        self.writer=csv.writer(self.file)
        self.writer.writerow(['sim_time','x','y','z','yaw','vx','vy','wz'])
        self.create_subscription(ModelStates,'/gazebo/model_states',self.record,10)
        self.create_subscription(LaserScan,'/scan',self.scan,qos_profile_sensor_data)

    def scan(self,msg):
        if self.scan_count==0:
            data={name:getattr(msg,name) for name in ['angle_min','angle_max','angle_increment','scan_time','time_increment','range_min','range_max']}
            data.update(count=len(msg.ranges),frame_id=msg.header.frame_id,source='live /scan')
            (self.root/'scan_metadata.json').write_text(json.dumps(data,indent=2))
        self.scan_count+=1

    def record(self,msg):
        if 'burger' not in msg.name:return
        i=msg.name.index('burger'); p=msg.pose[i]; v=msg.twist[i]; q=p.orientation
        a=math.atan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z))
        self.writer.writerow([self.get_clock().now().nanoseconds*1e-9,p.position.x,p.position.y,p.position.z,a,v.linear.x,v.linear.y,v.angular.z])
        self.count+=1
        if self.count%20==0:self.file.flush()


def main(args=None):
    rclpy.init(args=args); node=TruthRecorder()
    try:rclpy.spin(node)
    except (KeyboardInterrupt,ExternalShutdownException):pass
    finally:
        node.file.close(); node.destroy_node()
        if rclpy.ok():rclpy.shutdown()
