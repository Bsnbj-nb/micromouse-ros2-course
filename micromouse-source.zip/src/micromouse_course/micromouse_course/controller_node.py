"""唯一速度发布节点，组合感知、运动控制与迷宫决策。"""

from collections import deque
import json
import math
import time

import rclpy
from rclpy.clock import Clock, ClockType
from rclpy.node import Node
from rclpy.executors import ExternalShutdownException
from rclpy.qos import QoSProfile, DurabilityPolicy, ReliabilityPolicy, qos_profile_sensor_data
from geometry_msgs.msg import PoseStamped, Twist
from nav_msgs.msg import Odometry, Path
from sensor_msgs.msg import LaserScan
from std_msgs.msg import String
from std_srvs.srv import SetBool

from .core import (Pose2D, Velocity, ControlResult, extract_sectors,
                   yaw_from_quaternion, PointController, WaypointController,
                   PurePursuitController, WallFollower, WallConfig)
from .metrics import RunRecorder
from .runtime import (FrameAlignment, OpenLoopProgram, LoopMonitor,
                      unpack_points, simplify_collinear, sample_is_fresh,
                      finite_range_min)


MODES = ("idle", "manual", "open_loop", "point", "waypoints", "avoid",
         "wall_basic", "wall_adaptive", "pure_pursuit", "global")


class CourseController(Node):
    def __init__(self):
        super().__init__("course_controller")
        defaults = {
            "mode": "idle", "frame_id": "odom", "scan_frame": "base_scan",
            "spawn_x": 0.5, "spawn_y": 0.5, "spawn_yaw": 0.0,
            "scene": "course_maze", "control_rate": 20.0,
            "linear_speed": 0.14, "angular_speed": 0.8,
            "goal_x": 2.5, "goal_y": 1.5, "position_tolerance": 0.07,
            "waypoints_xy": [0.5, 0.5, 2.5, 0.5, 2.5, 2.5, 0.5, 2.5],
            "lookahead": 0.28, "desired_wall_distance": 0.32,
            "front_stop": 0.40, "opening_distance": 0.70,
            "corner_advance": 0.22, "exit_enabled": True,
            "exit_region": [4.15, 5.0, 3.1, 3.9], "exit_hold_seconds": 0.4,
            "scan_timeout": 0.65, "odom_timeout": 0.65,
            "wall_timeout": 2.0, "emergency_distance": 0.18,
            "rotation_stop_distance": 0.18, "max_run_seconds": 600.0,
            "loop_detection": False, "loop_repeat_limit": 4,
            "loop_cell_size": 0.4, "log_directory": "~/micromouse_runs",
            "record": True, "open_straight_seconds": 5.0,
            "open_turn_seconds": math.pi, "open_angular_speed": 0.5,
            "manual_timeout": 0.6,
        }
        self.cfg = {name: self.declare_parameter(name, value).value
                    for name, value in defaults.items()}
        self.mode = self.cfg["mode"]
        if self.mode not in MODES:
            raise ValueError("unsupported mode: " + self.mode)
        for name in ("control_rate", "linear_speed", "angular_speed", "position_tolerance",
                     "scan_timeout", "odom_timeout", "wall_timeout", "emergency_distance",
                     "rotation_stop_distance", "max_run_seconds", "manual_timeout",
                     "exit_hold_seconds"):
            if not math.isfinite(self.cfg[name]) or self.cfg[name] <= 0:
                raise ValueError(name + " must be finite and positive")
        region = self.cfg["exit_region"]
        if (len(region) != 4 or not all(math.isfinite(v) for v in region)
                or region[0] >= region[1] or region[2] >= region[3]):
            raise ValueError("exit_region must be [xmin,xmax,ymin,ymax]")
        self.latched_qos = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                                     durability=DurabilityPolicy.TRANSIENT_LOCAL)
        self.cmd_pub = self.create_publisher(Twist, "/cmd_vel", 10)
        self.state_pub = self.create_publisher(String, "/controller_state", self.latched_qos)
        self.sector_pub = self.create_publisher(String, "/scan_sectors", 10)
        self.alignment_pub = self.create_publisher(String, "/task_alignment", self.latched_qos)
        self.path_pub = self.create_publisher(Path, "/reference_path", self.latched_qos)
        self.trajectory_pub = self.create_publisher(Path, "/trajectory", 10)
        self.create_subscription(Odometry, "/odom", self.on_odom, qos_profile_sensor_data)
        self.create_subscription(LaserScan, "/scan", self.on_scan, qos_profile_sensor_data)
        self.create_subscription(Path, "/planned_path", self.on_path, self.latched_qos)
        self.create_subscription(Twist, "/teleop_cmd_vel", self.on_manual, 10)
        self.create_service(SetBool, "/emergency_stop", self.on_stop)
        self.pose = self.odom = self.alignment = self.sectors = None
        self.odom_stamp = self.scan_stamp = None
        self.odom_received = self.scan_received = None
        self.nearest = 0.0
        self.below_min_return = False
        self.received_manual = None
        self.manual_command = Velocity()
        self.pending_path = None
        self.path_error = ""
        self.path_signature = None
        self.algorithm = None
        self.finished = False
        self.stop_latched = False
        self.hard_fault = ""
        self.started_at = None
        self.last_tick = None
        self.exit_since = None
        self.avoid_turn = 0.0
        self.last_state = ""
        self.last_status_time = -math.inf
        self.last_record_time = -math.inf
        self.last_trace_time = -math.inf
        self.trajectory = deque(maxlen=6000)
        self.loop_monitor = LoopMonitor(cell_size=self.cfg["loop_cell_size"],
                                        repeat_limit=self.cfg["loop_repeat_limit"])
        self.recorder = self.new_recorder() if self.cfg["record"] else None
        self.reference_points = []
        self.build_algorithm()
        self.create_timer(1.0 / self.cfg["control_rate"], self.tick)
        # 仿真暂停时 ROS 计时器也暂停；单独用单调时钟清除可能残留的速度。
        self.watchdog_clock = Clock(clock_type=ClockType.STEADY_TIME)
        self.create_timer(0.1, self.watchdog, clock=self.watchdog_clock)
        self.get_logger().info("mode=%s; waiting for fresh /odom and /scan" % self.mode)
        if self.recorder:
            self.get_logger().info("run directory: " + str(self.recorder.directory))

    def new_recorder(self):
        metadata = dict(self.cfg)
        if getattr(self, "alignment", None) is not None:
            metadata["alignment"] = {"odom_start": vars(self.alignment.odom_start),
                                     "task_start": vars(self.alignment.task_start)}
        if getattr(self, "reference_points", None):
            metadata["reference_points_task"] = self.reference_points
        return RunRecorder(self.cfg["log_directory"], self.mode, metadata)

    def build_algorithm(self):
        common = dict(linear_speed=self.cfg["linear_speed"],
                      angular_speed=self.cfg["angular_speed"],
                      position_tolerance=self.cfg["position_tolerance"])
        if self.mode == "point":
            self.reference_points = [(self.cfg["goal_x"], self.cfg["goal_y"])]
            self.algorithm = PointController(self.reference_points[0], **common)
        elif self.mode in ("waypoints", "pure_pursuit"):
            self.reference_points = unpack_points(self.cfg["waypoints_xy"])
            if self.mode == "waypoints":
                self.algorithm = WaypointController(self.reference_points, **common)
            else:
                self.algorithm = PurePursuitController(self.reference_points,
                                                       lookahead=self.cfg["lookahead"], **common)
        elif self.mode.startswith("wall_"):
            self.algorithm = WallFollower(WallConfig(
                adaptive=self.mode == "wall_adaptive", linear_speed=self.cfg["linear_speed"],
                angular_speed=self.cfg["angular_speed"],
                desired_distance=self.cfg["desired_wall_distance"],
                front_stop=self.cfg["front_stop"], opening_distance=self.cfg["opening_distance"],
                advance_distance=self.cfg["corner_advance"]))
        elif self.mode == "open_loop":
            self.algorithm = OpenLoopProgram(linear=self.cfg["linear_speed"],
                                             straight_seconds=self.cfg["open_straight_seconds"],
                                             angular=self.cfg["open_angular_speed"],
                                             turn_seconds=self.cfg["open_turn_seconds"])

    @staticmethod
    def stamp_seconds(stamp):
        return stamp.sec + stamp.nanosec * 1e-9

    def now_seconds(self):
        return self.get_clock().now().nanoseconds * 1e-9

    def on_odom(self, message):
        if message.header.frame_id.lstrip("/") != self.cfg["frame_id"].lstrip("/"):
            self.hard_fault = "unexpected odom frame: " + message.header.frame_id
            return
        q = message.pose.pose.orientation
        try:
            yaw = yaw_from_quaternion(q.x, q.y, q.z, q.w)
        except ValueError as error:
            self.hard_fault = str(error)
            return
        p = message.pose.pose.position
        odom = Pose2D(p.x, p.y, yaw)
        if not odom.finite():
            self.hard_fault = "odometry is not finite"
            return
        stamp = self.stamp_seconds(message.header.stamp)
        if self.odom is not None and self.odom_stamp is not None:
            dt = stamp - self.odom_stamp
            jump = math.hypot(odom.x - self.odom.x, odom.y - self.odom.y)
            if dt < -0.05 or (0 <= dt < 0.5 and jump > 0.5):
                self.hard_fault = "odometry reset or teleport; restart the launch"
        self.odom, self.odom_stamp = odom, stamp
        self.odom_received = time.monotonic()
        if self.alignment is None:
            start = Pose2D(self.cfg["spawn_x"], self.cfg["spawn_y"], self.cfg["spawn_yaw"])
            self.alignment = FrameAlignment(odom, start)
            self.alignment_pub.publish(String(data=json.dumps({
                "frame_id": self.cfg["frame_id"], "odom_start": vars(odom),
                "task_start": vars(start), "scene": self.cfg["scene"]})))
            if self.recorder:
                self.recorder.metadata["alignment"] = {"odom_start": vars(odom), "task_start": vars(start)}
                self.recorder.metadata["reference_points_task"] = self.reference_points
                self.recorder._write_json("run_config.json", self.recorder.metadata)
            self.publish_reference()
            if self.pending_path is not None:
                saved, self.pending_path = self.pending_path, None
                self.on_path(saved)
        self.pose = self.alignment.to_task(odom)

    def on_scan(self, message):
        if message.header.frame_id.lstrip("/") != self.cfg["scan_frame"].lstrip("/"):
            self.hard_fault = "unexpected scan frame: " + message.header.frame_id
            return
        self.sectors = extract_sectors(message.ranges, message.angle_min,
                                       message.angle_increment, message.range_min,
                                       message.range_max)
        self.below_min_return = any(math.isfinite(v) and 0.0 < v < message.range_min
                                    for v in message.ranges)
        if message.range_min >= self.cfg["rotation_stop_distance"]:
            self.hard_fault = "rotation_stop_distance must exceed scan.range_min"
        self.scan_stamp = self.stamp_seconds(message.header.stamp)
        self.scan_received = time.monotonic()
        self.nearest = finite_range_min(message.ranges, message.range_min, message.range_max)
        if not math.isfinite(self.nearest):
            self.nearest = 0.0
        self.sector_pub.publish(String(data=json.dumps({
            "front": self.sectors.front, "left": self.sectors.left,
            "right": self.sectors.right, "front_left": self.sectors.front_left,
            "front_right": self.sectors.front_right, "valid": self.sectors.valid,
            "reason": self.sectors.reason}, allow_nan=False)))

    def on_path(self, message):
        if self.mode != "global":
            return
        if not message.poses:
            self.pending_path = None
            self.algorithm, self.path_signature = None, None
            self.finished = False
            self.path_error = "waiting for a valid planned path"
            self.publish_velocity(Velocity())
            return
        if message.header.frame_id.lstrip("/") != self.cfg["frame_id"].lstrip("/"):
            self.pending_path = None
            self.algorithm, self.path_signature = None, None
            self.path_error = "planned path frame does not match odom"
            self.publish_velocity(Velocity())
            return
        if self.alignment is None:
            self.pending_path = message
            return
        try:
            points = []
            for stamped in message.poses:
                if stamped.header.frame_id and stamped.header.frame_id.lstrip("/") != self.cfg["frame_id"]:
                    raise ValueError("mixed frame ids in path")
                p = stamped.pose.position
                task = self.alignment.to_task(Pose2D(p.x, p.y, 0.0))
                points.append((task.x, task.y))
            points = simplify_collinear(points)
            signature = tuple(points)
            if signature == self.path_signature:
                return
            self.algorithm = WaypointController(points, linear_speed=min(0.12, self.cfg["linear_speed"]),
                                                angular_speed=self.cfg["angular_speed"],
                                                position_tolerance=0.035)
        except (ValueError, TypeError) as error:
            self.pending_path = None
            self.algorithm, self.path_signature = None, None
            self.path_error = str(error)
            self.publish_velocity(Velocity())
            return
        self.path_signature = signature
        self.path_error = ""
        self.finished = False
        self.started_at = self.now_seconds()
        self.reference_points = points
        self.publish_reference()
        if self.cfg["record"]:
            if self.recorder:
                self.recorder.close()
            self.recorder = self.new_recorder()
            self.get_logger().info("new planned run: " + str(self.recorder.directory))

    def on_manual(self, message):
        if self.mode != "manual":
            return
        if not all(math.isfinite(v) for v in (message.linear.x, message.angular.z)):
            self.manual_command = Velocity()
            return
        # 本实验的安全扇区针对前进；倒车不进入速度输出。
        self.manual_command = Velocity(max(0.0, message.linear.x), message.angular.z)
        self.received_manual = time.monotonic()

    def on_stop(self, request, response):
        self.stop_latched = bool(request.data)
        self.publish_velocity(Velocity())
        if not request.data:
            self.manual_command = Velocity()
            self.received_manual = None
        response.success = True
        response.message = "emergency stop engaged" if request.data else "released; data and fault checks remain active"
        return response

    def publish_velocity(self, command):
        message = Twist()
        message.linear.x = float(command.linear)
        message.angular.z = float(command.angular)
        self.cmd_pub.publish(message)

    def watchdog(self):
        now = time.monotonic()
        stale = any(t is None or now - t > self.cfg["wall_timeout"]
                    for t in (self.scan_received, self.odom_received))
        if stale or self.stop_latched or self.hard_fault:
            self.publish_velocity(Velocity())

    def readiness(self, now):
        wall = time.monotonic()
        if self.hard_fault:
            return "FAULT", self.hard_fault
        if self.stop_latched:
            return "EMERGENCY_STOP", "operator stop"
        if self.pose is None or self.sectors is None:
            return "WAIT_DATA", "waiting for odometry and scan"
        if not sample_is_fresh(now, self.odom_stamp, wall, self.odom_received,
                               self.cfg["odom_timeout"], self.cfg["wall_timeout"]):
            return "WAIT_ODOM", "odometry is stale or has a future timestamp"
        if not sample_is_fresh(now, self.scan_stamp, wall, self.scan_received,
                               self.cfg["scan_timeout"], self.cfg["wall_timeout"]):
            return "WAIT_SCAN", "scan is stale or has a future timestamp"
        if not self.sectors.valid:
            return "WAIT_SCAN", self.sectors.reason
        if self.below_min_return:
            return "TOO_CLOSE", "scan contains positive returns below minimum range"
        return "", ""

    def algorithm_step(self, now):
        if self.mode == "idle":
            return ControlResult(Velocity(), "IDLE")
        if self.mode == "manual":
            if self.received_manual is None or time.monotonic() - self.received_manual > self.cfg["manual_timeout"]:
                return ControlResult(Velocity(), "WAIT_TELEOP")
            return ControlResult(self.manual_command, "MANUAL")
        if self.mode == "global" and self.algorithm is None:
            return ControlResult(Velocity(), "WAIT_PATH", fault=self.path_error)
        if self.finished:
            return ControlResult(Velocity(), "DONE", done=True)
        if self.mode == "avoid":
            if self.sectors.front < 0.45 and self.avoid_turn == 0:
                self.avoid_turn = 1.0 if self.sectors.left >= self.sectors.right else -1.0
            if self.sectors.front > 0.60:
                self.avoid_turn = 0.0
            if self.avoid_turn:
                return ControlResult(Velocity(0.0, self.avoid_turn * self.cfg["angular_speed"]), "AVOID_TURN")
            return ControlResult(Velocity(self.cfg["linear_speed"], 0.0), "AVOID_FORWARD")
        if self.mode == "open_loop":
            return self.algorithm.update(now)
        if self.mode.startswith("wall_"):
            if self.cfg["exit_enabled"]:
                xmin, xmax, ymin, ymax = self.cfg["exit_region"]
                inside = xmin <= self.pose.x <= xmax and ymin <= self.pose.y <= ymax
                self.exit_since = (self.exit_since if self.exit_since is not None else now) if inside else None
                if self.exit_since is not None:
                    if now - self.exit_since >= self.cfg["exit_hold_seconds"]:
                        return ControlResult(Velocity(), "DONE", done=True)
                    return ControlResult(Velocity(), "CONFIRM_EXIT")
            if self.cfg["loop_detection"] and self.loop_monitor.update(self.pose, now):
                self.hard_fault = "repeated position and heading; save map and use global planning"
                return ControlResult(Velocity(), "LOOP_DETECTED", fault=self.hard_fault)
            return self.algorithm.update(self.pose, self.sectors, now, scan_stamp=self.scan_stamp)
        return self.algorithm.update(self.pose)

    def tick(self):
        now = self.now_seconds()
        if self.last_tick is not None and now < self.last_tick - 0.05:
            self.hard_fault = "simulation time reset; restart the launch"
        self.last_tick = now
        state, reason = self.readiness(now)
        if state:
            result = ControlResult(Velocity(), state, fault=reason)
        else:
            if self.started_at is None:
                self.started_at = now
            if self.mode not in ("idle", "manual", "global") and now - self.started_at > self.cfg["max_run_seconds"] and not self.finished:
                self.hard_fault = "run timeout"
                result = ControlResult(Velocity(), "TIMEOUT", fault=self.hard_fault)
            elif self.mode == "global" and self.algorithm is not None and now - self.started_at > self.cfg["max_run_seconds"] and not self.finished:
                self.hard_fault = "planned run timeout"
                result = ControlResult(Velocity(), "TIMEOUT", fault=self.hard_fault)
            else:
                result = self.algorithm_step(now)
            command = result.command
            if not all(math.isfinite(v) for v in (command.linear, command.angular)):
                self.hard_fault = "controller produced a non-finite velocity"
                result = ControlResult(Velocity(), "FAULT", fault=self.hard_fault)
            elif command.linear > 0 and self.sectors.front <= self.cfg["emergency_distance"]:
                result = ControlResult(Velocity(), "FRONT_BLOCKED", fault="front emergency distance")
            elif abs(command.angular) > 0 and self.nearest < self.cfg["rotation_stop_distance"]:
                result = ControlResult(Velocity(), "TOO_CLOSE", fault="insufficient rotation clearance")
            else:
                clipped = Velocity(min(0.20, max(0.0, command.linear)), max(-1.2, min(1.2, command.angular)))
                result = ControlResult(clipped, result.state, result.done, result.fault)
            if result.done:
                self.finished = True
        self.publish_velocity(result.command)
        if result.state != self.last_state or now - self.last_status_time >= 0.5:
            payload = {"mode": self.mode, "state": result.state, "done": result.done,
                       "fault": result.fault, "sim_time": now,
                       "task_pose": vars(self.pose) if self.pose else None,
                       "command": vars(result.command)}
            self.state_pub.publish(String(data=json.dumps(payload, allow_nan=False)))
            if result.state != self.last_state:
                self.get_logger().info(result.state + (": " + result.fault if result.fault else ""))
            self.last_status_time = now
        if self.recorder and (now - self.last_record_time >= 0.1 or result.state != self.last_state):
            self.recorder.record(now, self.pose, self.odom, result, self.sectors, self.nearest)
            self.last_record_time = now
            if result.done:
                self.recorder.close()
        self.last_state = result.state
        if self.odom is not None and now - self.last_trace_time >= 0.2:
            p = self.pose_message(self.odom.x, self.odom.y, self.odom.yaw)
            self.trajectory.append(p)
            message = Path()
            message.header = p.header
            message.poses = list(self.trajectory)
            self.trajectory_pub.publish(message)
            self.last_trace_time = now

    def pose_message(self, x, y, yaw=0.0):
        result = PoseStamped()
        result.header.frame_id = self.cfg["frame_id"]
        result.header.stamp = self.get_clock().now().to_msg()
        result.pose.position.x, result.pose.position.y = float(x), float(y)
        result.pose.orientation.z = math.sin(yaw / 2.0)
        result.pose.orientation.w = math.cos(yaw / 2.0)
        return result

    def publish_reference(self):
        if self.alignment is None or not self.reference_points:
            return
        message = Path()
        message.header.frame_id = self.cfg["frame_id"]
        message.header.stamp = self.get_clock().now().to_msg()
        for x, y in self.reference_points:
            p = self.alignment.to_odom(Pose2D(x, y, 0.0))
            message.poses.append(self.pose_message(p.x, p.y))
        self.path_pub.publish(message)

    def close(self):
        if rclpy.ok():
            self.publish_velocity(Velocity())
        if self.recorder:
            self.recorder.close()


def main(args=None):
    rclpy.init(args=args)
    node = None
    try:
        node = CourseController()
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        if node is not None:
            node.close()
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
