"""占据栅格、射线更新与带障碍膨胀的 A*，不依赖 ROS。"""

from dataclasses import asdict, dataclass
from heapq import heappop, heappush
import json
import math
from pathlib import Path
from typing import Iterable, List, Optional, Sequence, Tuple


Point = Tuple[float, float]
Cell = Tuple[int, int]


@dataclass(frozen=True)
class GridSpec:
    resolution: float
    width: int
    height: int
    origin_x: float
    origin_y: float
    frame_id: str = "odom"

    def __post_init__(self):
        if not math.isfinite(self.resolution) or self.resolution <= 0:
            raise ValueError("resolution must be positive and finite")
        if (not isinstance(self.width, int) or not isinstance(self.height, int)
                or self.width < 1 or self.height < 1):
            raise ValueError("width and height must be positive integers")
        if self.width * self.height > 2_000_000:
            raise ValueError("grid is too large for this teaching implementation")
        if not all(math.isfinite(v) for v in (self.origin_x, self.origin_y)):
            raise ValueError("map origin must be finite")
        if not self.frame_id or self.frame_id.startswith("/"):
            raise ValueError("frame_id must be a nonempty TF frame without a leading slash")

    def contains(self, cell: Cell) -> bool:
        return 0 <= cell[0] < self.width and 0 <= cell[1] < self.height

    def world_to_cell(self, x: float, y: float) -> Optional[Cell]:
        if not (math.isfinite(x) and math.isfinite(y)):
            return None
        cell = (math.floor((x - self.origin_x) / self.resolution),
                math.floor((y - self.origin_y) / self.resolution))
        return cell if self.contains(cell) else None

    def cell_to_world(self, cell: Cell) -> Point:
        if not self.contains(cell):
            raise ValueError("cell is outside the grid")
        return (self.origin_x + (cell[0] + 0.5) * self.resolution,
                self.origin_y + (cell[1] + 0.5) * self.resolution)

    def index(self, cell: Cell) -> int:
        if not self.contains(cell):
            raise ValueError("cell is outside the grid")
        return cell[1] * self.width + cell[0]


def bresenham(start: Cell, end: Cell) -> List[Cell]:
    """返回包括起终点的整数栅格射线。"""
    x, y = start
    ex, ey = end
    dx, dy = abs(ex - x), abs(ey - y)
    sx, sy = (1 if x < ex else -1), (1 if y < ey else -1)
    error = dx - dy
    result = []
    while True:
        result.append((x, y))
        if (x, y) == (ex, ey):
            return result
        twice = 2 * error
        if twice > -dy:
            error -= dy
            x += sx
        if twice < dx:
            error += dx
            y += sy


def _clip_endpoint(spec: GridSpec, start: Point, end: Point) -> Point:
    """起点必须在图内；把射线终点裁到图内，不向边界写虚假障碍。"""
    sx, sy = start
    dx, dy = end[0] - sx, end[1] - sy
    # 留一个很小的余量，避免浮点除法把右/上边界映射到 width/height。
    epsilon = spec.resolution * 1e-8
    xmin, ymin = spec.origin_x + epsilon, spec.origin_y + epsilon
    xmax = spec.origin_x + spec.width * spec.resolution - epsilon
    ymax = spec.origin_y + spec.height * spec.resolution - epsilon
    t = 1.0
    if dx > 0:
        t = min(t, (xmax - sx) / dx)
    elif dx < 0:
        t = min(t, (xmin - sx) / dx)
    if dy > 0:
        t = min(t, (ymax - sy) / dy)
    elif dy < 0:
        t = min(t, (ymin - sy) / dy)
    t = max(0.0, t)
    return sx + t * dx, sy + t * dy


class OccupancyMapper:
    """在固定 odom 坐标系内累积雷达观测，不进行回环或漂移校正。"""

    def __init__(self, spec: GridSpec, hit_log_odds: float = 0.85,
                 miss_log_odds: float = -0.4, max_log_odds: float = 4.0):
        if not (hit_log_odds > 0 and miss_log_odds < 0 and max_log_odds > 0):
            raise ValueError("invalid log-odds update parameters")
        self.spec = spec
        self.hit_log_odds = hit_log_odds
        self.miss_log_odds = miss_log_odds
        self.max_log_odds = max_log_odds
        self.log_odds = [0.0] * (spec.width * spec.height)
        self.observed = bytearray(spec.width * spec.height)
        self.integrated_scans = 0

    def integrate_scan(self, sensor_x: float, sensor_y: float, yaw: float,
                       ranges: Iterable[float], angle_min: float,
                       angle_increment: float, range_min: float,
                       range_max: float) -> int:
        """返回本次采用的射线数。+inf 代表量程内无回波，NaN/-inf 丢弃。"""
        if not all(math.isfinite(v) for v in
                   (sensor_x, sensor_y, yaw, angle_min, angle_increment,
                    range_min, range_max)):
            return 0
        if angle_increment == 0 or range_min < 0 or range_max <= range_min:
            return 0
        start = self.spec.world_to_cell(sensor_x, sensor_y)
        if start is None:
            return 0
        free_cells, hit_cells = set(), set()
        used = 0
        for i, raw in enumerate(ranges):
            distance = float(raw)
            if math.isnan(distance) or distance == -math.inf:
                continue
            if math.isfinite(distance) and (distance < range_min or distance <= 0):
                continue
            if math.isfinite(distance) and distance > range_max:
                continue
            hit = math.isfinite(distance) and distance < range_max
            distance = min(distance, range_max)
            theta = yaw + angle_min + i * angle_increment
            endpoint = (sensor_x + distance * math.cos(theta),
                        sensor_y + distance * math.sin(theta))
            end_cell = self.spec.world_to_cell(*endpoint)
            hit = hit and end_cell is not None
            if end_cell is None:
                endpoint = _clip_endpoint(self.spec, (sensor_x, sensor_y), endpoint)
                end_cell = self.spec.world_to_cell(*endpoint)
            if end_cell is None:
                continue
            cells = bresenham(start, end_cell)
            if hit:
                free_cells.update(cells[:-1])
                hit_cells.add(cells[-1])
            else:
                free_cells.update(cells)
            used += 1
        # 同一扫描中的一格只更新一次，防止密集扇区过度降低占据概率。
        for cell in free_cells - hit_cells:
            self._update(cell, self.miss_log_odds)
        for cell in hit_cells:
            self._update(cell, self.hit_log_odds)
        if used:
            self.integrated_scans += 1
        return used

    def _update(self, cell: Cell, change: float):
        index = self.spec.index(cell)
        value = self.log_odds[index] + change
        self.log_odds[index] = max(-self.max_log_odds, min(self.max_log_odds, value))
        self.observed[index] = 1

    def occupancy(self) -> List[int]:
        return [round(100.0 / (1.0 + math.exp(-value))) if seen else -1
                for value, seen in zip(self.log_odds, self.observed)]

    @property
    def observed_cells(self) -> int:
        return sum(self.observed)


def _validate_data(spec: GridSpec, data: Sequence[int]):
    if len(data) != spec.width * spec.height:
        raise ValueError("occupancy data length does not match grid dimensions")
    if any(not isinstance(value, int) or isinstance(value, bool)
           or value < -1 or value > 100 for value in data):
        raise ValueError("occupancy values must be integers in [-1, 100]")


def save_grid(spec: GridSpec, data: Sequence[int], base_path: str,
              metadata: Optional[dict] = None) -> dict:
    """保存可视化 PGM、地图 YAML 和保留概率/坐标信息的 JSON。"""
    _validate_data(spec, data)
    observed = sum(value >= 0 for value in data)
    if observed == 0:
        raise ValueError("no observed cells; refusing to save an empty map")
    base = Path(base_path).expanduser()
    if base.suffix in (".pgm", ".yaml", ".json"):
        base = base.with_suffix("")
    base.parent.mkdir(parents=True, exist_ok=True)
    pgm, yaml, record = (base.with_suffix(s) for s in (".pgm", ".yaml", ".json"))
    pixels = bytearray()
    # 图像从上向下存储，OccupancyGrid 的第一行是地图 y 最小的一行。
    for y in range(spec.height - 1, -1, -1):
        for x in range(spec.width):
            value = data[y * spec.width + x]
            pixels.append(205 if value < 0 else round(254 * (1 - value / 100.0)))
    pgm_bytes = f"P5\n{spec.width} {spec.height}\n255\n".encode("ascii") + pixels
    yaml_text = (f"image: {json.dumps(pgm.name)}\n"
                 f"resolution: {spec.resolution}\n"
                 f"origin: [{spec.origin_x}, {spec.origin_y}, 0.0]\n"
                 "negate: 0\noccupied_thresh: 0.65\nfree_thresh: 0.196\nmode: trinary\n")
    payload = {"format_version": 1, "grid": asdict(spec),
               "observed_cells": observed, "data": list(data),
               "metadata": dict(metadata or {})}
    content = ((pgm, pgm_bytes), (yaml, yaml_text.encode("utf-8")),
               (record, json.dumps(payload, ensure_ascii=False).encode("utf-8")))
    for destination, blob in content:
        temporary = destination.with_name(destination.name + ".tmp")
        temporary.write_bytes(blob)
        temporary.replace(destination)
    return {"pgm": str(pgm), "yaml": str(yaml), "json": str(record),
            "observed_cells": observed}


def load_grid(path: str) -> Tuple[GridSpec, List[int], dict]:
    """读取本项目保存的 JSON；PGM/YAML 用于查看或第三方地图工具。"""
    filename = Path(path).expanduser()
    if filename.suffix != ".json":
        raise ValueError("map_file must be the .json written by /save_map")
    payload = json.loads(filename.read_text(encoding="utf-8"))
    if payload.get("format_version") != 1:
        raise ValueError("unsupported saved map format")
    spec = GridSpec(**payload["grid"])
    data = payload["data"]
    _validate_data(spec, data)
    if not any(value >= 0 for value in data):
        raise ValueError("saved map contains no observations")
    if not isinstance(payload.get("metadata", {}), dict):
        raise ValueError("map metadata must be an object")
    return spec, data, payload.get("metadata", {})


def inflated_blocked(spec: GridSpec, data: Sequence[int], radius: float = 0.18,
                     allow_unknown: bool = False, occupied_threshold: int = 65,
                     free_threshold: int = 35) -> bytearray:
    """未知和证据不足的格默认不可行；给机器人外接圆预留间隙。"""
    _validate_data(spec, data)
    if not math.isfinite(radius) or radius < 0:
        raise ValueError("inflation radius must be nonnegative and finite")
    if not 0 <= free_threshold < occupied_threshold <= 100:
        raise ValueError("require 0 <= free_threshold < occupied_threshold <= 100")
    blocked = bytearray(
        ((value < 0 and not allow_unknown) or value >= occupied_threshold
         or (free_threshold < value < occupied_threshold)) for value in data)
    result = bytearray(blocked)
    reach = math.ceil(radius / spec.resolution + 0.5)
    offsets = [(dx, dy) for dy in range(-reach, reach + 1)
               for dx in range(-reach, reach + 1)
               if math.hypot(max(abs(dx) - 0.5, 0) * spec.resolution,
                             max(abs(dy) - 0.5, 0) * spec.resolution) <= radius]
    # 只从障碍区域的边缘扩张，避免大片未知区重复做无用计算。
    for y in range(spec.height):
        for x in range(spec.width):
            idx = y * spec.width + x
            if not blocked[idx]:
                continue
            if not any(0 <= x + dx < spec.width and 0 <= y + dy < spec.height
                       and not blocked[(y + dy) * spec.width + x + dx]
                       for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                continue
            for dx, dy in offsets:
                nx, ny = x + dx, y + dy
                if 0 <= nx < spec.width and 0 <= ny < spec.height:
                    result[ny * spec.width + nx] = 1
    # 地图外侧也不可通行；不能让机器人圆形包络越出已定义的区域。
    for y in range(spec.height):
        for x in range(spec.width):
            distance = min(x + 0.5, y + 0.5, spec.width - x - 0.5,
                           spec.height - y - 0.5) * spec.resolution
            if distance < radius:
                result[y * spec.width + x] = 1
    return result


def astar_plan(spec: GridSpec, data: Sequence[int], start_xy: Point, goal_xy: Point,
               inflation_radius: float = 0.18, allow_unknown: bool = False,
               occupied_threshold: int = 65, free_threshold: int = 35) -> List[Point]:
    """八邻接 A*；拒绝越界和穿角，失败返回空列表。"""
    blocked = inflated_blocked(spec, data, inflation_radius, allow_unknown,
                               occupied_threshold, free_threshold)
    start, goal = spec.world_to_cell(*start_xy), spec.world_to_cell(*goal_xy)
    if start is None or goal is None:
        return []
    if blocked[spec.index(start)] or blocked[spec.index(goal)]:
        return []
    frontier = [(0.0, 0.0, start)]
    costs, previous = {start: 0.0}, {}
    moves = ((1, 0), (-1, 0), (0, 1), (0, -1),
             (1, 1), (1, -1), (-1, 1), (-1, -1))
    while frontier:
        _, cost, cell = heappop(frontier)
        if cost > costs.get(cell, math.inf):
            continue
        if cell == goal:
            cells = [cell]
            while cell in previous:
                cell = previous[cell]
                cells.append(cell)
            return [spec.cell_to_world(p) for p in reversed(cells)]
        for dx, dy in moves:
            neighbour = (cell[0] + dx, cell[1] + dy)
            if not spec.contains(neighbour) or blocked[spec.index(neighbour)]:
                continue
            if dx and dy:
                # 不能从两个相邻障碍的共同顶点斜穿过去。
                if (blocked[spec.index((cell[0] + dx, cell[1]))]
                        or blocked[spec.index((cell[0], cell[1] + dy))]):
                    continue
            new_cost = cost + math.hypot(dx, dy)
            if new_cost + 1e-12 >= costs.get(neighbour, math.inf):
                continue
            costs[neighbour] = new_cost
            previous[neighbour] = cell
            hx, hy = abs(goal[0] - neighbour[0]), abs(goal[1] - neighbour[1])
            estimate = max(hx, hy) + (math.sqrt(2) - 1) * min(hx, hy)
            heappush(frontier, (new_cost + estimate, new_cost, neighbour))
    return []
