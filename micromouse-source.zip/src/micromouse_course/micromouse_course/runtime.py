"""运行时使用的坐标换算、开环序列和重复访问检测。"""

from collections import defaultdict
from dataclasses import dataclass
import math

from .core import Pose2D, Velocity, ControlResult, wrap_angle


@dataclass(frozen=True)
class FrameAlignment:
    """把初次 odom 位姿对准已知出生位姿，不改变 ROS 的 TF 树。"""
    odom_start: Pose2D
    task_start: Pose2D

    def to_task(self, pose):
        angle = self.task_start.yaw - self.odom_start.yaw
        dx, dy = pose.x - self.odom_start.x, pose.y - self.odom_start.y
        return Pose2D(self.task_start.x + math.cos(angle) * dx - math.sin(angle) * dy,
                      self.task_start.y + math.sin(angle) * dx + math.cos(angle) * dy,
                      wrap_angle(pose.yaw + angle))

    def to_odom(self, pose):
        return FrameAlignment(self.task_start, self.odom_start).to_task(pose)


def unpack_points(values):
    if not values or len(values) % 2:
        raise ValueError("waypoints_xy must contain x,y pairs")
    if not all(math.isfinite(float(value)) for value in values):
        raise ValueError("path coordinates must be finite")
    return [(float(values[i]), float(values[i + 1])) for i in range(0, len(values), 2)]


def simplify_collinear(points):
    """仅删去同向共线内点，不把折角连接成对角捷径。"""
    result = []
    for point in points:
        p = (float(point[0]), float(point[1]))
        if not all(math.isfinite(v) for v in p):
            raise ValueError("path contains a non-finite coordinate")
        if result and math.hypot(p[0] - result[-1][0], p[1] - result[-1][1]) < 1e-9:
            continue
        while len(result) >= 2:
            a, b = result[-2], result[-1]
            ux, uy = b[0] - a[0], b[1] - a[1]
            vx, vy = p[0] - b[0], p[1] - b[1]
            if abs(ux * vy - uy * vx) > 1e-9 or ux * vx + uy * vy <= 0:
                break
            result.pop()
        result.append(p)
    return result


class OpenLoopProgram:
    """按仿真时间运行直行、停顿、原地转向；不使用里程计修正。"""
    def __init__(self, linear=0.12, straight_seconds=5.0,
                 angular=0.50, turn_seconds=math.pi):
        if not all(math.isfinite(v) and v > 0 for v in
                   (linear, straight_seconds, angular, turn_seconds)):
            raise ValueError("open-loop parameters must be positive and finite")
        self.segments = [(straight_seconds, Velocity(linear, 0.0), "OPEN_STRAIGHT"),
                         (1.0, Velocity(), "OPEN_PAUSE"),
                         (turn_seconds, Velocity(0.0, angular), "OPEN_TURN"),
                         (1.0, Velocity(), "OPEN_PAUSE")]
        self.start = None

    def update(self, now):
        if self.start is None:
            self.start = now
        elapsed = now - self.start
        if elapsed < 0:
            return ControlResult(Velocity(), "ERROR", fault="clock moved backwards")
        for duration, command, name in self.segments:
            if elapsed < duration:
                return ControlResult(command, name)
            elapsed -= duration
        return ControlResult(Velocity(), "DONE", done=True)


class LoopMonitor:
    """相同位置与朝向反复出现时停止，不能据此证明所有迷宫都可解。"""
    def __init__(self, cell_size=0.4, repeat_limit=4, min_gap=8.0,
                 min_travel=1.0):
        if cell_size <= 0 or repeat_limit < 2 or min_gap <= 0 or min_travel <= 0:
            raise ValueError("invalid loop monitor configuration")
        self.cell_size = cell_size
        self.repeat_limit = repeat_limit
        self.min_gap = min_gap
        self.min_travel = min_travel
        self.visits = defaultdict(list)
        self.previous_pose = None
        self.path_length = 0.0
        self.last_key = None
        self.last_count = 0

    def update(self, pose, now):
        if self.previous_pose is not None:
            self.path_length += math.hypot(pose.x - self.previous_pose.x,
                                          pose.y - self.previous_pose.y)
        self.previous_pose = pose
        key = (math.floor(pose.x / self.cell_size),
               math.floor(pose.y / self.cell_size),
               int(math.floor((wrap_angle(pose.yaw) + math.pi / 4) / (math.pi / 2))) % 4)
        # 原地等候和同一格内连续采样只算一次访问。
        if key == self.last_key:
            return False
        self.last_key = key
        history = self.visits[key]
        if history:
            last_time, last_distance = history[-1]
            if now - last_time < self.min_gap or self.path_length - last_distance < self.min_travel:
                return False
        history.append((now, self.path_length))
        self.last_count = len(history)
        return self.last_count >= self.repeat_limit


def sample_is_fresh(now_ros, stamp_ros, now_wall, received_wall,
                    ros_timeout, wall_timeout):
    if received_wall is None or stamp_ros is None:
        return False
    age = now_ros - stamp_ros
    return -0.05 <= age <= ros_timeout and 0 <= now_wall - received_wall <= wall_timeout


def finite_range_min(ranges, range_min, range_max):
    values = [float(r) for r in ranges
              if math.isfinite(r) and range_min <= r <= range_max]
    return min(values) if values else float(range_max)
