"""使用扫描时刻的 TF 将激光观测累计到 odom 栅格。"""

from datetime import datetime, timezone
import json
import math
from pathlib import Path

import rclpy
from rclpy.duration import Duration
from rclpy.node import Node
from rclpy.executors import ExternalShutdownException
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy, qos_profile_sensor_data
from rclpy.time import Time
from nav_msgs.msg import OccupancyGrid
from sensor_msgs.msg import LaserScan
from std_srvs.srv import Trigger
from tf2_ros import Buffer, TransformException, TransformListener

from micromouse_course.grid import GridSpec, OccupancyMapper, save_grid


class MappingNode(Node):
    def __init__(self):
        super().__init__("mapping_node")
        defaults = {
            "frame_id": "odom", "resolution": 0.05, "width": 320, "height": 320,
            "origin_x": -8.0, "origin_y": -8.0, "update_rate": 5.0,
            "publish_rate": 1.0, "scan_max_age": 1.0,
            "save_path": str(Path.home() / "micromouse_runs" / "map"),
        }
        for name, value in defaults.items():
            self.declare_parameter(name, value)
        get = lambda name: self.get_parameter(name).value
        self.spec = GridSpec(float(get("resolution")), int(get("width")),
                             int(get("height")), float(get("origin_x")),
                             float(get("origin_y")), str(get("frame_id")))
        self.mapper = OccupancyMapper(self.spec)
        self.save_path = str(get("save_path"))
        self.max_age = float(get("scan_max_age"))
        if (float(get("update_rate")) <= 0 or float(get("publish_rate")) <= 0
                or self.max_age <= 0):
            raise ValueError("map rates and scan_max_age must be positive")
        self.tf_buffer = Buffer(cache_time=Duration(seconds=10.0))
        self.tf_listener = TransformListener(self.tf_buffer, self)
        self.pending_scan = None
        self.last_scan_stamp = None
        self.last_warning_ns = None
        self.map_load_time = self.get_clock().now().to_msg()
        latched = QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL,
                             reliability=ReliabilityPolicy.RELIABLE)
        self.publisher = self.create_publisher(OccupancyGrid, "/map", latched)
        self.scan_subscription = self.create_subscription(
            LaserScan, "/scan", self._on_scan, qos_profile_sensor_data)
        self.save_service = self.create_service(Trigger, "/save_map", self._save)
        self.update_timer = self.create_timer(1.0 / float(get("update_rate")), self._update)
        self.publish_timer = self.create_timer(1.0 / float(get("publish_rate")), self._publish)
        self.get_logger().info(
            "Odometry grid mapping started; this node does not perform SLAM or loop closure.")

    def _on_scan(self, message):
        # 等待中的一帧不被新扫描反复覆盖，避免总在查询尚未到达的最新 TF。
        if self.pending_scan is None:
            self.pending_scan = message
        elif (Time.from_msg(message.header.stamp).nanoseconds
              < Time.from_msg(self.pending_scan.header.stamp).nanoseconds):
            self.pending_scan = message

    def _warn_throttled(self, message):
        now = self.get_clock().now().nanoseconds
        if (self.last_warning_ns is None or now < self.last_warning_ns
                or now - self.last_warning_ns > 5_000_000_000):
            self.get_logger().warning(message)
            self.last_warning_ns = now

    def _update(self):
        scan = self.pending_scan
        if scan is None:
            return
        stamp = Time.from_msg(scan.header.stamp)
        stamp_ns = stamp.nanoseconds
        if self.last_scan_stamp is not None and stamp_ns < self.last_scan_stamp:
            # 重置仿真时 odom 原点可能同时改变，不能继续叠加旧图。
            self.mapper = OccupancyMapper(self.spec)
            self.last_scan_stamp = None
            self.map_load_time = self.get_clock().now().to_msg()
            self.get_logger().warning("Scan time moved backwards; accumulated map was reset.")
        if stamp_ns == self.last_scan_stamp:
            self.pending_scan = None
            return
        age = (self.get_clock().now().nanoseconds - stamp_ns) * 1e-9
        if age > self.max_age or age < -self.max_age:
            self.pending_scan = None
            self._warn_throttled("Skipping a stale scan; check use_sim_time and /clock.")
            return
        if not scan.header.frame_id:
            self.pending_scan = None
            self._warn_throttled("LaserScan has an empty frame_id.")
            return
        try:
            # timeout=0 不阻塞单线程 executor，等待下一次定时器再尝试。
            transform = self.tf_buffer.lookup_transform(
                self.spec.frame_id, scan.header.frame_id, stamp,
                timeout=Duration(seconds=0.0))
        except TransformException as exc:
            self._warn_throttled(f"Waiting for scan-time TF: {exc}")
            return
        translation = transform.transform.translation
        q = transform.transform.rotation
        norm = math.sqrt(q.x * q.x + q.y * q.y + q.z * q.z + q.w * q.w)
        if not math.isfinite(norm) or norm < 1e-12:
            self.pending_scan = None
            self._warn_throttled("TF contains an invalid quaternion.")
            return
        x, y, z, w = q.x / norm, q.y / norm, q.z / norm, q.w / norm
        yaw = math.atan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))
        used = self.mapper.integrate_scan(
            translation.x, translation.y, yaw, scan.ranges, scan.angle_min,
            scan.angle_increment, scan.range_min, scan.range_max)
        self.last_scan_stamp = stamp_ns
        self.pending_scan = None
        if used == 0:
            self._warn_throttled("No usable scan rays, or laser origin is outside the grid.")

    def _publish(self):
        message = OccupancyGrid()
        message.header.stamp = self.get_clock().now().to_msg()
        message.header.frame_id = self.spec.frame_id
        message.info.map_load_time = self.map_load_time
        message.info.resolution = self.spec.resolution
        message.info.width = self.spec.width
        message.info.height = self.spec.height
        message.info.origin.position.x = self.spec.origin_x
        message.info.origin.position.y = self.spec.origin_y
        message.info.origin.orientation.w = 1.0
        message.data = self.mapper.occupancy()
        self.publisher.publish(message)

    def _save(self, request, response):
        del request
        try:
            paths = save_grid(self.spec, self.mapper.occupancy(), self.save_path, {
                "source": "laser_scan_with_odometry_tf",
                "integrated_scans": self.mapper.integrated_scans,
                "saved_at_utc": datetime.now(timezone.utc).isoformat(),
                "last_scan_stamp_ns": self.last_scan_stamp,
                "limitation": "No loop closure or odometry drift correction.",
            })
        except (OSError, ValueError) as exc:
            response.success = False
            response.message = str(exc)
        else:
            response.success = True
            response.message = json.dumps(paths, ensure_ascii=False)
        return response


def main(args=None):
    rclpy.init(args=args)
    node = None
    try:
        node = MappingNode()
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        if node is not None:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
