"""把任务场景坐标中的目标转换到 odom，交给全局规划节点。"""

import json
import math
import time

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, DurabilityPolicy, ReliabilityPolicy
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import String

from .core import Pose2D
from .runtime import FrameAlignment


class GoalSender(Node):
    def __init__(self):
        super().__init__("course_goal_sender")
        self.x = self.declare_parameter("x", 4.35).value
        self.y = self.declare_parameter("y", 3.50).value
        if not all(math.isfinite(v) for v in (self.x, self.y)):
            raise ValueError("x and y must be finite")
        self.pub = self.create_publisher(PoseStamped, "/goal_pose", 10)
        qos = QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL,
                         reliability=ReliabilityPolicy.RELIABLE)
        self.create_subscription(String, "/task_alignment", self.on_alignment, qos)
        self.alignment = None
        self.frame_id = "odom"

    def on_alignment(self, message):
        value = json.loads(message.data)
        self.alignment = FrameAlignment(Pose2D(**value["odom_start"]), Pose2D(**value["task_start"]))
        self.frame_id = value["frame_id"]

    def send(self):
        target = self.alignment.to_odom(Pose2D(self.x, self.y, 0.0))
        message = PoseStamped()
        message.header.frame_id = self.frame_id
        message.header.stamp = self.get_clock().now().to_msg()
        message.pose.position.x, message.pose.position.y = target.x, target.y
        message.pose.orientation.w = 1.0
        self.pub.publish(message)
        self.get_logger().info("goal sent: task=(%.3f, %.3f), odom=(%.3f, %.3f); check /planner_status" %
                               (self.x, self.y, target.x, target.y))


def main(args=None):
    rclpy.init(args=args)
    node = None
    try:
        node = GoalSender()
        deadline = time.monotonic() + 20.0
        while rclpy.ok() and time.monotonic() < deadline:
            rclpy.spin_once(node, timeout_sec=0.1)
            if node.alignment is not None and node.pub.get_subscription_count() > 0:
                node.send()
                # 等待已建立的可靠连接送达，不在订阅回调中阻塞。
                end = time.monotonic() + 0.5
                while rclpy.ok() and time.monotonic() < end:
                    rclpy.spin_once(node, timeout_sec=0.05)
                return
        raise RuntimeError("no alignment or goal subscriber; start course.launch.py mode:=global first")
    except KeyboardInterrupt:
        pass
    finally:
        if node is not None:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
