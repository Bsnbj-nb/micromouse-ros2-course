"""终端键盘发送人工速度请求，最终速度仍由控制节点统一审核。"""

import select
import sys
import termios
import time
import tty

import rclpy
from geometry_msgs.msg import Twist
from rclpy.node import Node


def main(args=None):
    if not sys.stdin.isatty():
        raise RuntimeError("teleop requires an interactive terminal")
    rclpy.init(args=args)
    node = Node("course_keyboard")
    publisher = node.create_publisher(Twist, "/teleop_cmd_vel", 10)
    original = termios.tcgetattr(sys.stdin)
    last_key = 0.0
    linear, angular = 0.0, 0.0
    print("w 前进，a 左转，d 右转，空格停止，q 退出。按住方向键；不支持倒车。", flush=True)
    try:
        tty.setcbreak(sys.stdin.fileno())
        while rclpy.ok():
            ready, _, _ = select.select([sys.stdin], [], [], 0.05)
            now = time.monotonic()
            if ready:
                key = sys.stdin.read(1)
                if key in ("q", "\x03"):
                    break
                if key == "w":
                    linear, angular = 0.10, 0.0
                elif key == "a":
                    linear, angular = 0.0, 0.50
                elif key == "d":
                    linear, angular = 0.0, -0.50
                else:
                    linear, angular = 0.0, 0.0
                last_key = now
            if now - last_key > 0.4:
                linear, angular = 0.0, 0.0
            message = Twist()
            message.linear.x, message.angular.z = linear, angular
            publisher.publish(message)
            rclpy.spin_once(node, timeout_sec=0.0)
    except KeyboardInterrupt:
        pass
    finally:
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, original)
        if rclpy.ok():
            publisher.publish(Twist())
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
