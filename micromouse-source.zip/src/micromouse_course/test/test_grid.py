"""栅格边界、雷达更新、地图保存和 A* 安全边界测试。"""

import json
import math
from pathlib import Path
import tempfile
import unittest

from micromouse_course.grid import (
    GridSpec, OccupancyMapper, astar_plan, bresenham,
    inflated_blocked, load_grid, save_grid,
)


class TestGridGeometry(unittest.TestCase):
    def test_coordinate_round_trip_and_negative_origin(self):
        spec = GridSpec(0.1, 20, 10, -1.0, -0.5)
        for cell in ((0, 0), (19, 9), (5, 7)):
            self.assertEqual(spec.world_to_cell(*spec.cell_to_world(cell)), cell)
        self.assertEqual(spec.world_to_cell(-1.0, -0.5), (0, 0))
        self.assertIsNone(spec.world_to_cell(-1.0001, 0.0))
        self.assertIsNone(spec.world_to_cell(1.0, 0.0))
        self.assertIsNone(spec.world_to_cell(0.0, 0.5))
        self.assertIsNone(spec.world_to_cell(math.nan, 0.0))

    def test_row_major_layout(self):
        spec = GridSpec(1.0, 5, 3, 0.0, 0.0)
        self.assertEqual(spec.index((2, 1)), 7)
        with self.assertRaises(ValueError):
            spec.index((-1, 1))

    def test_invalid_geometry(self):
        for args in ((0.0, 5, 5, 0, 0), (1, 0, 5, 0, 0),
                     (1, 5, 5, math.inf, 0), (1, 5, 5, 0, 0, "/odom")):
            with self.assertRaises(ValueError):
                GridSpec(*args)

    def test_bresenham_directions(self):
        self.assertEqual(bresenham((0, 0), (0, 3)), [(0, 0), (0, 1), (0, 2), (0, 3)])
        self.assertEqual(bresenham((3, 3), (0, 0)), [(3, 3), (2, 2), (1, 1), (0, 0)])
        self.assertEqual(bresenham((1, 1), (1, 1)), [(1, 1)])


class TestMapping(unittest.TestCase):
    def setUp(self):
        self.spec = GridSpec(1.0, 8, 8, 0.0, 0.0)
        self.mapper = OccupancyMapper(self.spec)

    def scan(self, ranges, yaw=0.0, angle_min=0.0, angle_increment=0.1,
             origin=(1.5, 1.5), range_max=6.0):
        return self.mapper.integrate_scan(*origin, yaw, ranges, angle_min,
                                           angle_increment, 0.1, range_max)

    def value(self, x, y):
        return self.mapper.occupancy()[self.spec.index((x, y))]

    def test_hit_marks_endpoint_only_and_keeps_unseen_unknown(self):
        self.assertEqual(self.scan([3.0]), 1)
        self.assertLess(self.value(1, 1), 50)
        self.assertLess(self.value(3, 1), 50)
        self.assertGreaterEqual(self.value(4, 1), 65)
        self.assertEqual(self.value(5, 1), -1)
        self.assertEqual(self.value(2, 2), -1)

    def test_infinite_return_clears_without_inventing_wall(self):
        self.scan([math.inf])
        row = [self.value(x, 1) for x in range(1, 8)]
        self.assertTrue(all(0 <= value < 50 for value in row))
        self.assertFalse(any(value >= 65 for value in self.mapper.occupancy()))

    def test_range_max_is_no_hit(self):
        self.scan([6.0])
        self.assertLess(self.value(7, 1), 50)
        self.assertFalse(any(value >= 65 for value in self.mapper.occupancy()))

    def test_invalid_samples_do_not_create_free_space(self):
        used = self.scan([math.nan, -math.inf, -1.0, 0.0, 0.05, 6.1])
        self.assertEqual(used, 0)
        self.assertEqual(self.mapper.observed_cells, 0)
        self.assertEqual(self.mapper.integrated_scans, 0)

    def test_endpoint_outside_map_is_clipped_and_not_occupied(self):
        self.scan([20.0], range_max=30.0)
        self.assertLess(self.value(7, 1), 50)
        self.assertFalse(any(value >= 65 for value in self.mapper.occupancy()))

    def test_sensor_outside_map_is_rejected(self):
        self.assertEqual(self.scan([2.0], origin=(-0.5, 1.5)), 0)
        self.assertEqual(self.mapper.observed_cells, 0)

    def test_yaw_transform_rotates_rays(self):
        self.scan([2.0], yaw=math.pi / 2)
        self.assertGreaterEqual(self.value(1, 3), 65)
        self.assertEqual(self.value(3, 1), -1)

    def test_negative_angle_increment(self):
        self.scan([2.0, 2.0], angle_min=math.pi / 2, angle_increment=-math.pi / 2)
        self.assertGreaterEqual(self.value(1, 3), 65)
        self.assertGreaterEqual(self.value(3, 1), 65)

    def test_repeated_beams_do_not_overweight_a_cell_within_one_scan(self):
        self.scan([3.0] * 10, angle_increment=1e-6)
        once = self.value(1, 1)
        self.assertGreater(once, 35)
        self.scan([3.0])
        self.assertLess(self.value(1, 1), 35)
        self.assertEqual(self.mapper.integrated_scans, 2)

    def test_hit_wins_over_free_for_same_cell_in_one_scan(self):
        self.scan([1.0, 3.0], angle_increment=1e-6)
        self.assertGreaterEqual(self.value(2, 1), 65)

    def test_log_odds_are_bounded(self):
        for _ in range(100):
            self.scan([3.0])
        self.assertTrue(all(-4.0 <= x <= 4.0 for x in self.mapper.log_odds))
        self.assertTrue(all(-1 <= x <= 100 for x in self.mapper.occupancy()))


class TestPlanning(unittest.TestCase):
    def setUp(self):
        self.spec = GridSpec(1.0, 7, 7, 0.0, 0.0)
        self.data = [0] * 49

    def block(self, x, y, value=100):
        self.data[self.spec.index((x, y))] = value

    def plan(self, start=(1.5, 3.5), goal=(5.5, 3.5), **kwargs):
        return astar_plan(self.spec, self.data, start, goal, **kwargs)

    def test_free_space_path_reaches_goal_and_uses_cell_centers(self):
        path = self.plan()
        self.assertEqual(path[0], (1.5, 3.5))
        self.assertEqual(path[-1], (5.5, 3.5))
        self.assertEqual(len(path), 5)

    def test_solid_wall_is_unreachable(self):
        for y in range(7):
            self.block(3, y)
        self.assertEqual(self.plan(), [])

    def test_gap_in_wall_is_used(self):
        for y in range(7):
            if y != 5:
                self.block(3, y)
        path = self.plan(inflation_radius=0.0)
        self.assertIn((3.5, 5.5), path)
        for x, y in path:
            self.assertEqual(self.data[self.spec.index(self.spec.world_to_cell(x, y))], 0)

    def test_diagonal_corner_cut_is_forbidden(self):
        spec = GridSpec(1.0, 2, 2, 0.0, 0.0)
        self.assertEqual(astar_plan(spec, [0, 100, 100, 0],
                                    (0.5, 0.5), (1.5, 1.5), 0.0), [])

    def test_unknown_is_blocked_unless_explicitly_allowed(self):
        for y in range(7):
            self.block(3, y, -1)
        self.assertEqual(self.plan(inflation_radius=0.0), [])
        self.assertTrue(self.plan(inflation_radius=0.0, allow_unknown=True))

    def test_uncertain_observation_is_not_assumed_free(self):
        for y in range(7):
            self.block(3, y, 50)
        self.assertEqual(self.plan(inflation_radius=0.0), [])

    def test_inflation_accounts_for_occupied_cell_area(self):
        self.block(3, 3)
        blocked = inflated_blocked(self.spec, self.data, 0.51)
        self.assertTrue(blocked[self.spec.index((2, 3))])
        self.assertFalse(blocked[self.spec.index((2, 2))])

    def test_robot_must_fit_inside_map_boundary(self):
        blocked = inflated_blocked(self.spec, self.data, 0.6)
        self.assertTrue(blocked[self.spec.index((0, 3))])
        self.assertFalse(blocked[self.spec.index((1, 3))])

    def test_blocked_start_or_goal_is_rejected(self):
        self.block(1, 3)
        self.assertEqual(self.plan(), [])
        self.data = [0] * 49
        self.block(5, 3)
        self.assertEqual(self.plan(), [])

    def test_outside_or_nonfinite_goal_is_rejected(self):
        self.assertEqual(self.plan(goal=(7.0, 3.5)), [])
        self.assertEqual(self.plan(goal=(math.nan, 3.5)), [])
        self.assertEqual(self.plan(start=(-0.01, 3.5)), [])

    def test_same_start_goal_is_single_point(self):
        self.assertEqual(self.plan(goal=(1.5, 3.5)), [(1.5, 3.5)])

    def test_input_map_is_not_modified(self):
        self.block(3, 3)
        original = list(self.data)
        self.plan()
        self.assertEqual(self.data, original)

    def test_invalid_occupancy_array_or_thresholds_are_rejected(self):
        with self.assertRaises(ValueError):
            inflated_blocked(self.spec, [0], 0.18)
        with self.assertRaises(ValueError):
            inflated_blocked(self.spec, [101] * 49, 0.18)
        with self.assertRaises(ValueError):
            inflated_blocked(self.spec, self.data, -1.0)
        with self.assertRaises(ValueError):
            inflated_blocked(self.spec, self.data, occupied_threshold=30, free_threshold=35)


class TestMapPersistence(unittest.TestCase):
    def test_round_trip_preserves_values_frame_resolution_and_origin(self):
        spec = GridSpec(0.05, 2, 2, -1.25, -0.75, "odom")
        values = [-1, 12, 88, 100]
        with tempfile.TemporaryDirectory() as directory:
            files = save_grid(spec, values, str(Path(directory) / "nested" / "map"),
                              {"integrated_scans": 3})
            loaded, data, metadata = load_grid(files["json"])
            self.assertEqual(loaded, spec)
            self.assertEqual(data, values)
            self.assertEqual(metadata["integrated_scans"], 3)
            self.assertEqual(files["observed_cells"], 3)
            self.assertIn("origin: [-1.25, -0.75, 0.0]", Path(files["yaml"]).read_text())

    def test_pgm_y_axis_is_flipped(self):
        spec = GridSpec(1.0, 2, 2, 0.0, 0.0)
        with tempfile.TemporaryDirectory() as directory:
            files = save_grid(spec, [0, -1, 100, 0], str(Path(directory) / "map"))
            blob = Path(files["pgm"]).read_bytes()
            self.assertEqual(list(blob.split(b"\n", 3)[3]), [0, 254, 254, 205])

    def test_empty_map_is_not_saved(self):
        spec = GridSpec(1.0, 2, 2, 0.0, 0.0)
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(ValueError):
                save_grid(spec, [-1] * 4, str(Path(directory) / "map"))
            self.assertEqual(list(Path(directory).iterdir()), [])

    def test_corrupt_saved_map_is_rejected(self):
        spec = GridSpec(1.0, 2, 2, 0.0, 0.0)
        with tempfile.TemporaryDirectory() as directory:
            files = save_grid(spec, [0] * 4, str(Path(directory) / "map"))
            path = Path(files["json"])
            payload = json.loads(path.read_text())
            payload["data"] = [0]
            path.write_text(json.dumps(payload))
            with self.assertRaises(ValueError):
                load_grid(str(path))
            with self.assertRaises(ValueError):
                load_grid(files["pgm"])


if __name__ == "__main__":
    unittest.main()
