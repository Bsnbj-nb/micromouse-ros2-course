"""检查任务坐标、开环时序、循环检测与消息新鲜度。"""

import math
import unittest

from micromouse_course.core import Pose2D, wrap_angle
from micromouse_course.runtime import (
    FrameAlignment, LoopMonitor, OpenLoopProgram, finite_range_min,
    sample_is_fresh, simplify_collinear, unpack_points,
)


class TestFrameAlignment(unittest.TestCase):
    def assertPoseAlmostEqual(self, actual, expected):
        self.assertAlmostEqual(actual.x, expected.x, places=10)
        self.assertAlmostEqual(actual.y, expected.y, places=10)
        self.assertAlmostEqual(wrap_angle(actual.yaw - expected.yaw), 0.0, places=10)

    def test_initial_pose_maps_to_configured_spawn(self):
        odom = Pose2D(-2.0, 3.0, -math.pi / 3)
        task = Pose2D(0.5, 1.5, math.pi / 4)
        alignment = FrameAlignment(odom, task)
        self.assertPoseAlmostEqual(alignment.to_task(odom), task)
        self.assertPoseAlmostEqual(alignment.to_odom(task), odom)

    def test_quarter_turn_changes_translation_axes(self):
        alignment = FrameAlignment(Pose2D(10.0, -5.0, 0.0),
                                   Pose2D(0.5, 0.5, math.pi / 2))
        self.assertPoseAlmostEqual(alignment.to_task(Pose2D(11.0, -5.0, 0.0)),
                                   Pose2D(0.5, 1.5, math.pi / 2))

    def test_round_trip_for_different_origins_and_headings(self):
        alignments = [
            FrameAlignment(Pose2D(0, 0, 0), Pose2D(0.5, 0.5, 0)),
            FrameAlignment(Pose2D(-3, 2, 2.9), Pose2D(5, -7, -2.8)),
            FrameAlignment(Pose2D(1, 3, -math.pi / 2), Pose2D(-2, 4, math.pi / 3)),
        ]
        poses = [Pose2D(0, 0, 0), Pose2D(-8.5, 3.4, 3.13),
                 Pose2D(4.7, -2.9, -3.13), Pose2D(1.5, 8, math.pi / 4)]
        for alignment in alignments:
            for pose in poses:
                with self.subTest(alignment=alignment, pose=pose):
                    self.assertPoseAlmostEqual(alignment.to_odom(alignment.to_task(pose)), pose)
                    self.assertPoseAlmostEqual(alignment.to_task(alignment.to_odom(pose)), pose)

    def test_alignment_preserves_distance(self):
        alignment = FrameAlignment(Pose2D(4, -3, 2.8), Pose2D(-2, 1, -1.7))
        a, b = Pose2D(2, 5, 0), Pose2D(6, 8, 1)
        ta, tb = alignment.to_task(a), alignment.to_task(b)
        self.assertAlmostEqual(math.hypot(tb.x - ta.x, tb.y - ta.y), 5.0)


class TestOpenLoopProgram(unittest.TestCase):
    def setUp(self):
        self.program = OpenLoopProgram(linear=0.1, straight_seconds=2.0,
                                        angular=0.5, turn_seconds=3.0)

    def test_first_tick_defines_time_origin(self):
        result = self.program.update(10.0)
        self.assertEqual(result.state, "OPEN_STRAIGHT")
        self.assertAlmostEqual(result.command.linear, 0.1)
        self.assertEqual(result.command.angular, 0.0)

    def test_segment_boundaries_and_final_stop(self):
        self.program.update(10.0)
        cases = [(11.99, "OPEN_STRAIGHT", 0.1, 0.0, False),
                 (12.0, "OPEN_PAUSE", 0.0, 0.0, False),
                 (13.0, "OPEN_TURN", 0.0, 0.5, False),
                 (16.0, "OPEN_PAUSE", 0.0, 0.0, False),
                 (17.0, "DONE", 0.0, 0.0, True),
                 (30.0, "DONE", 0.0, 0.0, True)]
        for now, state, linear, angular, done in cases:
            with self.subTest(now=now):
                result = self.program.update(now)
                self.assertEqual(result.state, state)
                self.assertEqual(result.command.linear, linear)
                self.assertEqual(result.command.angular, angular)
                self.assertEqual(result.done, done)

    def test_backwards_clock_stops(self):
        self.program.update(10.0)
        result = self.program.update(9.9)
        self.assertEqual(result.state, "ERROR")
        self.assertTrue(result.fault)
        self.assertFalse(result.done)
        self.assertEqual(result.command.linear, 0.0)
        self.assertEqual(result.command.angular, 0.0)

    def test_invalid_duration_or_velocity_is_rejected(self):
        for kwargs in ({"linear": 0.0}, {"straight_seconds": -1.0},
                       {"angular": math.inf}, {"turn_seconds": math.nan}):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                OpenLoopProgram(**kwargs)


class TestLoopMonitor(unittest.TestCase):
    def test_stationary_pose_does_not_count_repeated_visits(self):
        monitor = LoopMonitor()
        for t in range(200):
            self.assertFalse(monitor.update(Pose2D(1.2, 1.2, 0), float(t)))
        self.assertEqual(monitor.path_length, 0.0)
        self.assertEqual(monitor.last_count, 1)

    def test_turning_in_place_is_not_a_translation_loop(self):
        monitor = LoopMonitor(min_gap=1.0, repeat_limit=3)
        for t in range(100):
            self.assertFalse(monitor.update(Pose2D(1.2, 1.2, t * math.pi / 2), float(t)))
        self.assertEqual(monitor.path_length, 0.0)

    def test_four_complete_visits_with_travel_are_detected(self):
        monitor = LoopMonitor(repeat_limit=4, min_gap=8.0, min_travel=1.0)
        corners = [Pose2D(0.5, 0.5, 0), Pose2D(1.5, 0.5, math.pi / 2),
                   Pose2D(1.5, 1.5, math.pi), Pose2D(0.5, 1.5, -math.pi / 2)]
        results = [monitor.update(corners[i % 4], i * 3.0) for i in range(13)]
        self.assertFalse(any(results[:12]))
        self.assertTrue(results[12])
        self.assertEqual(monitor.last_count, 4)

    def test_fast_revisits_are_not_counted_again(self):
        monitor = LoopMonitor(repeat_limit=3, min_gap=8.0, min_travel=1.0)
        for i in range(10):
            pose = Pose2D(0.5 if i % 2 == 0 else 2.5, 0.5, 0.0)
            self.assertFalse(monitor.update(pose, i * 0.2))
        self.assertEqual(monitor.last_count, 1)

    def test_invalid_configuration_is_rejected(self):
        for kwargs in ({"cell_size": 0}, {"repeat_limit": 1},
                       {"min_gap": -1}, {"min_travel": 0}):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                LoopMonitor(**kwargs)


class TestPathUtilities(unittest.TestCase):
    def test_unpack_xy_pairs(self):
        self.assertEqual(unpack_points([0, 1, 2, 3]), [(0.0, 1.0), (2.0, 3.0)])

    def test_unpack_rejects_missing_or_nonfinite_coordinates(self):
        for values in ([], [1, 2, 3], [0, math.nan], [0, math.inf]):
            with self.subTest(values=values), self.assertRaises(ValueError):
                unpack_points(values)

    def test_collinear_reduction_preserves_corner(self):
        points = [(0, 0), (1, 0), (2, 0), (2, 1), (2, 2)]
        self.assertEqual(simplify_collinear(points), [(0, 0), (2, 0), (2, 2)])

    def test_collinear_reduction_preserves_u_turn(self):
        points = [(0, 0), (1, 0), (0, 0), (-1, 0)]
        self.assertEqual(simplify_collinear(points), [(0, 0), (1, 0), (-1, 0)])
        self.assertEqual(simplify_collinear([(0, 0), (1, 0), (0, 0), (1, 0)]),
                         [(0, 0), (1, 0), (0, 0), (1, 0)])

    def test_repeated_points_are_removed_but_endpoint_is_kept(self):
        self.assertEqual(simplify_collinear([(0, 0), (0, 0), (1, 1), (2, 2), (2, 2)]),
                         [(0, 0), (2, 2)])
        self.assertEqual(simplify_collinear([(1, 1)]), [(1, 1)])
        self.assertEqual(simplify_collinear([]), [])

    def test_nonfinite_path_coordinate_is_rejected(self):
        with self.assertRaises(ValueError):
            simplify_collinear([(0, 0), (math.inf, 1)])


class TestSampleFreshness(unittest.TestCase):
    def test_fresh_sample_and_exact_boundaries(self):
        self.assertTrue(sample_is_fresh(1.0, 1.0, 10.0, 10.0, 0.5, 2.0))
        self.assertTrue(sample_is_fresh(1.0, 0.5, 10.0, 8.0, 0.5, 2.0))
        self.assertTrue(sample_is_fresh(0.0, 0.05, 10.0, 10.0, 0.5, 2.0))

    def test_future_stale_and_missing_samples_are_rejected(self):
        cases = [(1.0, 1.06, 10.0, 10.0),
                 (1.0, 0.49, 10.0, 10.0),
                 (1.0, 1.0, 10.0, 7.9),
                 (1.0, 1.0, 10.0, 10.1),
                 (1.0, None, 10.0, 10.0),
                 (1.0, 1.0, 10.0, None)]
        for args in cases:
            with self.subTest(args=args):
                self.assertFalse(sample_is_fresh(*args, 0.5, 2.0))

    def test_paused_ros_clock_does_not_hide_wall_clock_timeout(self):
        self.assertTrue(sample_is_fresh(5.0, 5.0, 10.0, 10.0, 0.5, 2.0))
        self.assertFalse(sample_is_fresh(5.0, 5.0, 12.1, 10.0, 0.5, 2.0))

    def test_nonfinite_time_is_not_fresh(self):
        self.assertFalse(sample_is_fresh(math.nan, 0.0, 10.0, 10.0, 0.5, 2.0))
        self.assertFalse(sample_is_fresh(1.0, math.inf, 10.0, 10.0, 0.5, 2.0))
        self.assertFalse(sample_is_fresh(1.0, 1.0, math.nan, 10.0, 0.5, 2.0))

    def test_minimum_scan_discards_out_of_range_samples(self):
        self.assertEqual(finite_range_min([math.nan, math.inf, -math.inf, 0.0, 0.3, 2.0],
                                          0.12, 1.0), 0.3)
        self.assertEqual(finite_range_min([math.nan, math.inf, 0.0], 0.12, 3.5), 3.5)


if __name__ == "__main__":
    unittest.main()
