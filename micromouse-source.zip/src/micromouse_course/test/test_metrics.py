"""临时目录中的合成单元测试，不属于 Gazebo 实测结果。"""

from contextlib import redirect_stderr, redirect_stdout
import csv
import importlib.util
import io
import json
import math
from pathlib import Path
import tempfile
import unittest

from micromouse_course.core import ControlResult, LaserSectors, Pose2D, Velocity
from micromouse_course.metrics import RunRecorder


_script = Path(__file__).resolve().parents[1] / "tools" / "analyse_runs.py"
_spec = importlib.util.spec_from_file_location("course_run_analysis", _script)
analysis = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(analysis)


def configuration(mode="waypoints", **changes):
    config = {
        "mode": mode, "scene": "unit_test_scene", "spawn_x": 0.0,
        "spawn_y": 0.0, "spawn_yaw": 0.0, "linear_speed": 0.1,
        "angular_speed": 0.8, "position_tolerance": 0.07,
        "waypoints_xy": [0.0, 0.0, 1.0, 0.0],
        "reference_points_task": [[0.0, 0.0], [1.0, 0.0]],
        "data_origin": "synthetic_unit_test", "test_fixture": True,
    }
    config.update(changes)
    return config


def sample(recorder, now, x=0.0, y=0.0, v=0.0, w=0.0, state="WAIT_SCAN",
           done=False, valid=True, nearest=1.0, fault=""):
    pose = Pose2D(x, y, 0.0)
    result = ControlResult(Velocity(v, w), state, done, fault)
    sectors = LaserSectors(1.0, 1.0, 1.0, 1.0, 1.0, valid)
    recorder.record(now, pose, pose, result, sectors, nearest)


def create_run(root, mode="waypoints", completed=True, **changes):
    recorder = RunRecorder(root, mode, configuration(mode, **changes))
    sample(recorder, 100.0)
    sample(recorder, 105.0, v=0.1, state="WAYPOINT_0")
    sample(recorder, 107.0, x=0.5, y=0.2, v=0.1, state="WAYPOINT_1")
    sample(recorder, 109.0, x=1.0, state="DONE" if completed else "FRONT_BLOCKED",
           done=completed, fault="" if completed else "front emergency distance")
    recorder.close()
    return recorder


class TestRunRecorder(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="unit_metrics_")
        self.root = Path(self.temporary.name)
        self.recorders = []

    def tearDown(self):
        for recorder in self.recorders:
            recorder.close()
        self.temporary.cleanup()

    def recorder(self, mode="waypoints"):
        recorder = RunRecorder(self.root, mode, configuration(mode))
        self.recorders.append(recorder)
        return recorder

    def test_startup_wait_is_separate_from_completion_time(self):
        recorder = self.recorder()
        sample(recorder, 100.0)
        sample(recorder, 104.0)
        sample(recorder, 105.0, v=0.1, state="WAYPOINT_0")
        sample(recorder, 109.0, x=1.0, state="DONE", done=True)
        result = recorder.summary()
        self.assertTrue(result["task_completed"])
        self.assertEqual(result["completion_time_sim_s"], 4.0)
        self.assertEqual(result["startup_wait_sim_s"], 5.0)

    def test_goal_already_at_start_has_valid_zero_completion_time(self):
        recorder = self.recorder("point")
        sample(recorder, 100.0, state="DONE", done=True)
        result = recorder.summary()
        self.assertTrue(result["task_completed"])
        self.assertTrue(result["goal_reached"])
        self.assertEqual(result["completion_time_sim_s"], 0.0)
        self.assertIsNone(result["startup_wait_sim_s"])

    def test_open_loop_completion_does_not_claim_coordinate_goal(self):
        recorder = self.recorder("open_loop")
        sample(recorder, 10.0, v=0.1, state="OPEN_STRAIGHT")
        sample(recorder, 12.0, x=0.2, state="DONE", done=True)
        result = recorder.summary()
        self.assertTrue(result["task_completed"])
        self.assertFalse(result["goal_reached"])
        self.assertEqual(result["completion_time_sim_s"], 2.0)

    def test_failure_has_no_completion_time(self):
        recorder = self.recorder()
        sample(recorder, 1.0, v=0.1, state="WAYPOINT_0")
        sample(recorder, 2.0, state="FAULT", fault="unit-test failure")
        result = recorder.summary()
        self.assertFalse(result["task_completed"])
        self.assertFalse(result["goal_reached"])
        self.assertIsNone(result["completion_time_sim_s"])
        self.assertEqual(result["last_fault"], "unit-test failure")

    def test_close_flushes_all_rows_and_is_idempotent(self):
        recorder = self.recorder()
        sample(recorder, 1.0, v=0.1, state="WAYPOINT_0")
        sample(recorder, 2.0, x=1.0, state="DONE", done=True)
        recorder.close()
        recorder.close()
        sample(recorder, 3.0, x=2.0, state="DONE", done=True)
        with (recorder.directory / "trajectory.csv").open(newline="") as stream:
            rows = list(csv.DictReader(stream))
        summary = json.loads((recorder.directory / "summary.json").read_text())
        self.assertEqual(len(rows), 2)
        self.assertEqual(summary["samples"], 2)
        self.assertTrue(summary["clean_shutdown"])
        self.assertTrue(recorder.file.closed)
        self.assertEqual(rows[-1]["task_completed"], "True")

    def test_missing_pose_does_not_invent_sample(self):
        recorder = self.recorder()
        recorder.record(1.0, None, None, ControlResult(Velocity(), "WAIT_DATA"), None, 0.0)
        self.assertEqual(recorder.summary()["samples"], 0)
        self.assertIsNone(recorder.sim_start)

    def test_minimum_range_only_uses_valid_finite_observations(self):
        recorder = self.recorder()
        sample(recorder, 1.0, nearest=2.0)
        sample(recorder, 2.0, valid=False, nearest=0.01)
        sample(recorder, 3.0, nearest=math.inf)
        self.assertEqual(recorder.summary()["minimum_valid_scan_range_m"], 2.0)

    def test_distance_and_command_variation_use_recorded_samples(self):
        recorder = self.recorder()
        sample(recorder, 1.0, w=0.2)
        sample(recorder, 2.0, x=3.0, y=4.0, w=-0.3)
        sample(recorder, 3.0, x=3.0, y=4.0, w=0.0)
        self.assertAlmostEqual(recorder.summary()["path_length_odom_m"], 5.0)
        self.assertAlmostEqual(recorder.summary()["angular_command_total_variation"], 0.8)

    def test_metadata_preserves_test_origin_and_path(self):
        recorder = self.recorder()
        saved = json.loads((recorder.directory / "run_config.json").read_text())
        self.assertEqual(saved["data_origin"], "synthetic_unit_test")
        self.assertEqual(saved["reference_points_task"], [[0.0, 0.0], [1.0, 0.0]])


class TestRunAnalysis(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="unit_analysis_")
        self.root = Path(self.temporary.name)

    def tearDown(self):
        self.temporary.cleanup()

    def test_actual_rows_produce_cross_track_error_and_stop_counts(self):
        recorder = create_run(self.root)
        row = analysis.read_run(recorder.directory)
        self.assertTrue(row["task_completed"])
        self.assertEqual(row["completion_time_sim_s"], 4.0)
        self.assertAlmostEqual(row["path_cross_track_rmse_m"], math.sqrt(0.04 / 3))
        self.assertEqual(row["stop_samples"], 1)
        self.assertEqual(row["front_blocked_samples"], 0)

    def test_failure_is_not_reported_as_zero_second_completion(self):
        recorder = create_run(self.root, completed=False)
        row = analysis.read_run(recorder.directory)
        self.assertFalse(row["task_completed"])
        self.assertIsNone(row["completion_time_sim_s"])
        self.assertEqual(row["front_blocked_samples"], 1)

    def test_leftover_failure_duration_is_ignored_with_note(self):
        recorder = create_run(self.root, completed=False)
        path = recorder.directory / "summary.json"
        summary = json.loads(path.read_text())
        summary["completion_time_sim_s"] = 0.0
        path.write_text(json.dumps(summary))
        row = analysis.read_run(recorder.directory)
        self.assertIsNone(row["completion_time_sim_s"])
        self.assertIn("completion time was ignored", row["analysis_notes"])

    def test_single_point_or_missing_reference_has_no_rmse(self):
        point = create_run(self.root, "point", reference_points_task=[[1.0, 0.0]])
        wall = create_run(self.root, "wall_basic", reference_points_task=[])
        self.assertIsNone(analysis.read_run(point.directory)["path_cross_track_rmse_m"])
        self.assertIsNone(analysis.read_run(wall.directory)["path_cross_track_rmse_m"])

    def test_same_setup_pairs_waypoints_and_pure_pursuit(self):
        create_run(self.root, "waypoints")
        create_run(self.root, "pure_pursuit")
        rows, warnings = analysis.collect_runs(self.root)
        self.assertFalse(warnings)
        self.assertTrue(all(row["pp_waypoints_pair_available"] for row in rows))
        self.assertEqual(rows[0]["reference_path_hash"], rows[1]["reference_path_hash"])
        self.assertEqual(rows[0]["comparison_group_key"], rows[1]["comparison_group_key"])

    def test_different_path_does_not_create_comparison_pair(self):
        create_run(self.root, "waypoints")
        create_run(self.root, "pure_pursuit", reference_points_task=[[0.0, 0.0], [2.0, 0.0]])
        rows, _ = analysis.collect_runs(self.root)
        self.assertFalse(any(row["pp_waypoints_pair_available"] for row in rows))

    def test_different_speed_does_not_create_comparison_pair(self):
        create_run(self.root, "waypoints")
        create_run(self.root, "pure_pursuit", linear_speed=0.2)
        rows, _ = analysis.collect_runs(self.root)
        self.assertFalse(any(row["pp_waypoints_pair_available"] for row in rows))

    def test_different_scene_does_not_create_comparison_pair(self):
        create_run(self.root, "waypoints")
        create_run(self.root, "pure_pursuit", scene="different_unit_test_scene")
        rows, _ = analysis.collect_runs(self.root)
        self.assertFalse(any(row["pp_waypoints_pair_available"] for row in rows))

    def test_map_files_and_unrelated_directories_are_ignored(self):
        create_run(self.root)
        (self.root / "map.json").write_text("{}")
        (self.root / "map_assets").mkdir()
        rows, warnings = analysis.collect_runs(self.root)
        self.assertEqual(len(rows), 1)
        self.assertEqual(warnings, [])

    def test_incomplete_run_is_warned_and_skipped(self):
        create_run(self.root)
        incomplete = self.root / "incomplete_unit_run"
        incomplete.mkdir()
        (incomplete / "summary.json").write_text("{}")
        rows, warnings = analysis.collect_runs(self.root)
        self.assertEqual(len(rows), 1)
        self.assertEqual(len(warnings), 1)

    def test_mismatched_summary_or_false_success_is_rejected(self):
        recorder = create_run(self.root)
        path = recorder.directory / "summary.json"
        summary = json.loads(path.read_text())
        summary["samples"] += 1
        path.write_text(json.dumps(summary))
        with self.assertRaises(ValueError):
            analysis.read_run(recorder.directory)
        summary["samples"] -= 1
        summary["task_completed"] = False
        path.write_text(json.dumps(summary))
        with self.assertRaises(ValueError):
            analysis.read_run(recorder.directory)

    def test_no_data_fails_without_writing_sample_csv(self):
        output = self.root / "should_not_exist.csv"
        with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()) as errors:
            code = analysis.main(["--root", str(self.root), "--out", str(output)])
        self.assertEqual(code, 2)
        self.assertIn("No usable run records", errors.getvalue())
        self.assertFalse(output.exists())

    def test_output_csv_has_blank_failure_time_and_protects_sources(self):
        recorder = create_run(self.root, completed=False)
        records, _ = analysis.collect_runs(self.root)
        output = self.root / "unit_summary.csv"
        analysis.write_csv(records, output)
        with output.open(newline="", encoding="utf-8-sig") as stream:
            rows = list(csv.DictReader(stream))
        self.assertEqual(rows[0]["task_completed"], "False")
        self.assertEqual(rows[0]["completion_time_sim_s"], "")
        with self.assertRaises(ValueError):
            analysis.write_csv(records, recorder.directory / "trajectory.csv")


if __name__ == "__main__":
    unittest.main()
