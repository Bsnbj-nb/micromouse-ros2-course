"""配置接口和消息撤销边界检查；不启动 ROS，也不验证 DDS 或 Gazebo。"""

import ast
import json
import math
from pathlib import Path
from types import SimpleNamespace
import unittest

import yaml

from micromouse_course.core import Pose2D, Velocity, WaypointController
from micromouse_course.grid import GridSpec, astar_plan
from micromouse_course.runtime import FrameAlignment, simplify_collinear


PACKAGE = Path(__file__).resolve().parents[1]
MODULES = PACKAGE / "micromouse_course"


def syntax(path):
    return ast.parse(path.read_text(encoding="utf-8"), filename=str(path))


def declared_parameters(filename):
    """收集源码中默认参数字典和逐项声明的参数名。"""
    names = set()
    for node in ast.walk(syntax(MODULES / filename)):
        if isinstance(node, ast.Assign) and any(
                isinstance(target, ast.Name) and target.id == "defaults" for target in node.targets):
            names.update(key.value for key in node.value.keys if isinstance(key, ast.Constant))
        if (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                and node.func.attr == "declare_parameter" and node.args
                and isinstance(node.args[0], ast.Constant)):
            names.add(node.args[0].value)
    return names


def launch_nodes():
    nodes = []
    for node in ast.walk(syntax(PACKAGE / "launch" / "course.launch.py")):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "Node":
            values = {keyword.arg: keyword.value.value for keyword in node.keywords
                      if isinstance(keyword.value, ast.Constant)}
            nodes.append(values)
    return nodes


class PackageContractTests(unittest.TestCase):
    def test_yaml_node_names_and_parameters_match_launched_nodes(self):
        parameters = yaml.safe_load((PACKAGE / "config" / "course.yaml").read_text(encoding="utf-8"))
        expected = {"course_controller": "controller_node.py",
                    "grid_mapper": "mapping_node.py", "grid_planner": "planner_node.py"}
        launched = {node["name"] for node in launch_nodes()
                    if node.get("package") == "micromouse_course"}
        self.assertTrue(set(parameters).issubset(launched))
        for node_name, module_name in expected.items():
            with self.subTest(node=node_name):
                configured = set(parameters[node_name]["ros__parameters"])
                self.assertFalse(configured - declared_parameters(module_name))

    def test_launched_executables_have_installed_python_entry_points(self):
        tree = syntax(PACKAGE / "setup.py")
        calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call)
                 and isinstance(node.func, ast.Name) and node.func.id == "setup"]
        keywords = {item.arg: item.value for item in calls[0].keywords}
        entries = ast.literal_eval(keywords["entry_points"])["console_scripts"]
        available = {}
        for entry in entries:
            executable, target = [part.strip() for part in entry.split("=", 1)]
            module, function = target.split(":", 1)
            source = PACKAGE / (module.replace(".", "/") + ".py")
            self.assertTrue(source.is_file(), str(source))
            functions = {node.name for node in syntax(source).body if isinstance(node, ast.FunctionDef)}
            self.assertIn(function, functions)
            available[executable] = target
        for node in launch_nodes():
            if node.get("package") == "micromouse_course":
                self.assertIn(node["executable"], available)

    def test_only_controller_can_publish_robot_velocity(self):
        publishers = []
        for path in MODULES.glob("*.py"):
            for node in ast.walk(syntax(path)):
                if (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                        and node.func.attr == "create_publisher" and len(node.args) >= 2
                        and isinstance(node.args[1], ast.Constant)
                        and node.args[1].value == "/cmd_vel"):
                    publishers.append(path.name)
        self.assertEqual(publishers, ["controller_node.py"])

    def test_mapping_planning_and_rviz_share_odom_frame(self):
        parameters = yaml.safe_load((PACKAGE / "config" / "course.yaml").read_text(encoding="utf-8"))
        rviz = yaml.safe_load((PACKAGE / "rviz" / "course.rviz").read_text(encoding="utf-8"))
        mapper = parameters["grid_mapper"]["ros__parameters"]["frame_id"]
        planner = parameters["grid_planner"]["ros__parameters"]["frame_id"]
        fixed = rviz["Visualization Manager"]["Global Options"]["Fixed Frame"]
        self.assertEqual(mapper, planner)
        self.assertEqual(planner, fixed)
        self.assertEqual(fixed, "odom")


def stamp(seconds):
    sec = int(seconds)
    return SimpleNamespace(sec=sec, nanosec=int(round((seconds - sec) * 1e9)))


def header(frame="odom", seconds=10.0):
    return SimpleNamespace(frame_id=frame, stamp=stamp(seconds))


class PathMessage:
    def __init__(self):
        self.header = header()
        self.poses = []


def pose_message(x, y, frame="odom", seconds=10.0):
    return SimpleNamespace(header=header(frame, seconds), pose=SimpleNamespace(
        position=SimpleNamespace(x=x, y=y, z=0.0),
        orientation=SimpleNamespace(x=0.0, y=0.0, z=0.0, w=1.0)))


def path_message(points, frame="odom"):
    message = PathMessage()
    message.header.frame_id = frame
    message.poses = [pose_message(x, y, frame) for x, y in points]
    return message


class Publisher:
    def __init__(self):
        self.messages = []

    def publish(self, message):
        self.messages.append(message)


def callback_class(filename, class_name, namespace):
    """加载原类定义，用轻量消息对象执行实际回调，不模拟中间件。"""
    source = MODULES / filename
    node = next(node for node in syntax(source).body
                if isinstance(node, ast.ClassDef) and node.name == class_name)
    unit = ast.Module(body=[node], type_ignores=[])
    globals_ = dict(namespace, Node=object, math=math, json=json, Path=PathMessage)
    exec(compile(unit, str(source), "exec"), globals_)
    return globals_[class_name]


PLANNER = callback_class("planner_node.py", "PlannerNode", {
    "GridSpec": GridSpec, "astar_plan": astar_plan,
})
CONTROLLER = callback_class("controller_node.py", "CourseController", {
    "Pose2D": Pose2D, "Velocity": Velocity, "WaypointController": WaypointController,
    "simplify_collinear": simplify_collinear,
})


def planner_fixture():
    node = PLANNER.__new__(PLANNER)
    node.frame_id = "odom"
    node.goal_xy = (1.0, 1.0)
    node.pending = False
    node.spec = GridSpec(0.1, 10, 10, 0.0, 0.0)
    node.data = [0] * 100
    node.map_load_stamp = (1, 0)
    node.robot_xy = (0.1, 0.1)
    node.odom_stamp_ns = 10_000_000_000
    node.path_publisher = Publisher()
    node.get_clock = lambda: SimpleNamespace(now=lambda: SimpleNamespace(
        nanoseconds=10_000_000_000, to_msg=lambda: stamp(10.0)))
    node.statuses = []
    node._status = lambda state, message, **extra: node.statuses.append(state)
    return node


class PlannerCancellationTests(unittest.TestCase):
    def test_invalid_goal_cancels_old_path_and_old_goal(self):
        node = planner_fixture()
        node._on_goal(pose_message(1, 1, frame="map"))
        self.assertFalse(node.path_publisher.messages[-1].poses)
        self.assertIsNone(node.goal_xy)
        self.assertFalse(node.pending)
        self.assertEqual(node.statuses[-1], "INVALID_GOAL")

    def test_invalid_map_discards_previous_map_and_path(self):
        node = planner_fixture()
        node._on_map(SimpleNamespace(header=header("wrong_frame")))
        self.assertIsNone(node.spec)
        self.assertIsNone(node.data)
        self.assertFalse(node.path_publisher.messages[-1].poses)
        self.assertTrue(node.pending)

    def test_map_origin_change_revokes_path(self):
        node = planner_fixture()
        info = SimpleNamespace(resolution=.1, width=10, height=10,
            origin=pose_message(-1, 0).pose, map_load_time=stamp(1))
        node._on_map(SimpleNamespace(header=header(), info=info, data=[0]*100))
        self.assertEqual(node.spec.origin_x, -1)
        self.assertFalse(node.path_publisher.messages[-1].poses)
        self.assertTrue(node.pending)

    def test_bad_odometry_revokes_path(self):
        node = planner_fixture()
        node._on_odom(SimpleNamespace(header=header("wrong_frame")))
        self.assertIsNone(node.robot_xy)
        self.assertFalse(node.path_publisher.messages[-1].poses)

    def test_odometry_time_reset_revokes_path(self):
        node = planner_fixture()
        message = SimpleNamespace(header=header(seconds=2),
                                  pose=SimpleNamespace(pose=pose_message(.2, .2).pose))
        node._on_odom(message)
        self.assertFalse(node.path_publisher.messages[-1].poses)
        self.assertTrue(node.pending)
        self.assertEqual(node.odom_stamp_ns, 2_000_000_000)


def controller_fixture():
    node = CONTROLLER.__new__(CONTROLLER)
    node.mode = "global"
    node.cfg = {"frame_id": "odom", "linear_speed": .14,
                "angular_speed": .8, "record": False}
    node.pending_path = None
    node.path_signature = ((0.0, 0.0), (1.0, 1.0))
    node.algorithm = object()
    node.alignment = FrameAlignment(Pose2D(0,0,0), Pose2D(.5,.5,0))
    node.finished = False
    node.commands = []
    node.publish_velocity = node.commands.append
    node.publish_reference = lambda: None
    node.now_seconds = lambda: 10.0
    return node


class ControllerPathCancellationTests(unittest.TestCase):
    def test_empty_path_cancels_a_path_cached_before_odometry(self):
        node = controller_fixture()
        node.alignment = None
        node.on_path(path_message([(0,0), (1,0)]))
        self.assertIsNotNone(node.pending_path)
        node.on_path(path_message([]))
        self.assertIsNone(node.pending_path)
        self.assertIsNone(node.algorithm)
        self.assertIsNone(node.path_signature)
        self.assertEqual(node.commands[-1], Velocity())

    def test_wrong_frame_cancels_cached_and_running_path(self):
        node = controller_fixture()
        node.pending_path = path_message([(0,0), (1,0)])
        node.on_path(path_message([(0,0), (1,0)], frame="map"))
        self.assertIsNone(node.pending_path)
        self.assertIsNone(node.algorithm)
        self.assertEqual(node.commands[-1], Velocity())

    def test_nonfinite_path_cannot_leave_old_controller_running(self):
        node = controller_fixture()
        node.on_path(path_message([(0,0), (math.nan, 1)]))
        self.assertIsNone(node.algorithm)
        self.assertIsNone(node.path_signature)
        self.assertEqual(node.commands[-1], Velocity())

    def test_valid_path_is_transformed_from_odom_to_task_coordinates(self):
        node = controller_fixture()
        node.on_path(path_message([(0,0), (1,0)]))
        self.assertEqual(node.algorithm.waypoints, [(.5,.5), (1.5,.5)])
        self.assertFalse(node.finished)


if __name__ == "__main__":
    unittest.main()
