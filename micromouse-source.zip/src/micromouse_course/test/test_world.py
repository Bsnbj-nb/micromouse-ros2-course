"""检查世界资产结构和迷宫拓扑，不代表 Gazebo 物理仿真验收。"""

from collections import deque
import importlib.util
from pathlib import Path
import unittest
import xml.etree.ElementTree as ET


PACKAGE = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("generate_world", PACKAGE / "tools/generate_world.py")
generator = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(generator)


class WorldTests(unittest.TestCase):
    def test_maze_is_connected_tree(self):
        neighbors = generator.graph()
        queue, visited = deque([generator.START]), {generator.START}
        while queue:
            for cell in neighbors[queue.popleft()]:
                if cell not in visited:
                    visited.add(cell)
                    queue.append(cell)
        self.assertEqual(len(visited), generator.COLS * generator.ROWS)
        self.assertEqual(len(generator.PASSAGES), len(visited) - 1)

    def test_left_hand_rule_reaches_real_exit(self):
        walk = generator.left_hand_cell_walk()
        self.assertEqual(walk[0], generator.START)
        self.assertEqual(walk[-2], generator.GOAL)
        self.assertEqual(walk[-1], (generator.COLS, generator.ROWS - 1))
        # 经过死胡同后确有返回；不能把最短路线硬编码为墙跟随的验证结果。
        self.assertIn((0, 3), walk)
        self.assertGreater(walk.count((0, 2)), 1)

    def test_every_passage_is_open_and_every_other_edge_has_a_wall(self):
        names = {row[0] for row in generator.maze_wall_segments()}
        neighbors = generator.graph()
        for x in range(1, generator.COLS):
            for y in range(generator.ROWS):
                is_open = (x, y) in neighbors[(x - 1, y)]
                self.assertEqual(f"wall_v_{x}_{y}" not in names, is_open)
        for y in range(1, generator.ROWS):
            for x in range(generator.COLS):
                is_open = (x, y) in neighbors[(x, y - 1)]
                self.assertEqual(f"wall_h_{x}_{y}" not in names, is_open)
        self.assertNotIn("wall_v_0_0", names)
        self.assertNotIn("wall_v_4_3", names)

    def test_all_obstacles_have_matching_collision_geometry(self):
        for path in sorted((PACKAGE / "worlds").glob("*.world")):
            with self.subTest(world=path.name):
                root = ET.parse(path).getroot()
                self.assertEqual(root.tag, "sdf")
                self.assertEqual(root.attrib["version"], "1.6")
                self.assertFalse(root.findall(".//include"))
                models = root.findall("world/model")
                self.assertGreater(len(models), 1)
                for model in models:
                    self.assertEqual(model.findtext("static"), "true")
                    link = model.find("link")
                    collision = link.findtext("collision/geometry/box/size")
                    visual = link.findtext("visual/geometry/box/size")
                    self.assertEqual(collision, visual)
                    self.assertTrue(all(float(value) > 0 for value in collision.split()))

    def test_spawn_has_clearance_and_doorways_fit_burger(self):
        x, y = 0.5, 0.5
        robot_radius = 0.12
        for _, wx, wy, sx, sy in generator.maze_wall_segments():
            dx = max(abs(x - wx) - sx / 2, 0.0)
            dy = max(abs(y - wy) - sy / 2, 0.0)
            self.assertGreater((dx * dx + dy * dy) ** 0.5, robot_radius)
        self.assertGreater(generator.CELL_SIZE - generator.WALL_THICKNESS, 2 * robot_radius)

    def test_committed_assets_match_generator(self):
        builders = {"course_maze": generator.course_maze, "control_arena": generator.control_arena,
                    "failure_loop": generator.failure_loop}
        for name, builder in builders.items():
            actual = ET.parse(PACKAGE / "worlds" / f"{name}.world").getroot()
            expected = builder()
            # ElementTree 缩进属于排版，结构数据应保持一致。
            def semantic(element):
                return (element.tag, tuple(sorted(element.attrib.items())), (element.text or "").strip(),
                        tuple(semantic(child) for child in element))
            self.assertEqual(semantic(actual), semantic(expected), name)


if __name__ == "__main__":
    unittest.main()
