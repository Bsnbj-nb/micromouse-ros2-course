"""Signal/callback lifetime regression checks; real ROS runs are separate.

AI-assisted tests added with the 2026-11-02 recorder shutdown fix.
The ROS and signal adapters are faked so no real process is interrupted.
"""
import importlib.util
from pathlib import Path
import signal
import sys
from types import ModuleType, SimpleNamespace
import unittest
from unittest.mock import patch


class ExternalShutdown(Exception):
    pass


def module(name, **members):
    result = ModuleType(name)
    result.__dict__.update(members)
    return result


class ShutdownTests(unittest.TestCase):
    def run_case(self, action, constructor_failure=False, destroy_failure=False):
        events = []
        handlers = {signal.SIGINT: 'previous_int', signal.SIGTERM: 'previous_term'}
        alive = [False]
        options = SimpleNamespace(NO=object())

        def init(**kwargs):
            self.assertIs(kwargs['signal_handler_options'], options.NO)
            alive[0] = True
            events.append('init')

        def shutdown():
            alive[0] = False
            events.append('context_closed')

        def set_signal(number, handler):
            old = handlers[number]
            handlers[number] = handler
            return old

        class Executor:
            def add_node(self, node):
                events.append('node_added')

            def spin_once(self, timeout_sec):
                events.append('callback_started')
                action(handlers, alive, events)
                events.append('callback_finished')

            def shutdown(self):
                events.append('executor_stopped')

        class FakeNode:
            def __init__(self):
                if constructor_failure:
                    raise ValueError('constructor failure')
                self.file = SimpleNamespace(close=lambda: events.append('file_closed'))

            def destroy_node(self):
                events.append('node_destroyed')
                if destroy_failure:
                    raise ValueError('destroy failure')

        ros = module('rclpy', init=init, ok=lambda: alive[0], shutdown=shutdown)
        stubs = {
            'rclpy': ros,
            'rclpy.node': module('rclpy.node', Node=object),
            'rclpy.executors': module('rclpy.executors', ExternalShutdownException=ExternalShutdown,
                                      SingleThreadedExecutor=Executor),
            'rclpy.signals': module('rclpy.signals', SignalHandlerOptions=options),
            'rclpy.qos': module('rclpy.qos', qos_profile_sensor_data=object()),
            'gazebo_msgs': module('gazebo_msgs'),
            'gazebo_msgs.msg': module('gazebo_msgs.msg', ModelStates=object),
            'sensor_msgs': module('sensor_msgs'),
            'sensor_msgs.msg': module('sensor_msgs.msg', LaserScan=object),
        }
        path = Path(__file__).resolve().parents[1] / 'micromouse_course/truth_recorder.py'
        spec = importlib.util.spec_from_file_location('recorder_for_shutdown_test', path)
        target = importlib.util.module_from_spec(spec)
        error = None
        with patch.dict(sys.modules, stubs), patch.object(signal, 'signal', set_signal):
            spec.loader.exec_module(target)
            target.TruthRecorder = FakeNode
            try:
                target.main()
            except Exception as exc:
                error = exc
        self.assertFalse(alive[0])
        self.assertEqual(handlers, {signal.SIGINT: 'previous_int', signal.SIGTERM: 'previous_term'})
        return events, error

    def interrupt(self, signum, repeated=False):
        def action(handlers, alive, events):
            handlers[signum](signum, None)
            if repeated:
                handlers[signum](signum, None)
            self.assertTrue(alive[0], 'signal must not destroy a live callback context')
        events, error = self.run_case(action)
        self.assertIsNone(error)
        self.assertEqual(events[-5:], ['callback_finished', 'executor_stopped',
                                      'node_destroyed', 'file_closed', 'context_closed'])

    def test_sigint_finishes_current_callback_before_cleanup(self):
        self.interrupt(signal.SIGINT)

    def test_sigterm_finishes_current_callback_before_cleanup(self):
        self.interrupt(signal.SIGTERM)

    def test_repeated_signal_does_not_interrupt_cleanup(self):
        self.interrupt(signal.SIGINT, repeated=True)

    def test_unexpected_runtime_error_is_not_hidden(self):
        def action(*unused):
            raise RuntimeError('real callback failure')
        events, error = self.run_case(action)
        self.assertIsInstance(error, RuntimeError)
        self.assertEqual(events[-4:], ['executor_stopped', 'node_destroyed',
                                      'file_closed', 'context_closed'])

    def test_context_closes_when_node_construction_fails(self):
        events, error = self.run_case(lambda *args: None, constructor_failure=True)
        self.assertIsInstance(error, ValueError)
        self.assertEqual(events, ['init', 'context_closed'])

    def test_file_and_context_close_even_if_node_cleanup_fails(self):
        def action(handlers, alive, events):
            handlers[signal.SIGINT](signal.SIGINT, None)
        events, error = self.run_case(action, destroy_failure=True)
        self.assertIsInstance(error, ValueError)
        self.assertEqual(events[-2:], ['file_closed', 'context_closed'])


if __name__ == '__main__':
    unittest.main()
