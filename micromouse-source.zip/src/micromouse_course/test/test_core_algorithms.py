"""算法级回归检查；不代替 Gazebo 端到端验收。"""

import math
import unittest

from micromouse_course.core import (
    LaserSectors, PointController, Pose2D, PurePursuitController,
    Velocity, WallConfig, WallFollower, WaypointController,
    extract_sectors, wrap_angle, yaw_from_quaternion,
)


def sectors(front=2.0, left=0.32, right=0.60, heading=0.0):
    return LaserSectors(front, left, right, 0.5, 0.8, wall_heading=heading)


class GeometryTests(unittest.TestCase):
    def test_wrap_crosses_pi_by_short_route(self):
        self.assertAlmostEqual(wrap_angle(math.radians(-179 - 179)), math.radians(2))

    def test_wrap_many_revolutions(self):
        self.assertAlmostEqual(wrap_angle(12 * math.pi + 0.2), 0.2)

    def test_nonunit_quaternion_is_normalized(self):
        yaw = 1.2
        self.assertAlmostEqual(yaw_from_quaternion(0, 0, 2 * math.sin(yaw/2),
                                                   2 * math.cos(yaw/2)), yaw)

    def test_zero_quaternion_is_rejected(self):
        with self.assertRaises(ValueError):
            yaw_from_quaternion(0, 0, 0, 0)

    def test_nonfinite_quaternion_is_rejected(self):
        with self.assertRaises(ValueError):
            yaw_from_quaternion(0, math.nan, 0, 1)


class ScanTests(unittest.TestCase):
    def test_angle_min_not_zero(self):
        ranges = [2.0] * 360
        ranges[180] = 0.42  # -pi + 180 * pi/180 = 0
        reading = extract_sectors(ranges, -math.pi, math.pi / 180, 0.12, 3.5)
        self.assertTrue(reading.valid)
        self.assertAlmostEqual(reading.front, 0.42)

    def test_clockwise_scan(self):
        ranges = [2.0] * 360
        ranges[270] = 0.4
        reading = extract_sectors(ranges, 0, -math.pi / 180, 0.12, 3.5)
        self.assertAlmostEqual(reading.left, 0.4)

    def test_positive_inf_is_clear_within_range(self):
        reading = extract_sectors([math.inf] * 360, 0, math.pi / 180, 0.12, 3.5)
        self.assertTrue(reading.valid)
        self.assertEqual(reading.front, 3.5)

    def test_nan_sector_is_not_clear(self):
        ranges = [1.0] * 360
        for index in list(range(0, 16)) + list(range(345, 360)):
            ranges[index] = math.nan
        reading = extract_sectors(ranges, 0, math.pi / 180, 0.12, 3.5)
        self.assertFalse(reading.valid)
        self.assertEqual(reading.front, 0.0)

    def test_invalid_outliers_do_not_become_obstacles(self):
        ranges = [1.0] * 360
        ranges[:6] = [math.nan, -math.inf, -1, 0, 0.05, 6.0]
        reading = extract_sectors(ranges, 0, math.pi / 180, 0.12, 3.5)
        self.assertTrue(reading.valid)
        self.assertEqual(reading.front, 1.0)

    def test_partial_scan_cannot_supply_missing_side(self):
        reading = extract_sectors([1.0] * 61, -math.pi / 6, math.pi / 180, 0.12, 3.5)
        self.assertFalse(reading.valid)
        self.assertEqual(reading.left, 0.0)

    def test_invalid_metadata(self):
        for increment in [0.0, math.inf, math.nan]:
            with self.subTest(increment=increment):
                reading = extract_sectors([1.0]*360, 0, increment, 0.12, 3.5)
                self.assertFalse(reading.valid)

    def test_parallel_left_wall_has_zero_heading(self):
        ranges = []
        for degree in range(360):
            sine = math.sin(math.radians(degree))
            ranges.append(0.32/sine if sine > 0.10 else math.inf)
        reading = extract_sectors(ranges, 0, math.pi/180, 0.12, 3.5)
        self.assertIsNotNone(reading.wall_heading)
        self.assertAlmostEqual(reading.wall_heading, 0, places=6)


class WaypointTests(unittest.TestCase):
    def test_point_rotates_before_translation(self):
        result = PointController((1, 0)).update(Pose2D(0, 0, math.pi/2))
        self.assertEqual(result.command.linear, 0)
        self.assertLess(result.command.angular, 0)

    def test_velocity_is_limited(self):
        result = PointController((100, 0)).update(Pose2D(0, 0, 0))
        self.assertLessEqual(result.command.linear, 0.16)

    def test_terminal_state_stays_stopped(self):
        controller = PointController((1, 0))
        self.assertTrue(controller.update(Pose2D(1, 0, 0)).done)
        result = controller.update(Pose2D(1.5, 0, 0))
        self.assertTrue(result.done)
        self.assertEqual(result.command, Velocity())

    def test_waypoints_are_not_skipped_by_nearest_point(self):
        controller = WaypointController([(1, 0), (0, 0)])
        result = controller.update(Pose2D(0, 0, 0))
        self.assertEqual(controller.index, 0)
        self.assertFalse(result.done)
        self.assertGreater(result.command.linear, 0)

    def test_repeated_waypoints_finish(self):
        controller = WaypointController([(0, 0), (0, 0)])
        self.assertTrue(controller.update(Pose2D(0, 0, 0)).done)

    def test_bad_parameter_rejected(self):
        with self.assertRaises(ValueError):
            PointController((1, 1), linear_speed=math.nan)

    def test_bad_odometry_stops(self):
        result = PointController((1, 0)).update(Pose2D(math.nan, 0, 0))
        self.assertEqual(result.command, Velocity())
        self.assertTrue(result.fault)

    def test_p_controller_converges_in_kinematic_model(self):
        controller = PointController((1, 1))
        pose = Pose2D(0, 0, math.pi)
        for _ in range(2500):
            result = controller.update(pose)
            if result.done:
                break
            pose = integrate(pose, result.command, 0.05)
        self.assertTrue(result.done)
        self.assertLessEqual(math.hypot(pose.x - 1, pose.y - 1), 0.08)


def integrate(pose, command, dt):
    return Pose2D(pose.x + command.linear * math.cos(pose.yaw) * dt,
                  pose.y + command.linear * math.sin(pose.yaw) * dt,
                  wrap_angle(pose.yaw + command.angular * dt))


class PurePursuitTests(unittest.TestCase):
    def test_target_interpolates_inside_segment(self):
        controller = PurePursuitController([(0, 0), (2, 0)], lookahead=0.3)
        self.assertEqual(controller.point_at(0.3), (0.3, 0.0))

    def test_arc_length_continues_around_corner(self):
        controller = PurePursuitController([(0, 0), (1, 0), (1, 1)])
        self.assertEqual(controller.point_at(1.5), (1.0, 0.5))

    def test_projection_advances_monotonically(self):
        controller = PurePursuitController([(0, 0), (3, 0)])
        controller.update(Pose2D(0, 0, 0))
        controller.update(Pose2D(0.4, 0, 0))
        old = controller.progress
        controller.update(Pose2D(0.2, 0, 0))
        self.assertGreaterEqual(controller.progress, old)

    def test_start_near_end_does_not_skip_start(self):
        controller = PurePursuitController([(0, 0), (1, 0)])
        result = controller.update(Pose2D(1, 0, 0))
        self.assertEqual(result.state, "APPROACH_PATH_START")
        self.assertFalse(result.done)
        self.assertEqual(result.command.linear, 0)

    def test_closed_path_does_not_finish_at_initial_point(self):
        controller = PurePursuitController([(0, 0), (1, 0), (1, 1), (0, 0)])
        result = controller.update(Pose2D(0, 0, 0))
        self.assertFalse(result.done)
        self.assertEqual(controller.progress, 0)

    def test_short_closed_path_does_not_finish_at_start(self):
        controller = PurePursuitController(
            [(0, 0), (.1, 0), (.1, .1), (0, .1), (0, 0)], lookahead=.6,
            position_tolerance=.02)
        result = controller.update(Pose2D(0, 0, 0))
        self.assertFalse(result.done)
        self.assertNotEqual(result.command, Velocity())

    def test_duplicate_vertices_are_removed(self):
        controller = PurePursuitController([(0, 0), (0, 0), (1, 0)])
        self.assertEqual(len(controller.path), 2)

    def test_single_point_path_is_handled(self):
        controller = PurePursuitController([(0, 0)])
        self.assertTrue(controller.update(Pose2D(0, 0, 0)).done)

    def test_endpoint_stops_and_latches(self):
        controller = PurePursuitController([(0, 0), (0.5, 0)])
        controller.update(Pose2D(0, 0, 0))
        self.assertTrue(controller.update(Pose2D(0.49, 0, 0)).done)
        self.assertEqual(controller.update(Pose2D(1, 0, 0)).command, Velocity())

    def test_pursuit_tracks_polyline_in_kinematic_model(self):
        controller = PurePursuitController([(0, 0), (1, 0), (1, 1), (2, 1)])
        pose = Pose2D(0, 0, 0)
        for _ in range(4000):
            result = controller.update(pose)
            if result.done:
                break
            self.assertLessEqual(abs(result.command.angular), 0.85 + 1e-12)
            pose = integrate(pose, result.command, 0.05)
        self.assertTrue(result.done)
        self.assertLessEqual(math.hypot(pose.x - 2, pose.y - 1), 0.08)


class WallFollowerTests(unittest.TestCase):
    def test_positive_distance_error_turns_left(self):
        result = WallFollower().update(Pose2D(0, 0, 0), sectors(left=0.5), 0)
        self.assertGreater(result.command.angular, 0)

    def test_negative_distance_error_turns_right(self):
        result = WallFollower().update(Pose2D(0, 0, 0), sectors(left=0.2), 0)
        self.assertLess(result.command.angular, 0)

    def test_front_wall_with_right_open_starts_right_turn(self):
        result = WallFollower().update(Pose2D(0, 0, 0), sectors(front=0.25, right=2), 0)
        self.assertEqual(result.state, "TURN_RIGHT")
        self.assertLess(result.command.angular, 0)
        self.assertEqual(result.command.linear, 0)

    def test_dead_end_chooses_consistent_right_uturn(self):
        result = WallFollower().update(Pose2D(0, 0, 0), sectors(front=0.25), 0)
        self.assertEqual(result.state, "TURN_AROUND")
        self.assertLess(result.command.angular, 0)

    def test_left_opening_requires_debounce(self):
        controller = WallFollower()
        self.assertEqual(controller.update(Pose2D(0,0,0), sectors(left=2), 0).state,
                         "FOLLOW_WALL")
        self.assertEqual(controller.update(Pose2D(0.01,0,0), sectors(left=2), 0.2).state,
                         "ADVANCE_LEFT")

    def test_reused_scan_cannot_satisfy_opening_debounce(self):
        controller = WallFollower()
        reading = sectors(left=2)
        controller.update(Pose2D(0,0,0), reading, 0, scan_stamp=0)
        result = controller.update(Pose2D(.01,0,0), reading, .18, scan_stamp=0)
        self.assertEqual(result.state, "FOLLOW_WALL")
        result = controller.update(Pose2D(.01,0,0), sectors(left=.32), .2, scan_stamp=.2)
        self.assertEqual(result.state, "FOLLOW_WALL")

    def test_reappearing_wall_cancels_corner_advance(self):
        controller = WallFollower()
        controller.update(Pose2D(0,0,0), sectors(left=2), 0)
        controller.update(Pose2D(0,0,0), sectors(left=2), .2)
        result = controller.update(Pose2D(.01,0,0), sectors(left=.32), .4)
        self.assertEqual(result.state, "FOLLOW_WALL")
        self.assertEqual(result.command, Velocity())

    def test_left_turn_waits_until_car_has_passed_corner(self):
        controller = WallFollower()
        controller.update(Pose2D(0,0,0), sectors(left=2), 0)
        controller.update(Pose2D(0,0,0), sectors(left=2), 0.2)
        self.assertEqual(controller.update(Pose2D(0.10,0,0), sectors(left=2), 1).state,
                         "ADVANCE_LEFT")
        self.assertEqual(controller.update(Pose2D(0.23,0,0), sectors(left=2), 2.5).state,
                         "TURN_LEFT")

    def test_turn_crosses_pi_with_correct_accumulated_angle(self):
        controller = WallFollower()
        start = math.radians(170)
        controller.update(Pose2D(0,0,start), sectors(front=.2,left=2), 0)
        result = controller.update(Pose2D(0,0,math.radians(-100)), sectors(), 2)
        self.assertEqual(result.command, Velocity())
        result = controller.update(Pose2D(0,0,math.radians(-100)), sectors(), 2.2)
        self.assertEqual(result.state, "FOLLOW_WALL")

    def test_turn_timeout_latches_stop(self):
        controller = WallFollower()
        controller.update(Pose2D(0,0,0), sectors(front=.2), 0)
        result = controller.update(Pose2D(0,0,0), sectors(front=.2), 11)
        self.assertTrue(result.fault)
        self.assertEqual(result.command, Velocity())
        self.assertEqual(controller.update(Pose2D(0,0,1), sectors(), 12).state, "ERROR")

    def test_turn_completion_waits_for_scan_after_rotation(self):
        controller = WallFollower()
        controller.update(Pose2D(0,0,0), sectors(front=.2,left=2), 0, scan_stamp=0)
        controller.update(Pose2D(0,0,math.pi/2), sectors(left=2), 2, scan_stamp=1.9)
        result = controller.update(Pose2D(0,0,math.pi/2), sectors(left=2), 2.2, scan_stamp=1.9)
        self.assertEqual(result.state, "TURN_LEFT")
        self.assertEqual(result.command, Velocity())
        result = controller.update(Pose2D(0,0,math.pi/2), sectors(), 2.25, scan_stamp=2.2)
        self.assertEqual(result.state, "FOLLOW_WALL")

    def test_fault_requires_explicit_reset(self):
        controller = WallFollower()
        controller.update(Pose2D(0,0,0), sectors(front=.2), 0)
        controller.update(Pose2D(0,0,0), sectors(front=.2), 11)
        self.assertEqual(controller.update(Pose2D(0,0,0), sectors(), 12).command, Velocity())
        controller.reset()
        result = controller.update(Pose2D(0,0,0), sectors(), 0)
        self.assertFalse(result.fault)
        self.assertGreater(result.command.linear, 0)

    def test_corner_advance_cannot_continue_forever(self):
        controller = WallFollower()
        controller.update(Pose2D(0,0,0), sectors(left=2), 0)
        controller.update(Pose2D(0,0,0), sectors(left=2), .2)
        result = controller.update(Pose2D(0,0,0), sectors(left=2), 6)
        self.assertEqual(result.state, "ERROR")
        self.assertEqual(result.command, Velocity())

    def test_left_opening_cannot_immediately_retrigger(self):
        controller = WallFollower()
        controller.update(Pose2D(0,0,0), sectors(front=.2,left=2), 0)
        controller.update(Pose2D(0,0,math.pi/2), sectors(left=2), 2)
        controller.update(Pose2D(0,0,math.pi/2), sectors(left=2), 2.2)
        result = controller.update(Pose2D(0,.03,math.pi/2), sectors(left=2), 3)
        self.assertEqual(result.state, "FOLLOW_WALL")
        self.assertEqual(result.command.angular, 0)

    def test_observed_wall_and_distance_rearm_left_turn(self):
        controller = WallFollower()
        controller.update(Pose2D(0,0,0), sectors(front=.2,left=2), 0)
        controller.update(Pose2D(0,0,math.pi/2), sectors(), 2)
        controller.update(Pose2D(0,0,math.pi/2), sectors(), 2.2)
        controller.update(Pose2D(0,.1,math.pi/2), sectors(), 3)
        controller.update(Pose2D(0,.3,math.pi/2), sectors(), 4)
        self.assertTrue(controller.left_ready)

    def test_adaptive_speed_reduces_near_obstacle(self):
        base = WallFollower(WallConfig(adaptive=False))
        adaptive = WallFollower(WallConfig(adaptive=True))
        pose = Pose2D(0,0,0)
        # Compare forward motion above the stop threshold; at the threshold
        # both strategies correctly stop and cannot demonstrate adaptation.
        self.assertLess(adaptive.update(pose, sectors(front=.5), 0).command.linear,
                        base.update(pose, sectors(front=.5), 0).command.linear)

    def test_missing_scan_stops(self):
        result = WallFollower().update(Pose2D(0,0,0), LaserSectors.invalid("missing"), 0)
        self.assertEqual(result.command, Velocity())
        self.assertEqual(result.state, "WAIT_SCAN")

    def test_clock_reset_requires_controller_reset(self):
        controller = WallFollower()
        controller.update(Pose2D(0,0,0), sectors(), 5)
        result = controller.update(Pose2D(0,0,0), sectors(), 1)
        self.assertTrue(result.fault)


if __name__ == "__main__":
    unittest.main()
