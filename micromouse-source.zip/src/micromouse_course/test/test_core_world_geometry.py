"""连续几何回归，不涉及 Gazebo、物理接触或 ROS 话题。"""

import importlib.util
from pathlib import Path
import unittest


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "wall_kinematics", PACKAGE_ROOT / "tools" / "check_wall_kinematics.py")
KINEMATICS = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(KINEMATICS)


class WorldGeometryTests(unittest.TestCase):
    def test_baseline_reaches_exit_without_disc_collision(self):
        result = KINEMATICS.run_case(adaptive=False)
        self.assertEqual(result["outcome"], "REACHED_EXIT")
        self.assertGreater(result["minimum_disc_clearance_m"], 0.0)

    def test_adaptive_reaches_exit_without_disc_collision(self):
        result = KINEMATICS.run_case(adaptive=True)
        self.assertEqual(result["outcome"], "REACHED_EXIT")
        self.assertGreater(result["minimum_disc_clearance_m"], 0.0)


if __name__ == "__main__":
    unittest.main()
